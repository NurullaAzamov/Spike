function get_matlab_code

InFile='For_matlab_code_Lectures_MATH3701.tex';
OutFile='MATH3701_matlab_code.txt';

InF=fopen(InFile);
OutF=fopen(OutFile,'w'); 

flag=0; 
hline=char(ones(1,70)*'-');

while ~feof(InF)
    ss=fgetl(InF);
    b=strfind(ss,'\begin{verbatim}');
    if ~isempty(b)
        flag=1;
        continue
    end
    
    b=strfind(ss,'\end{verbatim}');
    if ~isempty(b)
        fprintf(OutF,'\n\n%s\n\n',hline);
        flag=0;
        continue
    end
    if flag==1
        fprintf(OutF,'%s\n',ss);
    end
end

fclose(OutF);
fclose(InF);

end