function ss=GetSentence(k)
% This function returns a random sentence of Arithmetic,
% k is an indicator of complexity of the formula. 

if k==1,
    ss=sprintf('(%s=%s)',GetTerm(randi(3)),GetTerm(randi(3)));
else
    bool=randi(2)-1;
    randoper=randi(10);
    if randoper<4,
        oper='\& ';
    elseif randoper<7,
        oper='\then ';
    else
        oper='\iff ';
    end
    
    if bool,
        ss=sprintf('(%s%s%s)',GetSentence(k-1),oper,GetSentence(1));
    else
        ss=sprintf('(%s%s%s)',GetSentence(1),oper,GetSentence(k-1));
    end
    
end


end