function outss=GetFreeVars(inss)
% This function returns a string of free variables outss
% which appear in a formula inss.


end