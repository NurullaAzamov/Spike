function b=IsCharFree(ch,inss)
% b = 0, if ch does not appear in inss,
% b = 1, if ch appears in inss as a free variable,
% b = 2, if ch appears in inss as a bound variable.


b=ismember(ch,inss);

end