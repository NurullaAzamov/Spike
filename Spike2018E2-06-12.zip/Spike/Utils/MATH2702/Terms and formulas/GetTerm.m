function [ss,vrs]=GetTerm(k)
% This function returns in ss a random arithmetic term
% with k atomic terms. The variable vrs contains 
% atomic terms which comprise the term ss. 

vars='abcklmnpqrstxyz';
vrs='';
n=length(vars);
m=randi(n);
if k==1,
    ss=vars(randi(m));
else
    bool=randi(2)-1;
    randoper=randi(10);
    if randoper<5,
        oper='\cdot ';
    elseif randoper<9,
        oper='+';
    else
        oper='-';
    end
    
    if bool,
        ss=sprintf('(%s%s%c)',GetTerm(k-1),oper,vars(randi(m)));
    else
        ss=sprintf('(%c%s%s)',vars(randi(m)),oper,GetTerm(k-1));
    end
end

end