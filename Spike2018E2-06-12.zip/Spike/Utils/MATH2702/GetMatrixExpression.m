function [s,b]=GetMatrixExpression
% This is a Spike G-type function.
% It returns a string of this kind:
%  (A+B)C^T
% where A,B, and C are matrices.

% NOT FINISHED

cc=randi(2);

if cc==1,
    i=randi(4)+1;
    j=randi(4)+1;
    k=randi(4)+1;
end

end