function T=TypeOfSingularPoint(A)
% This function returns type of the zero solution
% of the linear system
%
%  x'(t) = a*x(t) + b*y(t),
%  y'(t) = c*x(t) + d*y(t),
%
%  where A = [a,b;c,d].
%
% It is assumed that the type is generic.
%
%  Input: 
%     A, a real 2 x 2 matrix.
%
%  Output:
%     T = 0, if stable node,
%     T = 1, if unstable node,
%     T = 2, if unstable node,
%     T = 3, if stable focus,
%     T = 4, if unstable focus,
%     T = 5, if centers.
%     T = 9, if A==0.

  if ~NotZero(A(1,1)*A(1,2)*A(2,1)*A(2,2)),
      T=9; 
      return
  end

  lmb=eig(A);
  
  Re=real(lmb);
  
  if ~NotZero(abs(Re(1)*Re(2))),
      T=5; 
      return
  end
  
  Im=imag(lmb);
  
  if NotZero(Im(1));
      if Re(1)<0,
          T=3;
      else
          T=4;
      end
  else
      if Re(1)<0 && Re(2)<0,
          T=0;
      elseif Re(1)>0 && Re(2)>0,
          T=1;
      elseif Re(1)*Re(2)<0,
          T=2;
      end
      
  end
  
end