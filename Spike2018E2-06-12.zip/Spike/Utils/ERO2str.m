function s = ERO2str(Type,i,j,alpha)
  s='wrong ERO';
  if Type==1, 
      if alpha==1,
          s=sprintf('R_{%d} \\leftarrow R_{%d} + R_{%d}',i,i,j);
      elseif alpha==-1,
          s=sprintf('R_{%d} \\leftarrow R_{%d} - R_{%d}',i,i,j);
      else
          s=sprintf('R_{%d} \\leftarrow R_{%d} %+d R_{%d}',i,i,alpha,j);
      end
  elseif Type==2,
      if alpha==1,
          s=sprintf('R_{%d} \\leftarrow R_{%d}',i,i);
      elseif alpha==-1,
          s=sprintf('R_{%d} \\leftarrow - R_{%d}',i,i);
      else
          s=sprintf('R_{%d} \\leftarrow %d R_{%d}',i,alpha,i);
      end
  elseif Type==3,
      s=sprintf('R_{%d} \\leftrightarrow R_{%d}',i,j);
  end
end