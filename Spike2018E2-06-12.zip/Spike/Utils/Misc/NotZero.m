function bool=NotZero(r)
% This functions returns True, if 
% the real number r is not zero.

ZERO=10^(-9);
bool = (abs(r)>ZERO);

end