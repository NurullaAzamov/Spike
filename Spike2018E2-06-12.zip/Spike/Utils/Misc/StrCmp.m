function bool=StrCmp(s1,s2)
% This functions returns True, if 
% the string s1 starts with the string s2.

len = length(s2);
bool = (length(s1) >= len) && strcmp(s1(1:len),s2);

end
