function bool=IsZero(r)
% This functions returns True, if 
% the real number r is zero.

bool = ~NotZero(r);

end