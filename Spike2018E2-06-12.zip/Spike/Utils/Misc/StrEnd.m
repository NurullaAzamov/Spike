function bool=StrEnd(s1,s2)
% This functions returns True, if 
% the string s1 ends with the string s2.

len = length(s2);
bool = (length(s1) >= len) && strcmp(s1(end-len+1:end),s2);

end
