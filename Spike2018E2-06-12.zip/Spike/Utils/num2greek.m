function s=num2greek(n)
% Converts an arabic numeral n to an ancient Greek numeral.

if n>10^6-1,
    error('too big greek number');
end

u=char(ones(9,8)*' ');
u(1,1:6)='\alpha';
u(2,1:5)='\beta';
u(3,1:6)='\gamma';
u(4,1:6)='\delta';
u(5,1:8)='\epsilon';
u(6,1:8)='\digamma';
u(7,1:5)='\zeta';
u(8,1:4)='\eta';
u(9,1:6)='\theta';

d=char(ones(9,8)*' ');
d(1,1:5)='\iota';
d(2,1:6)='\kappa';
d(3,1:7)='\lambda';
d(4,1:3)='\mu';
d(5,1:3)='\nu';
d(6,1:3)='\xi';
d(7,1:3)='\,o';
d(8,1:3)='\pi';
d(9,1:6)='\qoppa';

c=char(ones(9,8)*' ');
c(1,1:4)='\rho';
c(2,1:6)='\sigma';
c(3,1:4)='\tau';
c(4,1:8)='\upsilon';
c(5,1:4)='\phi';
c(6,1:4)='\chi';
c(7,1:4)='\psi';
c(8,1:6)='\omega';
c(9,1:6)='\sampi';

s=[];
if mod(n,10)~=0,
  s=u(mod(n,10),:); 
end

if mod(floor(n/10),10)~=0,
    s=[d(mod(floor(n/10),10),:),s];
end

if mod(floor(n/100),10)~=0,
    s=[c(mod(floor(n/100),10),:),s];
end

if mod(floor(n/1000),10)~=0,
    s=[u(mod(floor(n/1000),10),:),'\dash',s];
end

if mod(floor(n/10000),10)~=0,
    s=[c(mod(floor(n/10000),10),:),'\dash',s];
end

if mod(floor(n/100000),10)~=0,
    s=[c(mod(floor(n/100000),10),:),'\dash',s];
end

s(s==' ')='';

end