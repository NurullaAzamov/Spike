function p = GetRandProbDist(n,k)
% GetRandProbDist returns a random
% probability distribution of size n.
% k is the number of digits after the decimal point.

for j=1:10,
    p=rand(1,n)+2*10^(-k);
    p=p/sum(p);
    p=round(p*10^k)/10^k;
    p(n)=1-sum(p(1:n-1));
    if prod(p)>10^(-10), 
        return
    end
end
end

