function s = Convert_real_to_comp_form(x,b,k,L,U)
% This function returns a base b k-digit computer form of a real number x
% with lower L and upper bounds U  bounds for the exponent. 
% 
% Input: x,b,k,L,U
% Output: s

if x==0, s='0'; return; end

if x<0, s='-'; else s='+'; end

x=abs(x);
E=floor(1+log(x)/log(b));
if E<L, s='UF'; return; end
if E>U, s='OF'; return; end

x=x/b^E;
s=sprintf('%s%s\\cdot %d^{%d}',s,Convert_real_to_base(x,b,k),b,E);
end
