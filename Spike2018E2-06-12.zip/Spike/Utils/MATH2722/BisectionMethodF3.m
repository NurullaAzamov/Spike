function x = BisectionMethodF3(c,d,a0,b0,kmax,tol)
% This function finds an approximate solution 
% of the equation f(x) = 0 in the interval [a0,b0],
% using the bisection method, where f(x)=x^5-c*x-d. 
% The stopping condition used is |f(xn)| < tol.
% 
% Input: 
%    c,d, coefficients
%    a0, left end of the domain of f(x) 
%    b0, right end of the domain of f(x) 
%    kmax, the maximum number of iterations,
%    tol, tolerance
% Output:
%    x, an approximate solution of f(x) = 0 

if (a0^5-c*a0-d)*(b0^5-c*b0-d) > 0, 
    error('Function has the same sign at end points'); 
end
for k=1:kmax,
    x=(a0+b0)/2;
    if abs(x^5-c*x-d)<tol, 
        return
    end
    if (a0^5-c*a0-d)*(x^5-c*x-d)<=0, 
        b0=x;
    else
        a0=x;
    end
    if k>= kmax, 
        error('Root is not found to the desired tolerance.'); 
    end
end
end