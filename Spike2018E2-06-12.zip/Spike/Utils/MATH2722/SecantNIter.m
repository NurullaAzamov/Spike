function s = SecantNIter(f,P1,a,b,niter)
% This function finds an approximate solution 
% of the equation f(x) = 0 in the interval [a,b],
% using 'niter' iterations of the Secant Method. 
% 
% Input: 
%    f, a continuous function on [a,b], given by an inline command
%    a, left end of the domain of f(x) 
%    b, right end of the domain of f(x) 
%    niter, number of iterations,
% Output:
%    x, an approximate solution of f(x) = 0 

x(1)=a; x(2)=b; % initial root enclosing interval
if sign(f(a,P1)) == sign(f(b,P1)), 
    error('Function has the same sign at end points'); 
end
for k=2:niter+1,
    x(k+1)=x(k)-(x(k)-x(k-1))*f(x(k),P1)/(f(x(k),P1)-f(x(k-1),P1));
end
s=x(niter+2);
end