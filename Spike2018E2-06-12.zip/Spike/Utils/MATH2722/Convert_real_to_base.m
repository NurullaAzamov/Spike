function s = Convert_real_to_base(x,b,N)
% This function converts a real number x
% to base b < 17. N is the number of digits after the point.
% The method of rounding used is chopping.
% 
% Input: x,b
% Output: s

%s=char(ones(1,30)*'0');
s='';
d='0123456789ABCDEF';

n=floor(x);   % integer part of x
r=x-n;        % fractional part of x

% convert the integer part
while n>0
    r0 = rem(n,b);
    s=[d(1+r0),s];
    n = floor(n/b);
end

if r==0, 
    return
end

s=[s,'.'];
for k=1:N,
    r=r*b;
    r0=floor(r);
    s=[s,d(1+r0)];
    r=r-r0;
%     if r==0, 
%         break
%     end
end

end