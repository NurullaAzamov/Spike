function x = Convert_to_base(n,b)
% This function converts an integer n 
% to base b < 17.
% 
% Input: n,b
% Output: x

x=''; 
d='0123456789ABCDEF';
while n>0
    r = rem(n,b);
    x=[d(1+r),x];
    n = floor(n/b);
end
end