function [EB,x]=EightBytesOfRealNum(s,c,f,N,form)
% This function returns in EB the sequence of eight bytes
% which encode the real number 
%
%         x=(-1)^s * 2^(c-1023) * (1+f),
%
% where the fractional part of the mantissa f is looked at 
% as a sequence of N bits. 
% The parameter 'form' shows how EB is presented, as 8 bytes (form == 0)
% or as 1,11 and 52 bytes (form == 1).
%
% Input: 
%      s, the first sign bit of 8 byte double precision computer number,
%      c, the next 11 exponent bits, given as an integer,
%      f, the first N bits of the 52 bit mantissa part, given as 
%               a real number. 
%      form, parameter which regulates how the 64 bits are presented:
%         form=0, as 8 bytes; 
%         form=1, as groups 1, 11, 52 bits;
%         form=2, in hexadecimal form.
%
% Output:
%      EB, eight bytes which encode the number x,
%      x, a number which is encoded by the eight bytes EB.

% The sign bit (first bit) of EB,
if s==1, 
    ss='1';
else
    ss='0'; 
end

% ... and the exponent part (next 11 bits)
exp_part=Convert_to_base(c,2);
exp_part = [char(ones(1,11-length(exp_part))*'0'),exp_part];  

ss=[ss,exp_part];

% ... and the mantissa part (next 52 bits) 
mantissa=Convert_real_to_base(f,2,N);
mantissa=mantissa(2:end);
ss=[ss,mantissa]; 

% append EB by zeros to 64 bits.
len=length(ss);
ss=[ss,char(ones(1,64-len)*'0')];

% Inserting spaces between 64 bits for better readability. 
if form == 0
    EB=char(ones(1,64+7)*' ');
    for k=0:7,
        EB(8*k+1+k:8*k+8+k)=ss(8*k+1:8*k+8);
    end
elseif form==1,
    EB=char(ones(1,64+2)*' ');
    EB(1)=ss(1);
    EB(3:13)=ss(2:12);
    EB(15:15+51)=ss(13:64);
elseif form==2,
    EB=char(ones(1,16+7)*' ');
    for j=1:8,
        ttt=Convert_from_base_to_base(ss(8*j-7:8*j),2,16);
        if length(ttt)==1,
            ttt=['0',ttt];
        elseif isempty(ttt),
            ttt='00';
        end
        EB(3*j-2:3*j-1)=ttt;
    end
end
%x=sprintf('$%7.5f$',(-1)^s*2^(c-1023)*(1+f));
x=sprintf('$%.12f$',(-1)^s*2^(c-1023)*(1+f));
end