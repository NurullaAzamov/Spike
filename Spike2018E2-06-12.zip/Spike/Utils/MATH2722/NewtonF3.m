function s = NewtonF3(f,df,P1,P2,x1,kmax,tol)
% This function finds an approximate solution 
% of the equation f(x,P1,P2) = 0 in the interval [P1,P2],
% using Newton's Method. The stopping condition 
% is |f(x(n))| < tol.
% 
% Input: 
%    f, a continuous function on [a,b], given by an inline command
%    a, left end of the domain of f(x) 
%    b, right end of the domain of f(x) 
%    kmax, the maximum number of iterations,
%    tol, tolerance
% Output:
%    s, an approximate solution of f(x) = 0 

x(1)=x1;  % initial approximation
for k=1:kmax,
    x(k+1)=x(k) - f(x(k),P1,P2)/df(x(k),P1,P2);
    if abs(f(x(k+1),P1,P2))<tol, 
        s=x(k+1);
        return
    end
    if k>= kmax, 
        error('NewtonF3: Root is not found to the desired tolerance.'); 
    end
end
end