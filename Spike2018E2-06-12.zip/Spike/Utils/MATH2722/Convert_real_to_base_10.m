function x = Convert_real_to_base_10(d,b)
% This function converts a real number given by string d 
% from base b to base 10. 
% 
% Input: d,b,N
% Output: x
    function n=Convert_digit(s,bb)
        n=bb;
        if s == '0', n = 0; end
        if s == '1', n = 1; end
        if s == '2', n = 2; end
        if s == '3', n = 3; end    
        if s == '4', n = 4; end
        if s == '5', n = 5; end    
        if s == '6', n = 6; end
        if s == '7', n = 7; end 
        if s == '8', n = 8; end
        if s == '9', n = 9; end  
        if s == 'A', n = 10; end
        if s == 'B', n = 11; end    
        if s == 'C', n = 12; end    
        if s == 'D', n = 13; end    
        if s == 'E', n = 14; end    
        if s == 'F', n = 15; end    
        if n>=bb, error('Wrong digit'); end
    end
    
if b>16, error('Base is too large'); end
n=length(d);
x=0;
for k = 1:n,
    if d(k) == '.', break; end;
    x = x*b + Convert_digit(d(k),b);
end
y=0;
for j=k+1:n,
  y=y+Convert_digit(d(j),b)/b^(j-k);  
end
x=x+y;
end