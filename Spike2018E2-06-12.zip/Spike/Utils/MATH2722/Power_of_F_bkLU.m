function n=Power_of_F_bkLU(b,k,L,U)
% Returns the number of computer numbers with base b
% mantissa length k, lower L and upper U boudns for exponent. 

n=1+2*(b-1)*b^(k-1)*(U-L+1);
end