function s=Convert_from_base_to_base(d,b1,b2)
% This function converts an integer given by string d
% from base b1 to base b2.
% 
% Input: d,b1,b2
% Output: s

x=Convert_to_base_10(d,b1);
s=Convert_to_base(x,b2);
end