function s = Convert_real_to_sci_form(x,b,k,L,U)
% This function returns a base b k-digit scientific form of a real number x
% with lower L and upper bounds U  bounds for the exponent. 
% 
% Input:  x, a real number,
%         b, base,
%         k, mantissa length,
%         L, lower bound of exponent
%         U, upper bound of exponent
%
% Output: s, a string containing in LaTeX format the 
%         scientific form of a real number x.

if x==0, 
    s='0'; 
    return
end

if x<0,
    s='-';
else
    s='';
end

x=abs(x);

E=floor(log(x)/log(b));

if E<L,
    s='UF';
    return
end

if E>U,
    s='OF';
    return
end

x=x/b^E;
entirepart=floor(x);
x=x-entirepart;
s=sprintf('%s%d%s\\cdot %d^{%d}',s,entirepart,Convert_real_to_base(x,b,k-1),b,E);
end
