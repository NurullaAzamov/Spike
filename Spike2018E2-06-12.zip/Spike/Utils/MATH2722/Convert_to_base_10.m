function x = Convert_to_base_10(d,b)
% This function converts an integer given by string d
% from base b to base 10.
% 
% Input: d,b
% Output: x

    function n=Convert_digit(c)
        if ismember(c,'1234567890'),
            n=c-48;
        elseif ismember(c,'ABCDEF'),
            n=c-55;
        else 
            error('Wrong digit'); 
        end
    end
    

d=upper(d);

if b>16, 
    error('Base is too large'); 
end

n=length(d);

x=0;

for k = 1:n,
    x = x*b + Convert_digit(d(k));
end

end