function x = RegularFalsiNIter(f,P1,a0,b0,niter)
% This function finds an approximate solution 
% of the equation f(x,P1) = 0 in the interval [a0,b0],
% using 'niter' iterations of the Regular Falsi method. 
% 
% Input: 
%    f, a continuous function on [a0,b0] x [c,d], given by an inline command
%    a0, left end of the domain of f(x) 
%    b0, right end of the domain of f(x) 
%    P1, a number from [c,d]
%    niter, number of iterations
% Output:
%    x, an approximate solution of f(x) = 0 

a=a0; b=b0; % initial root enclosing interval
if sign(f(a,P1)) == sign(f(b,P1)), % this is a bit faster than f(a)*f(b)>0.
    error('Function has the same sign at end points'); 
end
for k=1:niter,
    x=b-(b-a)*f(b,P1)/(f(b,P1)-f(a,P1));
    if sign(f(a,P1)) == sign(f(x,P1)),
        a=x;
    else
        b=x;
    end
end
end