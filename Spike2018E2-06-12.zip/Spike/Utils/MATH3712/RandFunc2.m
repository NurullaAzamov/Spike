function S=RandFunc2(c1,c2)
% This function returns a LaTeX string 
% containing a ''random'' function of two variables c1 and c2.

a=randi(5);
b=randi(6)-3;
c=randi(6)-3;

if a==0,
  as='';
else
  as=sprintf('%s%c^2',AsCoef(a),c1);
end
if b==0,
  bs='';
else
  bs=sprintf('%s%c%c',AsSignedCoef(b),c1,c2);
end
if c==0,
  cs='';
else
  cs=sprintf('%s%c^2',AsSignedCoef(c),c2);
end
if b^2+c^2>0,
    S=sprintf('(%s%s%s)',as,bs,cs);
else
    S=sprintf('%s%s%s',as,bs,cs);
end
k=randi(2);
if k==1, S=['-',S];
else S=['+',S];
end

end