function S=StrOrder2PDE2(A,c1,c2)
% This function returns a LaTeX string 
% containing a second order PDE in variables c1 and c2
% with coefficients from a 2x2 symmetric matrix A.

if norm(A-A')>10^(-8),
    error('Non-symmetric matrix');
end
if norm(A)<10^(-8),
    error('Zero matrix');
end

if abs(A(1,1))<10^(-8),
  S11='';
else
  S11=sprintf('%su_{%c%c}',AsCoef(A(1,1)),c1,c1);
end
if abs(A(1,2))<10^(-8),
  S12='';
else
  S12=sprintf('%su_{%c%c}',AsSignedCoef(2*A(1,2)),c1,c2);
end
if abs(A(2,2))<10^(-8),
  S22='';
else
  S22=sprintf('%su_{%c%c}',AsSignedCoef(A(2,2)),c2,c2);
end
S=sprintf('%s%s%s',S11,S12,S22);
end