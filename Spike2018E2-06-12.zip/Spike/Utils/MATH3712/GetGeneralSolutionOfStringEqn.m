function [s,b]=GetGeneralSolutionOfStringEqn

a=1+randi(9);
c=a;

b=(rand<0.5);
if b==0,
    c = a + randi(3);
end

y=randi(2);
if y==1,
    x=a; a=c; c=x; 
end

y=randi(2);

if y==1,
    s=sprintf('For any function $f \\in C^2(\\mbR)$ the function $u(x,t) = f(x-%dt)$ is a solution of the string equation $u_{tt} = %d u_{xx}.$',a,c^2);
else
    s=sprintf('For any function $f \\in C^2(\\mbR)$ the function $u(x,t) = f(x+%dt)$ is a solution of the string equation $u_{tt} = %d u_{xx}.$',a,c^2);
end

end