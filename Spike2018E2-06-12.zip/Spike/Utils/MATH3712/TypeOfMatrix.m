function type=TypeOfMatrix(A)
% This function returns type of a matrix A.
% 0 - ell, 1 - par, 2 -hyper.

[m,n]=size(A);
if m~=n,
    error('Non-square matrix');
end

if A(1,1)<0, 
    A=-A;
end

if abs(det(A)) < 10^(-8),
    type = 1;
    return
end

type=0; 
for k=1:n, 
    if det(A(1:k,1:k)) <= 10^(-8), 
       type=2; 
       return
    end
end
    
end