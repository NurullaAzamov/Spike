function [s,b]=GetProductSolutionOfStringEqn

a=1+randi(9);
m=1+randi(7);
n=m;

b=(rand<0.5);
if b==0,
    n = n + randi(3);
end
y=randi(2);
if y==1,
    x=m; m=n; n=x; 
end

y=randi(3);

if y==1,
  s=sprintf('The function $u(x,t) = \\cos %d x \\cos %d t$ is a solution of the string equation $u_{tt} = %d u_{xx}.$',m,n*a,a^2);
elseif y==2,
  s=sprintf('The function $u(x,t) = \\cos %d x \\sin %d t$ is a solution of the string equation $u_{tt} = %d u_{xx}.$',m,n*a,a^2);
else
  s=sprintf('The function $u(x,t) = \\sin %d x \\sin %d t$ is a solution of the string equation $u_{tt} = %d u_{xx}.$',m,n*a,a^2);
end

end