function S=RandOrder1ConstPDO2(c1,c2)

a=0; b=0; c=0;
while a==0, a=randi(12)-6; end
while b==0, b=randi(12)-6; end
while abs(c)<=1, c=randi(12)-6; end

s1=AsSignedCoef(a);
s2=AsSignedCoef(b);
s3=AsSignedCoef(c);
S=sprintf('%su_{%c}%su_{%c}%s',s1,c1,s2,c2,s3);

end