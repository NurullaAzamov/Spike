function A=GetRandOrder2PDEMatrix(n)
% This function generates a symmetric n x n matrix A
% which is elliptic, parabolic or hyperbolic
% with equal probability 1/3. 

A=zeros(n,n);
while norm(A)<10^(-8),
    r=rand;
    j=randi(n);
    spec=randi(4,1,n); 
    if r<1/3,
        spec(j)=0;
    elseif r<2/3, 
        % do nothing
    else
        spec(j)=-spec(j);
    end
    B=zeros(n,n);
    while det(B) == 0,  
        B=round(rand(n,n)*5 - 2*ones(n,n)); 
    end
    A=B'*diag(spec)*B;
end
end
