function E=FSHE1D(x,t,a)
% FSHE1D(x,t,a) is the 
% fundamental solution of 1D heat equation u_t=a^2 u_{xx}.

E=(4*pi*a^2*t)^(-1/2) * exp(-x^2/(4*a^2*t));

end