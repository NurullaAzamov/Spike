function S=StrOrder2PDE3(A,c1,c2,c3)
% This function returns a LaTeX string 
% containing a second order PDE in variables c1, c2 and c3
% with coefficients from a 3x3 symmetric matrix A.

if norm(A-A')>10^(-8),
    error('Non-symmetric matrix');
end
if norm(A)<10^(-8),
    error('Zero matrix');
end

%S=[AsFracCoef(A(1,1)),'u_{',c1,c1,'}'];
if abs(A(1,1))<10^(-8),
  S11='';
else
  S11=sprintf('%su_{%c%c}',AsCoef(A(1,1)),c1,c1);
end
if abs(A(1,2))<10^(-8),
  S12='';
else
  S12=sprintf('%su_{%c%c}',AsSignedCoef(2*A(1,2)),c1,c2);
end
if abs(A(2,2))<10^(-8),
  S22='';
else
  S22=sprintf('%su_{%c%c}',AsSignedCoef(A(2,2)),c2,c2);
end
if abs(A(1,3))<10^(-8),
  S13='';
else
  S13=sprintf('%su_{%c%c}',AsSignedCoef(2*A(1,3)),c1,c3);
end
if abs(A(2,3))<10^(-8),
  S23='';
else
  S23=sprintf('%su_{%c%c}',AsSignedCoef(2*A(2,3)),c2,c3);
end
if abs(A(3,3))<10^(-8),
  S33='';
else
  S33=sprintf('%su_{%c%c}',AsSignedCoef(A(3,3)),c3,c3);
end
S=sprintf('%s%s%s%s%s%s',S11,S22,S33,S12,S13,S23);
if S(1)=='+', S=S(2:end); end
end