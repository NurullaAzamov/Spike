function [s,b]=GetSolutionOf2DimLaplaceEqn
% This functions returns in s a polynomial of degree 3.
% b==1, if s is a solution of the Laplace equation; 
% b==0, if otherwise.  

while 1
    
    p1=zeros(4,4);
    p1(1:2,1:2)=randi(7,2,2)-3;
    
    p2=zeros(4,4);
    p2(3,1)=1; p2(1,3)=-1;
    
    p3=zeros(4,4);
    p3(4,1)=1; p3(2,3)=-3;
    
    p4=zeros(4,4);
    p4(1,4)=-1; p4(3,2)=3;
    
    a=randi(5,1,4)-2;
    
    % p is a random solution.
    p=a(1)*p1+a(2)*p2+a(3)*p3+a(4)*p4;
    
    b=(rand<0.5);
    
    spoiler=zeros(4,4);
    k=randi(4);
    spoiler(k,5-k) = randi(2);
    
    if b==0,
        p=p+spoiler;
    end
    
    if sum(sum(abs(p))) ~= 0,
        break
    end
    
end

s= Poly2Var2LaTeX(p);
if s(1)=='+',
    s=s(2:end);
end
s=sprintf('$u(x,y) = %s$',s);
end