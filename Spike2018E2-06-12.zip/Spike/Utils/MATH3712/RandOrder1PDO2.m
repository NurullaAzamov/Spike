function S=RandOrder1PDO2(c1,c2)

s1=RandFunc2(c1,c2);
s2=RandFunc2(c1,c2);
s3=RandFunc2(c1,c2);
S=sprintf('%su_{%c}%su_{%c}%su',s1,c1,s2,c2,s3);

end