function S=RandPoly2(A,c1,c2)
% This function returns a LaTeX string 
% containing a random polynomial of two variables c1 and c2.
% This polynomial is supposed to be used as a coefficient,
% hence, if there is more than one summand the polynomial is bracketed.

A=rand(2,2);
A=(A+A')*8;



end