function u=PoissonKernel(r,theta)

u = (1-r^2)/(1-2*r*cos(theta)+r^2);

end