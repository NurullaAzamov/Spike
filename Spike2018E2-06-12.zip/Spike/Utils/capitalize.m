function outss=capitalize(inss)

n=length(inss);
outss=lower(inss);
outss(1)=upper(outss(1));
for i=2:n,
    if inss(i-1)==' ' && inss(i)~=' ',
        outss(i)=upper(inss(i));
    end
end

end