function [x,y]=gcdcoef(a,b)
% This function finds an integer solution 
% of the equation a*x+b*y = gcd(a,b), such that 0 <= x < abs(b)/gcd(a,b),
% where a and b are two integers.
% Usage: [x,y]=gcdcoef(a,b). 

% Taking care of some special cases.
if (a==0) && (b==0), 
     error('At least of the integers a and b must be non-zero'); 
end
if a==0, x=0; y=sign(b); return; end;
if b==0, y=0; x=sign(a); return; end;

[x,y]=gcdcoefpos(abs(a),abs(b));

if b < 0, y = -y; end
if a < 0, x = -x; end

if x < 0, 
    x = x + abs(b);
    y = y - sign(b)*a;
end
end