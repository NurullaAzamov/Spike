function test_gcdcoef(n)

for i=1:n,
   a=500-randi(1000);
   b=0;
   while b==0, b=500-randi(1000); end
   [x,y]=gcdcoef2(a,b);
   d=gcd(a,b);
   if (a*x+b*y~= d) || (x<0) || (x >= abs(b)),
       disp([a,b]);
       error('A mistake');
   end
end
disp('OK');
end