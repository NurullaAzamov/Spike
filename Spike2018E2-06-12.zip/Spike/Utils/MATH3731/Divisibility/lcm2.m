function x = lcm2(a,b)
% This function calculates the least
% common multiple of two integers a and b.
c=gcd2(a,b);
x=round(a*b/c); 
end

