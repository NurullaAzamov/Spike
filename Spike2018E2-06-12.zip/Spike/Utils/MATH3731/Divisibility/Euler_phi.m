function phi=Euler_phi(n)

if ~isnumeric(n) || (n<1),
    error('The argument must be a positive integer.');
end

if n==1, 
    phi=1;
    return
end

a=factor(n);
[~,N]=size(a);
p=a(1);

k=1;
while k < N && a(k+1)==p,
    k=k+1;
end

phi=(p^k-p^(k-1))*Euler_phi(n/p^k);

end