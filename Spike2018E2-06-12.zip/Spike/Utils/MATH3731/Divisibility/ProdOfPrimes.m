function n=ProdOfPrimes(p,k)
% Returns 
%  n = p(1)^k(1)*...*p(m)^k(m),
% where m=size(p).

n=1;
[~,m]=size(p);
[~,m2]=size(k);
if m~=m2, 
    error('Arrays of different size.');
end

for j=1:m,
    n=n*p(j)^k(j);
end

end
