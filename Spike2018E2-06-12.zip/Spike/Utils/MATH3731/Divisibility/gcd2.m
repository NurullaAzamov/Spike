function x = gcd2(a,b)
% This function calculates the greatest 
% common divisor of two integers a and b.

if a==0 && b==0, error('Both integers are zero'); end;
a=abs(a);
b=abs(b);

if a==0, x = b; return; end; 
if b==0, x = a; return; end; 
if a==b, x = a; return; end;  
if a>b, a = rem(a,b); else b = rem(b,a); end;
x=gcd2(a,b); 
end

