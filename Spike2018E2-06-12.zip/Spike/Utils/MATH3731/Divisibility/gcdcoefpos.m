function [x,y]=gcdcoefpos(a,b)
% This function finds an integer solution 
% of the equation a*x+b*y = gcd(a,b), such that 0 <= x < b/gcd(a,b),
% where a and b are two positive integers.
% Usage: [x,y]=gcdcoef(a,b). 

% Replacing a and b by a co-prime pair, 
% so we have to solve now the equation a*x+b*y=1, 0 <= x < b.
c=gcd(a,b); a=round(a/c); b=round(b/c); 

% Taking care of some special cases.
if (a<=0) || (b<=0), 
     error('The integers a and b must be positive.'); 
end

% We expect that the number of divisions in 
% the Euclidean algorithm will not exceed 300. 
Max_number_of_divisions=300;
r=zeros(Max_number_of_divisions,1);
q=zeros(Max_number_of_divisions,1);
n=-999;
% Applying the Euclidean algorithm to find gcd of a and b.
r(1) = max(a,b); r(2) = min(a,b);
if r(2) == 1, 
    if a>=b, x=0; y=1;
    else x=1; y=0; end
    return
end
for k=3:Max_number_of_divisions, 
    r(k) = rem(r(k-2),r(k-1));
    q(k) = round((r(k-2)-r(k))/r(k-1));
    if r(k) ==1, n=k; break; end
end

if n==-999, disp([a,b]); error('Error!!!'); end

% Reversing back the Euclidean algorithm. 
x=1;      % these x and y solve the equation
y=-q(n); % x*r(n-2)+y*r(n-1)=1.

for k=n-2:-1:2,
    prev_y=y;
    y = x - y*q(k+1);  % these x and y solve the equation
    x = prev_y;        % x*r(k-1) + y*r(k)=1
end

if a<b, 
    cc=x; x=y; y=cc; % swap x and y
end

while x < 0, x = x + b; y = y - a; end
while x >=b, x = x - b; y = y + a; end

end