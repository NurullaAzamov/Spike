function d=order_of_element_of_Un(n,k)
% This function returns order d
% of an element k of the group U_n.
%

d=0;
prod=1;

for j=1:500,
    prod=mod(k*prod,n);
    if prod==1,
        d=j;
        return
    end
end

end