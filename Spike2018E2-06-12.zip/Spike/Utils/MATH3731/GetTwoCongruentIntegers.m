function [s,b]=GetTwoCongruentIntegers(opt)

n=1+randi(12);
a=10+randi(100);
b=randi(2)-1;
if b==0, c=a+n*(randi(23)-10)+randi(n-1);
else c=a+n*(randi(23)-10);
end
if opt==1,
  s=sprintf('$[%d]_{%d}=[%d]_{%d}$',a,n,c,n);
elseif opt==2,
  s=sprintf('$%d \\in [%d]_{%d}$',a,c,n);
elseif opt==3,
  s=sprintf('$\\congruent{%d}{%d}{%d}$',a,c,n);
elseif opt==4,
  b=~b;
  s=sprintf('$[%d]_{%d} \\cap[%d]_{%d} = \\emptyset$',a,n,c,n);
elseif opt==5,
  s=sprintf('$[%d]_{%d} \\subset [%d]_{%d}$',a,(randi(3)+1)*n,c,n);
end
end

