function k=get_an_element_of_Un(n)
% This function returns a random element
% of the group U_n.

k=1; 
while k==1,
    k=randi(n-1);
    k=k/gcd(n,k);
end
end