function [a,b] = Get_a_unit_of_domain(p)
% Given a prime number p this function returns
% a random pair of integers a and b such that 
% a + b*sqrt(p) is a unit of the integral domain Z[sqrt(p)].

for b=1:100,
    if IsNumberSquare(b^2*p-1),
        a=sqrt(b^2*p-1);
        return
    elseif IsNumberSquare(b^2*p+1),
        a=sqrt(b^2*p+1);
        return
    end
end
error('A unit has not been found.');

end