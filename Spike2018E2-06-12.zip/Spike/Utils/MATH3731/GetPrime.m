function [p,c]=GetPrime(k)
% This function returns in p
% a k digit prime and in c a k digit composite (k=3 or 4)
% which looks like a prime. 

k=k-1;

p=0; c=0;

while 1,
  x=10^k+2*randi((10^(k+1)-10^k)/2)+1;
  if mod(x,3)==0 || mod(x,5)==0 || mod(x,7)==0|| mod(x,5)==11,
      continue
  else
      if isprime(x),
          p=x;
      else
          c=x;
      end
  end
  if p~=0 && c~=0,
      break
  end
end

end