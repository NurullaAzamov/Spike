function [a,b,tf]=GetTwoCoprimeIntegers
% Returns a random pair of integers a and b.
% tf is true, if a and b are co-prime,
% otherwise tf is false. 

a=1; b=1;
while (a==1)||(b==1),
    a=randi(40)+10;
    b=randi(40)+10;
    c=gcd(a,b);
    a=a/c;
    b=b/c;
end

tf=(rand<0.5);

if ~tf,
    d=2*randi(3)+1;
    a=a*d;
    b=b*d;
end


end