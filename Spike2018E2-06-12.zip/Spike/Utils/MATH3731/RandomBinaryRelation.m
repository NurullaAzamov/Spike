function BR=RandomBinaryRelation(n)
% This function creates a random binary relation
% in a set of n elements. 

BR=randi(2,n,n)-1;
end

