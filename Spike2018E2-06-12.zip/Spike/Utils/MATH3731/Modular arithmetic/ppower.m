function c=ppower(a,n,p)
% This function calculates a^n
% modulo p, where p is a prime number.

% if ~isprime(p),
%     error('p is not prime.');
% end

if (mod(a,p)==0),
    if n==0,
        error('0^0 uncertainty.');
    else
        c=0;
        return
    end
end

% Using Fermat's theorem to simplify the power.
n=mod(n,p-1);

c=1;
for k=1:n,
    c=pmult(c,a,p);
end
end
