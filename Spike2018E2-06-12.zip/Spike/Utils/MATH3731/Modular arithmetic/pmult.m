function c=pmult(a,b,p)
% This function calculates c=a*b
% where a and b are elements of the field Z(p) with p elements,
% where p is a prime number.

c=mod(a*b,p);
end