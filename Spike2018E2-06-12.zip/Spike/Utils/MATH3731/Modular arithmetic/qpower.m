function c=qpower(a,n,p)
% This function calculates a^n
% modulo p, where p is a positive integer


if (mod(a,p)==0),
    if n==0,
        error('0^0 uncertainty.');
    else
        c=0;
        return
    end
end

if isprime(p),
    c=ppower(a,n,p);
    return
end

if n==1,
    c=a;
    return
elseif mod(n,2)==0,
    b=qpower(a,n/2,p);
    c=pmult(b,b,p);
    return
else 
    b=qpower(a,(n-1)/2,p);
    c=pmult(a,b*b,p);
    return
end

end
