function c=pdiv(a,b,p)
% This function calculates c=a*b^(-1)
% where a and b are elements of the field Z(p) with p elements,
% where p is a prime number.

b=mod(b,p);
[~,y]=gcdcoef(p,b);
c=mod(a*y,p);
end

