function b=IsNumberSquare(n)
% b is true if n is a square number,
% otherwise b is false.
b = ((floor(sqrt(n)))^2==n);
end