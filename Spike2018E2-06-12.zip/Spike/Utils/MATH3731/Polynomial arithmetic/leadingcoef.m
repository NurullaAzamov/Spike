function a=leadingcoef(f)

% Returns leading coefficient a_n of a polynomial f(x).

% Remove trailing zeros. 
k=length(f);
if k==0, 
    a=0; 
    return 
end
while f(k)==0, 
     k=k-1; 
     if k==0, break; end
end
a=f(k);

end