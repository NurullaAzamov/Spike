function c=polyprod(a,b,p)
% c is the product of polynomials a and b modulo p.
%

a=deblankpoly(a);
b=deblankpoly(b);

m=length(a); n=length(b);

c=zeros(1,m+n-1);

for k=1:m+n-1,
    c(k) = 0;
    for j=1:k,
        if (j<=m) && (k+1-j<=n),
            c(k) = c(k) + a(j)*b(k+1-j);
        end
    end
end

if p~=0,
  c=mod(c,p);
end

c=deblankpoly(c);

end