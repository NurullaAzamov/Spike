function b=IsReducible(f,p)
% Returns true if a polynomial f(x)=f0+f1*x+... of degree 2 or 3 from Z_p[x]
% is reducible.

b=0;
n=deg(f);
if (n~=2) && (n~=3), 
    error('Degree should be 2 or 3.');
end
for x=0:p-1,
    if PolyEval(f,x,p)==0,
        b=1;
        return
    end
end
end