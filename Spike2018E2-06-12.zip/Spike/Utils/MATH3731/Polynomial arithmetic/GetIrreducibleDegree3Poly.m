function [f,g]=GetIrreducibleDegree3Poly(p)
% Returns in f a random degree three irreducible polynomial from Z_p[x]. 
% g is a random reducible polynomial.


g=0; f=0;
for j=1:100,
    h=randi(p,1,4)-1;
    h(4)=randi(p-1);
    h(1)=randi(p-1);
    if IsReducible(h,p),
        g=h; 
    else
        f=h; 
    end
    if (length(g)~=1) && (length(f)~=1),
        return
    end
end
error('Failure.');

end