function [GCD,x,y]=polygcdcoef(a,b,p)
% This function finds GCD of a and b, and a solution 
% of the equation a*x+b*y = gcd(a,b),
% where a,b,x,y are polynomials from the polynomial ring Z_p[.].
% Usage: [x,y]=polygcdcoef(a,b). 

% Taking care of some special cases.
if (deg(a)<0) && (deg(b)<0), 
     error('At least one polynomial must be non-zero.'); 
end

% We expect that the polynomials a and b have degree < 10.
if (deg(a)>=10) || (deg(b)>=10), 
     error('Degree is too big, sorry.'); 
end

% We expect that the number of divisions in 
% the Euclidean algorithm will not exceed 300. 
Max_number_of_divisions=300;
r=zeros(Max_number_of_divisions,10);
q=zeros(Max_number_of_divisions,10);
n=-999;
% Applying the Euclidean algorithm to find gcd of a and b.
r(1,1:length(a)) = a; r(2,1:length(b)) = b;

for k=3:Max_number_of_divisions, 
    [qq,rr]=DART(r(k-2,:),r(k-1,:),p);
    r(k,1:length(rr)) = rr;
    q(k,1:length(qq)) = qq;
    if deg(r(k,:)) == -1, 
        n=k; 
        GCD=r(k-1,:);
        break
    end
end

if n==-999, error('Error!!!'); end

GCD=deblankpoly(GCD);

% Reversing back the Euclidean algorithm. 
x=1;      % these x and y solve the equation
y=-q(n-1,:); % x*r(n-3)+y*r(n-2)=gcd.

for k=n-3:-1:2,
    prev_y=y;
    y = polysum(x, -polyprod(y,q(k+1,:),p),p);  % these x and y solve the equation
    x = prev_y;        % x*r(k-1) + y*r(k)=1
end

gcd2=polysum(polyprod(a,x,p),polyprod(b,y,p),p);
diff=polysum(GCD,-gcd2,p);

if deg(diff)~=-1,
    cc=x; 
    x=y;
    y=cc;
    gcd2=polysum(polyprod(a,x,p),polyprod(b,y,p),p);
    diff=polysum(GCD,-gcd2,p);
    if deg(diff)~=-1,
        error('Not OK.')
    end
end

an=leadingcoef(GCD);
invan=pdiv(1,an,p);
GCD=polyprod(invan,GCD,p);  % Now GCD is a monic polynomial.

x=polyprod(invan,x,p);
y=polyprod(invan,y,p);

end