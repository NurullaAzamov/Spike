function a=monicassoc(f,p)

% Returns monic associate of a polynomial f(x) from Z_p[x].

b=leadingcoef(f);
c=pdiv(1,b,p);
a=polyprod(c,f,p);

end