function [f,g]=GetIrreducibleDegree2Poly(p)
% Returns in f a random degree two irreducible polynomial from Z_p[x]. 
% g is a random reducible polynomial.


g=0; f=0;
for j=1:100,
    h=randi(p,1,3)-1;
    h(3)=randi(p-1);
    h(1)=randi(p-1);
    if IsReducible(h,p),
        g=h; 
    else
        f=h; 
    end
    if (length(g)~=1) && (length(f)~=1),
        return
    end
end
error('Failure.');

end