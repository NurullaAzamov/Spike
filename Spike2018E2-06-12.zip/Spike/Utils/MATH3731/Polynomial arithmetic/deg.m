function n=deg(f)
% Returns degree n of polynomial f(x).
% n = -1, if f(x) = 0.

% Remove trailing zeros. 
k=length(f);
while f(k)==0, 
     k=k-1; 
     if k==0, break; end
end
n=k-1;

end