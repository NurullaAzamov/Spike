function f=monomial(an,n)

% Returns the monomial a_n*x^n.

if n<0, error('monomial'); end

f=zeros(1,n+1);
f(n+1) = an;

end