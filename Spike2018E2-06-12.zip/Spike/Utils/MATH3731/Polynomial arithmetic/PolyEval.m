function y=PolyEval(a,x,p)
% y is the value of a polynomial f(x) = a0+a1*x+a2*x^2+...
% given by vector a=(a0,a1,a2,...) at point x. 

n=deg(a);
if n<0, 
    y=0;
    return
end
y=a(1);
for j=2:n+1,
    y=y+a(j)*ppower(x,j-1,p);
    y=mod(y,p);
end

end