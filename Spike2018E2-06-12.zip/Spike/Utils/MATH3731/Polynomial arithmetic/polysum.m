function c=polysum(a,b,p)
% c is the sum of polynomials a and b modulo p.
%

m=length(a); n=length(b);

if m>=n,
    c=a;
    for k=1:n,
        c(k)=c(k)+b(k);
    end
else
    c=b;
    for k=1:m,
        c(k)=c(k)+a(k);
    end
end

if p~=0,
  c=mod(c,p);
end

c=deblankpoly(c);

end