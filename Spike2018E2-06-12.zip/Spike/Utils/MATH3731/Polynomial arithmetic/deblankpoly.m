function a=deblankpoly(f)

% Removes trailing zeros from f(x).

k=length(f);
if k==0, 
    return 
end
while f(k)==0, 
     k=k-1; 
     if k==0, 
         a=0;
         return
     end
end
a=f(1:k);

end