function [q,r]=DART(f,g,p)
% Returns the Division Algorithm representation 
% for a pair of polynomials f(x), g(x) from Z_p[x].
%

if deg(f) < deg(g),
    q=0;
    r=f;
    if p~=0,
        r=mod(r,p);
    end
    return
end

degg=deg(g);
degq=deg(f)-degg;
q=zeros(1,degq+1);
b=leadingcoef(g);

for j=degq+1:-1:1,
    if deg(f) < degg,
        r=f;
        return
    end
%     if degg+j > length(f), 
%         disp('DART error');
%         disp('f=');
%         disp(f);
%         disp('deg(g)=');
%         disp(degg);
%         disp('deg(q)=');
%         disp(degq);
%         disp('j=');
%         disp(j);
%     end
    if degg+j > length(f),
        continue
    end
    a=f(degg+j);
    if a==0,
        continue
    else
        q(j) = pdiv(a,b,p);
        h=monomial(q(j),j-1);
        f=polysum(f,-polyprod(g,h,p),p);
    end
end

r=f;
if p~=0,
    r=mod(r,p);
end

end