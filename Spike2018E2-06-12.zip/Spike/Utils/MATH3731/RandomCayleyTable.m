function CT=RandomCayleyTable(n)
% This function creates a random Cayley table
% of size n times n. That is, a Cayley table of 
% a randomly chosen binary operation in the set {1,...,n}.
%

CT=zeros(n,n);
for j=1:n,
    for k=1:n,
        CT(j,k)=randi(n);
    end
end
end

