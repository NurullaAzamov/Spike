function [a,c,n,tf]=GetCongruentInts

n=1+randi(12);
a=30+randi(100);
tf=randi(2)-1;
c=a+n*(randi(23)-10);
if tf==0, 
    c=c+randi(n-1);
end
end

