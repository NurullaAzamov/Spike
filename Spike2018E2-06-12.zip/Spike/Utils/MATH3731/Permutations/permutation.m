classdef permutation
    
    properties 
        array
        len
    end
    
    methods

        function perm=permutation(n)
            perm.array=1:n;
            perm.len=n;
        end % constructor permutation
        
        function perm=getrand(perm,n)
            a=randperm(n);
            perm.array=a;
            perm.len=n;
        end % function getrand
        
        function perm=inverse(perm)
            n=perm.len;
            b=zeros(1,n);
            for j=1:n,
                b(perm.array(j)) = j;
            end
            perm.array=b;
        end
        
        function prod=product(perm,b)
            % multiply permutation perm by permutation b.
            if perm.len~=b.len,
                error('Different size permutations.');
            end
            c=zeros(1,perm.len);
            for j=1:perm.len,
                c(j)=perm.array(b.array(j));
            end
            prod=permutation(perm.len);
            prod.array=c;
            prod.len=perm.len;
        end
        
        function [A,s]=toCycleProd(perm)
            % This function returns cycles of a permutation a.
            % The cycles are returned in rows of the matrix A.
            % s is a vector which contains lengths of the cycles.
            
            n=perm.len;
            a=perm.array;
            b=zeros(1,n);
            s=zeros(1,n);
            A=zeros(n,n); % this matrix will contain cycles of the permutation a.
            for j=1:n,
                if prod(b)==1,
                    break
                end
                for k=1:n,
                    if b(k) ==0,
                        % k is the first element of j-th cycle.
                        m=1;
                        A(j,m)=k;
                        b(k)=1;
                        while b(a(A(j,m)))==0,
                            A(j,m+1)=a(A(j,m));
                            b(A(j,m+1))=1;
                            m=m+1;
                            if m>n,
                                error('Something wrong.');
                            end
                        end
                        s(j)=m;
                        break
                    else
                        continue
                    end
                end
            end
            A=A(1:j-1,:);
            s=s(1:j-1);
        end % function toCycleProd
        
        function d=order(perm)
            [~,s]=toCycleProd(perm);
            d=1;
            for j=1:length(s),
                d=lcm(d,s(j));
            end
        end % function order
        
        function sign=parity(perm)
            [~,s]=toCycleProd(perm);
            sign=(-1)^(length(s)+sum(s));
        end % function parity

        function sa=toLaTeX(perm)
            % This function returns a string
            % which contains a permutation a in LaTeX format.
            
            n=perm.len;
            ccc=char(ones(1,n)*'c');
            S='\left(\begin{array}{';
            S=sprintf('%s%s}',S,ccc);
            for j=1:n-1
                S=[S,sprintf('%d&',j)];
            end
            S=[S,sprintf('%d\\\\',n)];
            for j=1:n-1
                S=[S,sprintf('%d&',perm.array(j))];
            end
            S=[S,sprintf('%d',perm.array(n))];
            
            sa=[S,'\end{array}\right)'];
            
        end
        
        function sa=toLaTeX_as_CycleProduct(perm)
            % This function returns cycle product representation of a permutation a
            % in LaTeX format.
            [A,s]=toCycleProd(perm);
            sa='';
            for j=1:length(s),
                ss='';
                for k=1:s(j),
                    ss=sprintf('%s%d',ss,A(j,k));
                end
                sa=sprintf('%s(%s)',sa,ss);
            end
        end
        
        function sa=toLaTeX_as_ShortCycleProduct(perm)
            % This function returns cycle product representation of a permutation a
            % in LaTeX format. The difference with Perm2CycleProdLaTeX(a)
            % is that this function omits trivial length one cycles.
            
            [A,s]=toCycleProd(perm);
            sa='';
            for j=1:length(s),
                if s(j)==1,
                    continue
                end
                ss='';
                for k=1:s(j),
                    ss=sprintf('%s%d',ss,A(j,k));
                end
                sa=sprintf('%s(%s)',sa,ss);
            end
            
        end
        
        function perm=randprodcycles(perm,s)
            % This function returns a permutation a
            % which is the product of random disjoint cycles
            % of lengths s(1),s(2),...
            
            
            n=sum(s);
            b=randperm(n);
            a=zeros(1,n);
            lens=length(s);
            ss=zeros(1,lens);
            for k=1:lens,
                ss(k)=sum(s(1:k));
            end
            for j=1:n,
                if ~ismember(j,ss),
                    a(b(j))=b(j+1);
                else
                    m=find(ss==j);
                    if m>1,
                        a(b(j))=b(ss(m-1)+1);
                    else
                        a(b(j))=b(1);
                    end
                end
            end
            perm.len=n;
            perm.array=a;
        end
        
    end % methods
    
    
end
