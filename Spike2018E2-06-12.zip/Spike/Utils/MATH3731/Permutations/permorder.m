function d=permorder(a)

[~,s]=Perm2CycleProd(a);
d=1;
for j=1:length(s),
    d=lcm(d,s(j));
end
end