function c=permprod(a,b)
% This function calculates product of two permutations:
% c=a*b.

n=length(a);
m=length(b);
if m~=n,
    error('Different size permutations.');
end
c=zeros(1,n);
for j=1:n,
    c(j)=a(b(j));
end

end
