function [A,s]=Perm2CycleProd(a)
% This function returns cycles of a permutation a. 
% The cycles are returned in rows of the matrix A.
% s is a vector which contains lengths of the cycles. 

n=length(a);
b=zeros(1,n);
s=zeros(1,n);
A=zeros(n,n); % this matrix will contain cycles of the permutation a. 
for j=1:n,
    if prod(b)==1, 
        break
    end
    for k=1:n,
        if b(k) ==0,
            % k is the first element of j-th cycle.
            m=1;
            A(j,m)=k;
            b(k)=1;
            while b(a(A(j,m)))==0,
                A(j,m+1)=a(A(j,m));
                b(A(j,m+1))=1;
                m=m+1;
                if m>n,
                    error('Something wrong.');
                end
            end
            s(j)=m;
            break
        else
            continue
        end
    end
end
A=A(1:j-1,:);
s=s(1:j-1);

end
