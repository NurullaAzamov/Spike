Unfinished
function f=permprod2(a,b,c)
% This function calculates product of two or three permutations:
% f=a*b or f = a*b*c, depending on the number of arguments.

n=length(a);
m=length(b);
if m~=n,
    error('Different size permutations.');
end

d=zeros(1,n);

for j=1:n,
    d(j)=a(b(j));
end

if nargin>2,
    p=length(c);
    if m~=p,
        error('Different size permutations.');
    end
    f=zeros(1,n);
    
    for j=1:n,
        f(j)=d(c(j));
    end
else 
    f=d;
end


end
