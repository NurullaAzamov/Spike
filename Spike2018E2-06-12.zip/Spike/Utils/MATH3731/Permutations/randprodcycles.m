function a=randprodcycles(s)
% This function returns a permutation a
% which is the product of random disjoint cycles 
% of lengths s(1),s(2),...


n=sum(s);
b=randperm(n);
a=zeros(1,n);
lens=length(s);
ss=zeros(1,lens);
for k=1:lens,
    ss(k)=sum(s(1:k));
end
for j=1:n,
    if ~ismember(j,ss),
        a(b(j))=b(j+1);
    else
        m=find(ss==j);
        if m>1,
            a(b(j))=b(ss(m-1)+1);
        else
            a(b(j))=b(1);
        end
    end
end

end