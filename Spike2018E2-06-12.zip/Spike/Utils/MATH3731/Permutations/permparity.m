function sign=permparity(a)

[~,s]=Perm2CycleProd(a);
sign=(-1)^(length(s)+sum(s));
end