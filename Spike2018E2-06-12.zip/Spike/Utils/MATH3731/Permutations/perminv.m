function b=perminv(a)
% This function calculates inverse of a permutation a:
% b=a^(-1).

n=length(a);
b=zeros(1,n);
for j=1:n,
    b(a(j)) = j;
end

end
