function Grade=Mark2Grade(Mark)

if Mark<45,
    Grade='F';
elseif Mark<50,
    Grade='F/A';
elseif Mark<65,
    Grade='P';
elseif Mark<75,
    Grade='CR';
elseif Mark<85,
    Grade='DN';
else
    Grade='HD';
end


end