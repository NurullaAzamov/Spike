function S = BinaryRel2LaTeX(A,op,elem)
% sLaTeXCayleyTable(A) returns a string 
% which represents the matrix A with 0/1 entries 
% in LaTeX format as a true-false table. 
% 
% op is the operation given as a string in LaTeX format,
% elem is the finite set of elements in which the binary operation is
% given.

    function s=type_a_row(a)
    % This function returns in LaTeX format
    % the row a; for example, if a=[1,0,1], then 
    % type_a_row(a) returns
    % T & F & F \\
      s='';
      for jj=1:n,
          s=sprintf('%s&%c',s,FT(a(jj)+1));
      end
    end

FT='FT';

[~,n]=size(A);
S='\begin{tabular}{|c||';
for j=1:n, 
    S=sprintf('%sc|',S); 
end
S=sprintf('%s}%c  \\hline %s ',S,char(13),op);
for j=1:n, 
    S=sprintf('%s&%s',S,elem(j)); 
end
S=sprintf('%s\\\\%c  \\hline%c  \\hline',S,char(13),char(13));

for i=1:n
    S=sprintf('%s %s %s\\\\%c  \\hline', S, elem(i), type_a_row(A(i,:)),char(13));
end
S=sprintf('%s%c\\end{tabular}',S,char(13));
end


