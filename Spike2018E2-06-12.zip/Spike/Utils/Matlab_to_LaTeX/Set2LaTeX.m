function s=Set2LaTeX(a,option)
% This functions returns LaTeX 
% form of a set given by a vector a.
%
% option = 0: write elements of a in a given order with repetitions.
% option = 1: write elements of a in increasing order without repetitions.
% option = 2: write elements of a in increasing order with repetitions.

n=length(a);
ZERO = 10^(-10);

sorted=sort(a);
neated=sorted(1);
for j=2:n,
    if sorted(j)>sorted(j-1) + ZERO,
        neated=[neated,sorted(j)];
    end
end

if option ==0, 
elseif option==1,
    a = neated;
elseif option ==2, 
    a = sorted;
else 
    error('Set2LaTex: unknown option');
end

n=length(a);

s=sprintf('%s',LaTeXFrac(a(1)));
for j=2:n,
    s = sprintf('%s,%s',s,LaTeXFrac(a(j)));
end
s=sprintf('\\set{%s}',s);

end