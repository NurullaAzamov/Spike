function s=num2roman(n)
% Converts an arabic numeral n to a roman numeral.

    function ss=R(k,ivx)
        if k==1, ss=ivx(1);
        elseif k==2, ss=[ivx(1),ivx(1)];
        elseif k==3, ss=[ivx(1),ivx(1),ivx(1)];
        elseif k==4, ss=[ivx(1),ivx(2)];
        elseif k==5, ss=ivx(2);
        elseif k==6, ss=[ivx(2),ivx(1)];
        elseif k==7, ss=[ivx(2),ivx(1),ivx(1)];
        elseif k==8, ss=[ivx(2),ivx(1),ivx(1),ivx(1)];
        elseif k==9, ss=[ivx(1),ivx(3)];
        elseif k==0, ss='';
        else error('k is wrong');
        end
    end

if n>3999,
    error('n is too big');
end

s=[R(mod(floor(n/1000),10),'M'),R(mod(floor(n/100),10),'CDM'),R(mod(floor(n/10),10),'XLC'),R(mod(n,10),'IVX')];

end