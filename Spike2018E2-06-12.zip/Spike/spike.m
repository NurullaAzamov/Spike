% Spike, version 2018 E2, 05/07/2018.
% Author: Nurulla Azamov, Flinders University 2014.
%
% AVOID CONFLICT OF FUNCTIONS! (FROM OTHER FOLDERS).
%
% Usage: spike(TopicCode,AssNum)
%     or spike(TopicCode,AssNum,NVers),
%     or spike(TopicCode,AssNum,NVers,OPTION).
%
% Examples: >>spike('MATH3701',2)
%           >>spike('MATH2722',3,3)
%           >>spike('MATH3712',4,1,1)
%
% Input: 
%    TopicCode, an 8-symbol topic code.
%    AssNum, assignment number or 'E' (for exam papers).
%    NVers,  assignment version number. The default value of NVers is 1.
%
%    OPTION,    option, if option==1, then spike ignores the top-file,
%               otherwise it doesn't. The default value of OPTION is 0.
%
%    To run spike, there must be three files: 
%      (a) Topfile, 
%          this is a file the content of which spike copies 
%          into the beginning of the output. 
%          Topfile may also contain some Matlab commands to be executed 
%          before the spike-code.
%      (b) TopicCodeAn.spk,
%          this is a file with a spike-code. Here n from An 
%          is the assignment number. For example, this file 
%          can have names such as MATH3701A2.spk, MATH2722A3.spk, 
%          MATH3712A4.spk
%      (c) StudList.txt, 
%          this is a file with a list of student ID's 
%          enrolled in the topic. The file StudList.txt is 
%          kept in the topic folder TopicCode.
%          This file may look as follows:
%
%          2071253 
%          2022880 
%          2095220 
%          2119922 
%          2107080 
%          -------
%
% Output: 
%   a LaTeX file with an assignment. 
%   This output LaTeX file is saved in the folder Prelim\, 
%   a subfolder of the topic folder.
%   The saved output file is also copied into a LaTeX folder Assignments\
%   or, if such a folder does not exist, it is 
%   opened in Matlab's editor.
%
%  If AssNum='E' and NVers is an even number, then spike 
%  considers the exam paper as supplementary. 
%
% For more help see Spike's manual available online
% at www.arxiv.org 

function spike(TopicCode,AssNum,NVers,OPTION)

fprintf('spike, version 2018 E2, 05/07/2018, by Nurulla Azamov\n');
fprintf('Flinders University, Adelaide, Australia, 2014.\n\n');

currfolder=pwd;
if length(currfolder)<6 || ~strcmp(currfolder(end-5:end),'\Spike'),
    fprintf('Error: to run spike the current folder is to be \\Spike.\n');
    fprintf('Please change the folder and run spike again.\n');
    return    
end

if nargin<4,
    OPTION=0; % default value of OPTION variable.
end

% There are two types of variables, let's call them external and 
% internal. External variables are those which can be defined and 
% modified by Spike's user, internal variables are those which are
% necessary for inner workings of Spike. The external variables
% will be kept in the base workspace of Matlab, so we have to work 
% with them through Matlab's "evalin" function.

if OPTION,
    evalin('base','ANSWER_ATTEMPTS=80;');
    evalin('base','ANS_ATTEMPTS=10;');
    evalin('base','MIN_RAW_VOLUME=200;');
    evalin('base','DestFolder=''NoFolder'';');
end

TopicCode=upper(TopicCode);

if length(TopicCode) < 5,
    error('Topic code must have at least 5 characters')
end

WrongTopicCode=TopicCode;
% This is for instructing students how not to wrongly submit assignmemts.
if TopicCode(5)=='3',
    WrongTopicCode(5)='2';
else
    WrongTopicCode(5)='3';
end

% Save current workspace in a temporary file.
evalin('base', 'save ''temp.mat''');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization of certain parameters.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MAX_NUMBER_OF_QUESTIONS=80;

% The variables NRepeat, NAltAns and PercentMarks
% have global analogues. While the former variables 
% can be overridden in spk-files, 
% the global analogues override values set in spk-files.

% Proportion of total assessment, which this assignment constitutes.
% By default, it is 10% 
evalin('base','PercentMarks=10;');

% Assignment due date.
% By default, it is 'to be announced'. 
evalin('base','duedate=''TBA'';');

% How many times to repeat each test question.
% By default, only once.  
evalin('base','NRepeat=1;'); 
evalin('base','GlblNRepeat='''';'); 

% Number of alternative multiple choice answers.
% By default, it is 5. 
evalin('base','NAltAns=5;'); 
evalin('base','GlblNAltAns='''';'); 

evalin('base','GlblWeight='''';'); 

% Random seed. This value is overridden in top-file.
evalin('base','rseed=247;');

% currdir=cd;
% cd('\\userab\a\azam0001\DriveH\Documents\MATLAB\Spike');

% Counter of log-file warnings. 
evalin('base','LogWarnings=0;');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization of topic data. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
try 
  Topic=topic(TopicCode);
catch ME
    GeneralError(ME);
    return
end

if nargin < 3, 
    NVers=1; % default value of Version number.
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Creating the output-latex file and the log file 
% and opening them for writing.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
try
    OutFile=sprintf('%s\\Prelim\\',Topic.code);
    LogFile=sprintf('%s\\Logs\\',Topic.code);
catch ME
    GeneralError(ME);
    return
end

IsAssignment=1911;
IsExam=2212;

if isnumeric(AssNum),
    % DocType is a boolean variable with values 'Assignment' and 'Exam'.
    DocType=IsAssignment;
    OutFile=sprintf('%sA%dV%d.tex',OutFile,AssNum,NVers);
    LogFile=sprintf('%sA%dV%d.log',LogFile,AssNum,NVers);
else
    DocType=IsExam;
    OutFile=sprintf('%sExV%d.tex',OutFile,NVers);
    LogFile=sprintf('%sExV%d.log',LogFile,NVers);
end

% TopicAmVn is something like 'MATH2712A2V1'
if DocType==IsAssignment
    TopicAmVn=sprintf('%sA%dV%d',Topic.code,AssNum,NVers);
elseif DocType==IsExam 
    TopicAmVn=sprintf('%sExV%d',Topic.code,NVers);
else
    error('Wrong assignment number parameter.');
end


OutF=fopen(OutFile,'w'); % the LaTeX output file
LogF=fopen(LogFile,'w'); % the log-file

if OutF~=-1,
    fprintf('Warning: the file \\%s already exists.\n',OutFile);
    fprintf('If it is a final version of assignment, it is recommended to\n');
    fprintf('save its copy somewhere else (say, in the folder Final\\).\n\n');
    fprintf('Press space-bar to continue and overwrite the existing ');
    fprintf('file\nor terminate this program by [Ctrl+Pause].\n\n');
    pause;
end

if ~OPTION,
    fprintf(OutF,'%% This file was generated on ');
    fprintf(OutF,'%s by spike, version 2018 E2, 05/07/2018.\n',date);
    fprintf(OutF,'%% Computer type: %s\n',computer);
    fprintf(OutF,'%% Matlab version: %s\n',version);
end

fprintf(LogF,'%% This log-file was generated on ');
fprintf(LogF,'%s by spike, version 2018 E2, 05/07/2018.\n',date);
fprintf(LogF,'%% Computer type: %s\n',computer);
fprintf(LogF,'%% Matlab version: %s\n\n',version);

if DocType==IsExam
    fprintf('\n\nReminder:    ');
    if NVers==1 || NVers==3
        fprintf('NVers=%d, -- main exam paper', NVers);
    elseif NVers==2 || NVers==4
        fprintf('NVers=%d, -- supp exam paper', NVers);
    elseif NVers==5 || NVers==7 || NVers==9
        fprintf('NVers=%d, -- GE exam paper', NVers);
    elseif NVers==6 || NVers==8
        fprintf('NVers=%d, -- supp GE exam paper', NVers);
    end
    fprintf('\n\n');
end

if  DocType==IsExam
    Topic.NStud=1;
    fprintf('Preparing version %d of the exam paper:\n',NVers);
else 
    fprintf('Preparing version %d of the assignment:\n',NVers);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization of assignment data.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Asst=assignment(Topic,AssNum);

if DocType==IsAssignment,
    TopF=fopen('topfile.tex');
elseif DocType==IsExam,
    TopF=fopen('examtopfile.tex');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Processing the Matlab part of the top-file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~OPTION,
    
    % Process MATLAB commands given in the top-file,
    % until the line \documentclass.
    % These commands may for instance change some constants.
    while ~feof(TopF),
        ss=fgetl(TopF);
        % skip empty lines and comments
        if isempty(ss) || (ss(1) =='%'),
            continue
        end
        
        if StrCmp(ss,'\documentclass'),
            fprintf(OutF,'%s\n',ss);
            break
        else
            % if a line of the Matlab part of the top-file
            % is not a comment, then try to execute it.
            %'duedate:' commands need special treatment.
            if StrCmp(ss,'duedate:'),
                [ass_number,DueDate]=strtok(ss(9:end),'=');
                if strcmp(ass_number,TopicAmVn),
                    evalin('base',['duedate',DueDate]);
                end
            elseif StrCmp(ss,'PercentMarks:'),
                [ass_number,MARKS]=strtok(ss(14:end),'=');
                if strcmp(ass_number,TopicAmVn),
                    evalin('base',['PercentMarks',MARKS]);
                end
            else
                try
                    evalin('base',ss);
                catch ME
                    fprintf(LogF,'\n\nSpike: ERROR in top-file.');
                    fprintf(LogF,'\n%s\n\n',ss);
                    fprintf(LogF,'%s\n',ME.identifier);
                    fprintf(LogF,'%s\n',ME.message);
                    evalin('base','LogWarnings=LogWarnings+1;');
                    
                    % Delete the current workspace
                    % and restore the old workspace.
                    evalin('base', 'clear');
                    evalin('base', 'load ''temp.mat''');
                    delete 'temp.mat'
                    
                    LogWarnings=evalin('base','LogWarnings');
                    fprintf(LogF,'Number of warnings: %d.\n',LogWarnings);
                    edit(LogFile);
                    return
                end
            end
        end
        
        if feof(TopF),
            error('In top-file "\documentclass" is expected.');
        end
    end

    Asst.duedate=evalin('base','duedate');
    Asst.pmark=evalin('base','PercentMarks');
    Asst.rseed=evalin('base','rseed');
    
    if evalin('base','NAltAns > 8'),
        error('The value of NAltAns should not exceed 8.');
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Processing the LaTeX part of the top-file.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    while ~feof(TopF),
        ss=fgetl(TopF);
        
        if StrCmp(ss,'-------'),
            break
        end
        
        if StrCmp(ss,'%EOF'),
            break
        elseif StrCmp(ss,'\begin{document}'),
            fprintf(OutF,'\\newcommand{\\topiccode}{%s}\n',Topic.code);
            fprintf(OutF,'\\newcommand{\\wrongtopiccode}{%s}\n',WrongTopicCode);
            fprintf(OutF,'\\newcommand{\\topicname}{%s}\n',Topic.name);
            fprintf(OutF,'\\newcommand{\\Version}{%d}\n',NVers);
            if isnumeric(Asst.number),
                fprintf(OutF,'\\newcommand{\\NAss}{%d}\n',Asst.number);
                fprintf(OutF,'\\newcommand{\\WrongNAss}{%d}\n',mod(Asst.number,4)+1);
            else
                fprintf(OutF,'\\newcommand{\\NAss}{Exam Paper}\n');
            end
            fprintf(OutF,'\\newcommand{\\Year}{%d}\n',Asst.year);
            fprintf(OutF,'\\newcommand{\\Semester}{%d}\n',Asst.semester);
            
            fprintf(OutF,'\\newcommand{\\DueDate}{%s}\n',Asst.duedate);

            fprintf(OutF,'\\newcommand{\\PercentMarks}');
            fprintf(OutF,'{%d}\n',Asst.pmark);
            
            if AssNum=='E', 
                if mod(NVers,2)==1,
                    fprintf(OutF,'\\newcommand{\\supplementary}{}\n');
                else 
                    fprintf(OutF,'\\newcommand{\\supplementary}{Supplementary\\ }\n');
                end
                if NVers >= 5,
                    GE_topiccode=Topic.code;
                    GE_topiccode(5)='8';
                    fprintf(OutF,'\\renewcommand{\\topiccode}{%s}\n',GE_topiccode);
                    fprintf(OutF,'\\renewcommand{\\topicname}{%s GE}\n',Topic.name);
                end
            end
        end
        
        fprintf(OutF,'%s\n',deblank(ss));
    end
    
    fprintf(OutF,'%% End of top file.\n');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % End of processing of the top-file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Processing the spike-file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AnsString = char(ones(Topic.NStud,MAX_NUMBER_OF_QUESTIONS)*' ');
EmptyString = char(ones(1,MAX_NUMBER_OF_QUESTIONS)*' ');
Questns = EmptyString;
Weights = EmptyString;
QuesTypes = EmptyString;
NumAltAnswers = EmptyString;
Repeats=zeros(1,MAX_NUMBER_OF_QUESTIONS);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start the main cycle
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf(OutF,'\\catcode`@=11\n');

% This is a cycle of assignments.

CQues=0;  

for n_00 = 1:Topic.NStud,

    CurrAnsString=EmptyString;
    CurrAnsPtr=0;

    % Prepare an assignment for nth student.
    fprintf('Variant %d: ',n_00);
    
    % Open spk-file for reading again.
    spkfile=fopen(Asst.SpkFile);
    if spkfile==-1,
        fprintf('Spike: Error 140.\n');
        fprintf('The file %s is not found.\n',Asst.SpkFile);
        return
    end
    
    % Initialize
    NSpkLn=0;    % current string in spk-file.
    CQues=0;  % current MC question.
    
    % ID length, usually 7.
    ID_LEN=Topic.ID_LENGTH;
    
    if DocType==IsAssignment,
        fprintf(OutF,'\n\\newpage\n');
        fprintf(OutF,'\\renewcommand{\\@oddhead}{{\\small ');
        fprintf(OutF,'{\\sf %s \\ ',TopicAmVn);
        fprintf(OutF,' %d \\ Semester %d}\n',Asst.year,Asst.semester);
        fprintf(OutF,'\\quad \\hfil {\\sf Student ID: ****');
        fprintf(OutF,'%s}}}\n',Topic.StudList(n_00,ID_LEN-2:ID_LEN));
    end
    
    fprintf(OutF,'\\setcounter{nques}{0}\n\n');

    % This is a cycle of problems in an assignment.
    while true,
        
        % Read a spike-block, constructor
       
        SB=spikeblock; 
        SB=SB.readspikeblock(spkfile,NSpkLn,OutF,LogF,   CQues+1,n_00,NVers);        

        NSpkLn=SB.EndLn;
        
        if strcmp(SB.status,'error'), 
            return
        elseif strcmp(SB.status,'EOF') || feof(spkfile), 
            break
        end
        
        
        % Current Student ID
        StudID=str2double(Topic.StudList(n_00,1:ID_LEN));
        
        % Random Seed depends only on
        %   (1) year
        %   (2) semester
        %   (3) StudId
        %   (4) Question number
        %   (5) Assignment version number
        %   (6) and the variable rseed, predefined in the top-file. 
        RandSeed=59*Asst.year+83*Asst.semester+53*Asst.rseed;
        RandSeed=RandSeed+89*StudID+37*CQues;
        
        % The point of this code is to ensure that 
        % the MCP parts of exam papers for a topic
        % and its GE version are the same. 
        if DocType==IsExam
            RandSeed=RandSeed+97*mod(NVers,2);
        else
            RandSeed=RandSeed+97*NVers;
        end
       
        Q='';
            %%%%%%%%%%%%%%%%%%  text  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if strcmp(SB.Cmd,'text'),
            QQ=textblock(SB);
            QQ.ProcessTxtPt;

            %%%%%%%%%%%%%%%%%%  data  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        elseif strcmp(SB.Cmd,'data'),
            rng(RandSeed);
            QQ=datablock(SB);
            QQ.ProcessCmdPt;
            %%%%%%%%%%%%%%%%%%  problem Z (void) %%%%%%%%%%%%%%%%%%%%%%%%%%
        elseif strcmp(SB.Cmd,'problemZ'),
            % in this case do nothing
        elseif strcmp(SB.Cmd,'problemV') && SB.Version>1,
            % in this case also do nothing
            % (we don't want to give a verbatim type question twice)
            %%%%%%%%%%%%%%%%  problems A,B,D,I,R,T,G,H,V  %%%%%%%%%%%%%%%%%
        else
            % Constructor
            Q=eval(sprintf('%s(SB)',SB.Cmd));
        end
        %%%%%%%%%%%  End of spike block <<...>>  processing %%%%%%%%%%%%%%%
        
        if isempty(Q),
            %disp(SB);
            %error('Failed to initialise a spike-block');
        else

            CQues=CQues+1;

            Q=Q.SetRandSeed(RandSeed);
            
            Q=Q.Execute;
            
            CurrAnsString(CurrAnsPtr+1:CurrAnsPtr+Q.NRepeats)=Q.CorrAns;
            CurrAnsPtr = CurrAnsPtr+Q.NRepeats;
            
            if n_00==1,
                
                Questns(CQues) = char('0'+mod(CQues,10));
                
                Weights(CQues)=char(Q.Weight+'0');
                
                QuesTypes(CQues)=Q.Type;

                NumAltAnswers(CQues) = char(Q.NAltAnswers+'0');
                
                Repeats(CQues) = Q.NRepeats;
            end
            
        end

    end % while true
    
    AnsString(n_00,:)=CurrAnsString;
    
    fprintf(OutF,'%%===============================================\n');
    fclose(spkfile);
    fprintf('  done.\n');
    
end % for n_00


% if DocType==IsAssignment,
%     fprintf(OutF,'\n\\newpage\n');
%     fprintf(OutF,'\\renewcommand{\\@oddhead}{}\n');
%     fprintf(OutF,'\\mbox{ }\\vskip 10 cm\\small\\noindent\n');
%     fprintf(OutF,'This file has been generated by \\Spike,');
%     fprintf(OutF,' a free Matlab\nbased software for generating');
%     fprintf(OutF,' randomised multiple choice \n');
%     fprintf(OutF,'questions in mathematics, physics');
%     fprintf(OutF,' and engineering subjects.\n\n');
%     fprintf(OutF,'\\bigskip\\noindent\n');
%     fprintf(OutF,'\\Spike''s user''s manual is available');
%     fprintf(OutF,' on \\verb!www.arxiv.org!.\n\nUser''s manual ');
%     fprintf(OutF,'also explains how to obtain \\Spike.\n');
% end


if DocType==IsExam && ~OPTION,
    fprintf(OutF,'\\vskip 1.5 cm\n');
    fprintf(OutF,'{\\bf Written part.}\n');
    fprintf(OutF,'\\bigskip\\medskip\n\n');
    
    ss=FindLineInExamFile('FileWithExamQuestions=',TopF);
    ss=strrep(ss,'\','\\');
    examfile=sprintf(ss,Asst.semester,TopicCode,TopicCode);

    startstring=FindLineInExamFile('StartString=',TopF);
    
    nListedQuestions = NumExamQues(startstring,examfile);
    
    ss=FindLineInExamFile('ExamQuestionMarks=',TopF);
    
    examquesmarks=str2num(ss);

    nExamQuestions = length(examquesmarks);
    
    % While the MCP parts of a topic and its GE version exam papers 
    % are the same, we want the theory parts to be different.
    rng(RandSeed+97*NVers);
    
    ExamQuesNumbers=sort(randperm(nListedQuestions,nExamQuestions));
    
    ExamFile=fopen(examfile);
    
    if ExamFile==-1,
        fprintf('Exam question file %s\n',examfile);
        fprintf('Exam question file does not exist.\n'); 
        fprintf('Possible reason is that the command\n');
        fprintf('FileWithExamQuestions=...\n');
        fprintf('in examtopfile.tex contains a typo.\n');
        error('Exam question file does not exist.');
    end
    
    % find the start string in the exam questions file. 
    while true
        ss=fgetl(ExamFile);
        if feof(ExamFile),
            fprintf('In exam file the start string is expected:\n');
            fprintf('someting like \subsection{Exam theory questions}.\n');
            return
        end
        if strcmp(ss,startstring)
            break
        end
    end
    
    CurrExamQues=1;
    CurrListedQues=0;
    while true
        if feof(ExamFile),
            error('In an exam file \end{enumerate} is expected');
        end
        
        ss=strtrim(fgetl(ExamFile));

        NewExamQuesStarted = StrCmp(ss,'\item');
        
        EndEnumerate = StrCmp(ss,'\end{enumerate}');

        if NewExamQuesStarted && CurrListedQues==ExamQuesNumbers(CurrExamQues),
            CurrExamQues=CurrExamQues+1;
        end

        if EndEnumerate || (CurrExamQues > nExamQuestions),
            break
        end
       
        if NewExamQuesStarted,
            CurrListedQues=CurrListedQues+1;
            if CurrListedQues==ExamQuesNumbers(CurrExamQues),
                fprintf(OutF,'\n\\vskip 1.5 cm\n');
                fprintf(OutF,'%%Question number %d\n',CurrListedQues);
                fprintf(OutF,'\\noindent %s.',num2roman(CurrExamQues));
                fprintf(OutF,'  [%dm]\n',examquesmarks(CurrExamQues));
                fprintf(OutF,'%s\n',ss(7:end));
                continue
            end
        else
            if CurrListedQues==ExamQuesNumbers(CurrExamQues),
                fprintf(OutF,'%s\n',ss);
                continue
            end
        end
    end
    
    fprintf(OutF,'\n\n\\vskip 1.5 cm\n');
    
    fprintf(OutF,'\\begin{center}');
    fprintf(OutF,' $\\la\\la$ \\bf END OF EXAMINATION $\\ra\\ra$\n');
    fprintf(OutF,'\\end{center}\n');
end

fclose(TopF);

%clear ans TopF ss;

if ~OPTION,
%    fprintf(OutF,'\\newpage');
%    AnsTemplate = mysparse(QuesTypes,CQues,Repeats); not done yet. 
    fprintf(OutF,'\n\\catcode`@=12\n');
    fprintf(OutF,'\\end{document}\n');
    
    fprintf(OutF,'\n%%==================================================');
    fprintf(OutF,'\n%%============= Marking information ================');
    fprintf(OutF,'\n%%==================================================');
    
    fprintf(OutF,'\n\nRandom seed: %d\n',Asst.rseed');
    
    fprintf(OutF,'\n\nThe following information is given ');
    fprintf(OutF,'for marking purposes.\nThe line which ');
    fprintf(OutF,'starts with %%MARKING indicates beginning of ');
    fprintf(OutF,'the marking\ninformation.');
    fprintf(OutF,' The marking program ``spikemark.m'' looks for ');
    fprintf(OutF,'this line\nand once it is found it ');
    fprintf(OutF,'starts the marking process.\nBefore the');
    fprintf(OutF,' seven dash line ------- correct answers are given.\n');
    
    fprintf(OutF,' PrbType: types of questions: A,B,D,G,H,I,R,T or V.\n');
    fprintf(OutF,' Questns: the last digit of the number of a question.\n');
    fprintf(OutF,' Weights: mark for a correct answer.\n');
    fprintf(OutF,' Specfcs: specifications for marking:\n');
    fprintf(OutF,'  (a) "+" consider any answer as correct ');
    fprintf(OutF,'(for whatever reason).\n');
    fprintf(OutF,'  (b) "0" ignore the problem, that is,');
    fprintf(OutF,' give no marks for it.\n');
    fprintf(OutF,'  (c) "n" do not show the right answer');
    fprintf(OutF,' for this problem.\n');
    fprintf(OutF,'  (d) "." or " " treat the problem as usual.\n\n');
    
    fprintf(OutF, 'Topic code:          %s\n',Topic.code);
    if isnumeric(Asst.number),
        fprintf(OutF, 'Assignment number:   %d\n',Asst.number);
        fprintf(OutF, 'Version:             %d\n',NVers);
    else
        fprintf(OutF, 'Exam paper.\n');
    end
    fprintf(OutF, 'Number of questions: %d\n',CQues);
    fprintf(OutF, 'Types of questions: ');
    
    Types_of_questions='ABDIRGHTV';
    for j=1:length(Types_of_questions),
        NNN=length(strfind(QuesTypes,Types_of_questions(j)));
        if NNN~=0, 
            fprintf(OutF, '%d%c ', NNN,Types_of_questions(j));
        end
    end
    fprintf(OutF, '\n\n');
    
   
    if DocType==IsAssignment,
        fprintf(OutF, '%%MARKING\n');
    elseif DocType==IsExam,
        fprintf(OutF, '%%MARKING:EXAM\n');
    end
    
    fprintf(OutF, 'PrbType: %s\n',mysparse2(QuesTypes,CQues,Repeats));
    fprintf(OutF, 'NAltAns: %s\n',mysparse2(NumAltAnswers,CQues,Repeats));
    fprintf(OutF, 'Questns: %s\n',mysparse2(Questns,CQues,Repeats));
    fprintf(OutF, 'Weights: %s\n',mysparse2(Weights,CQues,Repeats));

    lineofdots=char(ones(1,80)*'.');
    fprintf(OutF, 'Specfcs: %s\n',mysparse3(lineofdots,CQues,Repeats));
   
    for n=1:Topic.NStud,
    
        if DocType==IsAssignment,
        
            ss=Topic.StudList(n,:);
            
        elseif DocType==IsExam,
            
            ss='Correct';
            
        end
        
        fprintf(OutF, '%s: %s\n',ss,mysparse3(AnsString(n,:),CQues,Repeats));
    end
    
    fprintf(OutF, '-------\n');
    
end

fprintf('Number of questions: %d\n',CQues);

LogWarnings=evalin('base','LogWarnings');
fprintf(LogF,'\n\nNumber of warnings: %d.\n', LogWarnings);

fclose(OutF);
fclose(LogF);

if LogWarnings > 0, 
    edit(LogFile);
    fprintf('\nNumber of WARNINGS: %d.\n', LogWarnings);
end

DestFolder=evalin('base','DestFolder');
DestFolder=strrep(DestFolder,'[Sem]',num2str(Asst.semester));
DestFolder=strrep(DestFolder,'[Topic]',TopicCode);
DestFolder=strrep(DestFolder,'[Ver]',num2str(NVers));

if exist(DestFolder,'dir'),
    copyfile(OutFile,sprintf('%s\\%s.tex',DestFolder,TopicAmVn));
    fprintf('The assignment file \\%s has been copied to\n', OutFile);
    fprintf('%s\n\n',DestFolder);
else
    fprintf('The destination folder \\');
    fprintf('%s\nhas not been found.\n\n', DestFolder);
    
    edit(OutFile);
    fprintf('The assignment file \\%s is opened ', OutFile);
    fprintf('in Matlab''s editor.\n\n');
end

% Delete the current workspace and restore the old workspace.
evalin('base', 'clear');
evalin('base', 'load ''temp.mat''');
delete 'temp.mat'


end  % spike

function GeneralError(ME)
    fprintf('An error occured.\n');
    fprintf('A probable cause of this error is that the current folder\n');
    fprintf('is not \\Spike or this folder with its subfolders is not in Matlab''s path.\n');
    fprintf('Please correct this and run Spike again.\n\n');
    fprintf('%s\n',ME.message);
end

function ss=FindLineInExamFile(tobefound,TopF)
    ss=fgetl(TopF);
    if ~StrCmp(ss,tobefound)
        fprintf('In examtopfile.tex "%s" is expected.',tobefound);
        error('The program is halted.');
    end
    tobefoundlen=length(tobefound);
    ss=ss(tobefoundlen+1:end);
end