classdef problemH < problemG
    
    
    properties
        out;   % out and tf are two problemH-specific variables,
        tf;    % which the command part has to produce. 
    end
    
    methods

        function q=problemH(S)
            q=q@problemG(S);
            evalin('base', 'out=999;');
            evalin('base', 'tf=999;');
        end
        
    end
    
    methods (Access = protected)
        
        
        function q = ProcessCmdPt(q)
            % Execute commands of the command part.
            % If an attempt to execute fails, give an error message. 
            for k=1:q.NCmdPt,
                outstr = q.CmdPt(k,:);
                try
                    status=Spike2Matlab(outstr,1,0);
                    if ~isempty(status),
                        q.Sp_Error(status,outstr);
                    end
                catch ME
                    q.ME_Error(outstr,ME);
                end
            end
            
            q.out = evalin('base', 'out;');
            q.tf = evalin('base', 'tf;');
            
            if q.out==999,
                msg='The variable "out" is undefined.';
                q.Sp_Error(msg,q.CmdPt(q.NCmdPt,:));
            elseif q.tf==999,
                msg='The variable "tf" is undefined.';
                q.Sp_Error(msg,q.CmdPt(q.NCmdPt,:));
            end
            
        end
        
        function q = ProcessTxtPt(q)
            % Write the body of the multiple choice question;
            % it is of this kind: ``How many of the following
            % statements are true?''
            for k=q.FreezeTxtPoint+1:q.NTxtPt,
                fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k,:)));
            end
            
            % nchosentrue is the number of right statements chosen randomly.
            
            q.nchosentrue=0;
            
            fprintf(q.outfile,'\\begin{enumerate}\n');
            
            for k=1:q.nques,
                q.ProcessCmdPt;
                s=evalin('base','out');
                fprintf(q.outfile,'\\item %s\n',s);
                q.nchosentrue=q.nchosentrue+evalin('base', 'tf');
            end
            
            fprintf(q.outfile,'\\end{enumerate}\n');
            
            q.CorrAns(q.CRepeat) = char('0'+q.nchosentrue);
            
        end
        
    end
    
end % classdef problemH