function [status,raw_volume]=Spike2Matlab(ss,raw_volume,runnumber)
% Generally, a Spike command is just a Matlab command, but with 
% one exception. This function transforms that exceptional 
% Spike command into Matlab format.
%
% Specifically,
%    if a spike-command sb has a pair of curved brackets {...}
%    then this function replaces them by a number,
%    chosen randomly from the list of numbers inside the curved brackets.
%
%    For example, a command such as 
%
%       a=[{3:7},{3,5,7,11}];
%
%    will be replaced in one run by, say, a=[6,7],
%    in another run by, say, a=[4,11], etc.
%
% Input: ss, a string with a Spike operator;
% Output: the string ss converted to a MATLAB operator and evaluated.

status='';

ss=strtrim(ss);

a_type='';
k=strfind(ss,'!=');
if ~isempty(k),
    a_type = '!=';
else 
    k=strfind(ss,'!<');
    if ~isempty(k),
        a_type = '!<';
    else
        k=strfind(ss,':=');
        if ~isempty(k),
            a_type = ':=';
        else
            k=strfind(ss,':<');
            if ~isempty(k),
                a_type = ':<';
            end
        end
    end
end

% if a_type is not one of these: '', '!=', '!<', ':=', ':<'
if isempty(a_type), 
    [outss,status,raw_volume]=ProcessCurvedBrackets(ss,raw_volume,runnumber);
    if ~isempty(status),
        return
    end
    try
        evalin('base',outss);
    catch
        fprintf('Spike: Error 273.\n');
        fprintf('Line with error %s: \n',outss);
        error('In Spike2Malab evalin, line 53.');
    end

    if ~isempty(strfind(ss,'randi'));
        raw_volume=raw_volume*32;
    elseif ~isempty(strfind(ss,'rand'));
        raw_volume=raw_volume*1000;
    end
    
    if ~isempty(strfind(ss,'Get'));
        raw_volume=raw_volume*1000;
    end

    return
end

% if there are more than one combinations of symbols := or != or !< or !=
% then report error.
if length(k)>1,
    status=['Incorrect multiple assignment operator(1): ',ss];
    return
elseif ~StrEnd(ss,'};') || ~strcmp(ss(k+2),'{'),
    status=['Incorrect multiple assignment operator(2): ',ss];
    return
end

% if a_type is one of these: '', '!=', '!<', ':=', ':<'

% pp is the array of numbers, from which a value of a variable
% is chosen. For example, if the command is 'a={3:7};' then 
% pp=[3,4,5,6,7].
try
    pp=evalin('base',sprintf('[%s]',ss(k+3:end-2)));
catch
    error('In Spike2Matlab evalin, line 87.');
end

% lenvar is the number of variables in a multiple assignment operator,
% vars is the array of lenvar variables. 
% For example, in 'a,b,c!={1:10};' lenver is 3 and vars is [a,b,c].
[vars,lenvar,~]=SeparateVariables(ss(1:k-1),',');
% if lenvar==1,
%     status='A multiple assignment operator is to have at least two variables';
%     return
% end

if a_type(1)=='!',
    % if variables are to have different values, then choose 
    % non-coinciding indices,
    ind=randperm(length(pp),lenvar);
else
    % else choose any indices within the range. 
    ind=randi(length(pp),1,lenvar);
end

a=pp(ind);

if a_type(2)=='<',
    a = sort(a);
end

if isnumeric(a(1)),
    for j=1:lenvar,
        evalin('base',sprintf('%s=%d;',deblank(vars(j,:)),a(j)));
    end
else
    for j=1:lenvar,
        evalin('base',sprintf('%s=''%c'';',deblank(vars(j,:)),a(j)));
    end
end

% Adjust raw volume. 
lenpp=length(unique(pp));
if runnumber==1,
    if strcmp(a_type,':='), 
        raw_volume=raw_volume*lenpp^lenvar;
    elseif strcmp(a_type,':<'), 
        % For this formula see e.g. "A.N.Shiryaev, Probability", 
        % section I.1, formula (2).
        raw_volume=raw_volume*nchoosek(lenpp+lenvar-1,lenvar);
    elseif strcmp(a_type,'!='), 
        raw_volume=raw_volume*nchoosek(lenpp,lenvar)*factorial(lenvar);
    elseif strcmp(a_type,'!<'), 
        raw_volume=raw_volume*nchoosek(lenpp,lenvar);
    end
end

end % Spike2Matlab

