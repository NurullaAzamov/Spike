function [outss,status,raw_vol]=ProcessCurvedBrackets(inss,raw_vol,runnum)
% This function processes randomising "curved bracket" operators
% in spike commands. 
%
% runnum is RunNumber
% raw_vol is RawVolume

  status='';

  % if the string inss contains the substring 'sprintf'
  % then do nothing.
  s=strfind(inss,'sprintf');
  if ~isempty(s),
      outss=inss;
      return
  end
  
  % if a command line ss contains "randi" command,
  % then presumably raw volume should be large enough,
  % so we just multiply it by 1000, and do not worry
  % about it.
  if ~isempty(strfind(inss,'rand')),
      if runnum==1,
          raw_vol=1000*raw_vol;
      end
  end

  % a and b are positions of curved brackets in inss.
  [a,b,status]=GetPairOfCurvedBrackets(inss);
  
  % if the string inss does not contain curved brackets 
  % then do (almost) nothing.
  if ~isempty(status),
      return
  elseif a==0,
      outss=inss;
      return
  end
  
  pp=evalin('base',sprintf('[%s]',inss(a+1:b-1)));
  len=length(unique(pp));
  if runnum==1,
      raw_vol=raw_vol*len;
  end
  nn=pp(randi(len));
  outss=sprintf('%s%d%s',inss(1:a-1),nn,inss(b+1:end));
  [outss,status,raw_vol]=ProcessCurvedBrackets(outss,raw_vol,runnum);
end % ProcessCurvedBrackets

function [a,b,status]=GetPairOfCurvedBrackets(inss)
% a and b are indices of the first inner pair of brackets { and }.
% For example, if inss='a={3:{4:10}}', then a = 6 and b = 11.
status='';
a=0; b=0;
n=length(inss);
for j=1:n,
    if inss(j)=='{',
        a=j;
    elseif inss(j)=='}',
        if a==0,
            status='Unbalanced pair of curved brackets {...}.';
            return
        else
            b=j;
            return
        end
    end
end
end % GetPairOfCurvedBrackets