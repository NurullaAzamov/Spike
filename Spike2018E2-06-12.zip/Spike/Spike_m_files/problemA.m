classdef problemA < problemR
    % This class implements multiple choice
    % questions of type A.
    %
    % In type A question the command part does not have the answer 
    % command. Instead, the command part produces two specific 
    % for type A questions variables "approxans" and "exactans". 
    % The code of problemA then takes care of preparing 
    % the correct answer and multiple incorrect choice answers. 
    
    properties
    end
    
    methods
        
        function q=problemA(S)
            % S is a spikeblock
            q=q@problemR(S);
        end
        
    end
    
    methods (Access = protected)
       
        function q=ProcessCmdPt(q)
            % Execute commands of the command part.
            % If an attempt to evaluate fails, give an error message.
            
            NAttempts=0;
            
            % We run this cycle until "condition" is true 
            % (which happens, or should happen, in 99.9% 
            %  of cases anyway).
            while true,
                
                NAttempts=NAttempts+1;
                if NAttempts >= 50,
                    fprintf('\nQ%d: too many (>50) attepmts.\n',q.QuesNum);
                    fprintf('%s\n',q.TxtPt(1,:));
                    error('The program terminated.');
                end
                evalin('base','condition=1;');
                
                % Run ALL commands of the command part,
                % including the last line too.
                % (so we have here ...:q.NCmdPt, and not ...:q.NCmdPt-1
                %  as in type I questions).
                for k=1:q.NCmdPt,
                    
                    out = strtrim(q.CmdPt(k,:));
                    
                    if StrCmp(out,'rawvolume'),
                        ket=strfind(out,')');
                        factor=evalin('base',out(11:ket-1));
                        q.RawVolume=q.RawVolume*factor;
                        continue
                    end
                    
                    try
                        RN=q.CRun;
                        [status,q.RawVolume]=Spike2Matlab(out,q.RawVolume,RN);
                        if ~isempty(status),
                            q.Sp_Error(status,out);
                        end
                    catch ME
                        q.Sp_Error(ME.message,out);
                    end
                    
                    if evalin('base','~condition;'),
                        break
                    end
                    
                end
                
                if evalin('base','~condition;'),
                    continue
                else
                    break
                end
                
            end
            
            % Process the last answer command.
            % This command produces "answer" variable.
            q=q.ProcessAnswerCmd;
            
        end
        
        function q=ProcessAnswerCmd(q)
            
            try
                x=evalin('base','approxans;');
            catch ME
                q.Sp_Error(ME.message,'"approxans" is not found.');
            end
            
            if isnan(x),
                q.Sp_Error('problemA error','approxans is NaN');
            elseif isinf(x),
                q.Sp_Error('problemA error','approxans is Inf');
            end
            
            try
                y=evalin('base','exactans;');
            catch ME
                q.Sp_Error(ME.message,'"exactans" is not found.');
            end

            if isnan(y),
                q.Sp_Error('problemA error','exactans is NaN');
            elseif isinf(y),
                q.Sp_Error('problemA error','exactans is Inf');
            end
            
            k=HowClose(x,y); 
            
            if k >= 12,
                fprintf(q.logfile,'Q%d: ',q.QuesNum);
                fprintf(q.logfile,'Type A question: the approximate ');
                fprintf(q.logfile,'solution is too good: k=%d\n',k);
                evalin('base','LogWarnings=LogWarnings+1;');
            end

            if k >= 19,
                Message=sprintf('Value of HowClose = %d',k);
                q.Sp_Error(Message,'exactans = approxans?');
            end
            
            
            try
                outss=sprintf('xprintf(''$#%de$'',''%s'');',k+3,'approxans');
            catch ME
                q.Sp_Error(ME.message,'too many digits in approxans??.');
            end
            
            [q.answer,~,status,logstatus]=evalin('base',outss);
            
            if ~logstatus,
                fprintf(q.logfile,'%s',logstatus);
            end
            
            if ~isempty(status),
                q.Sp_Error(status,outss);
            end
            
            
        end
        
    end
    
end % classdef problemI
