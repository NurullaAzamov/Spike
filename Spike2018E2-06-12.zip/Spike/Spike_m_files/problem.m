classdef problem < spikeblock
    % problem is the superclass of problemI, problemR, etc
    
    properties
        CRepeat; % current repeat of the question
                   % (former RepeatNum)
        
        NAltAnswers;   % number of alternative answers A,B,C,...
        NRepeats;  % how many times to repeat this MC question.
        CorrAns;   % correct answer, from version 2018A4 it is a string of 
                   %  one of these: A,B,C,... or 0,1,2,...
        TxtPtPar;  % hashtag parameters
        LiquidTxtPtPar; % hashtag parameters which come after \freeze.
        Weight;    % weight of the question (replacing old "marks" field)
        Type;      % problem type, one of A,B,D,G,H,I,...
        RawVolume; % raw volume :)
        CRun;      % current run of the command part of the spike-block 
                   % (former RunNumber).
        RandSeed;
    end
    
    methods
        function q=problem(S)
            
            q=q@spikeblock;
            
            q.RawVolume=1;
            q.CRun=1;
            q.CRepeat=1;

           
            q.Cmd=S.Cmd;
            q.CmdPt=S.CmdPt;
            q.NCmdPt=S.NCmdPt;
            q.TxtPt=S.TxtPt;
            q.NTxtPt=S.NTxtPt;
            q.Type=S.Cmd(8);
            
            q.outfile=S.outfile;
            q.logfile=S.logfile;
            q.StartLn=S.StartLn;
            q.EndLn=S.EndLn;
            q.QuesNum=S.QuesNum;
            q.CurrAssign=S.CurrAssign;
            q.Version=S.Version;
            q.FreezeCmdPoint=S.FreezeCmdPoint;
            q.FreezeTxtPoint=S.FreezeTxtPoint;
            
            q.SpkFile=S.SpkFile;

            q.AtLine=S.AtLine;

        end
        
       
        function q=SetRandSeed(q,randseed)
            q.RandSeed=randseed;
        end
        
        
        function q=Execute(q)

           q=ProcessAtLine(q);
            
           abc='a':'z';

           fprintf(q.outfile,'\n\\problemtype{%c}',q.Type);
           fprintf(q.outfile,'\n%%%s',q.SpkFile);
            
           for rep_00=1:q.NRepeats,
               
               fprintf(q.outfile,'\n%%Q%d(%c)\n',q.QuesNum,abc(rep_00));
               
               fprintf('%d',mod(q.QuesNum,10)); % echo
               rng(q.RandSeed+rep_00);
               
               q.CRepeat=rep_00;
               
               % Process the Matlab part of a spike block.
               q=q.ProcessCmdPt;
               
               % Choose a random permutation of answers.
               q=q.SetRandPerm;
               
               % Set the correct answer to the question.
               q=q.SetCorrAns;
               
               % Type question number and the frozen part of the text
               % into the output file.
               q=q.TypeQuesNum_and_FrozenTxTPart;
               
               % Process the LaTeX part of a spike block.
               q=q.ProcessTxtPt;
               
               q=q.ProcessAnswers;
               
               q=q.TypeRawVolume;
               
               fprintf(q.outfile,'%%Corr ans: %c\n',q.CorrAns(q.CRepeat));
           end
        end
        
        function Sp_Error(q,message,str)
            fprintf('\n\n\nSpike: ERROR in spike-block ');
            fprintf('starting at line %d in spk-file.\n',q.StartLn);
            fprintf('Question number: %d\n',q.QuesNum);
            fprintf('Spike-block type: %s\n\n',q.Cmd);
            fprintf('Line with error:\n\n      !%s!\n\n',str);
            if length(message)>=18 && strcmp(message(1:18),'Undefined function'),
                fprintf('The line contains an undefined function.\n');
            else
                fprintf('Message:\n      %s\n',message);
            end
            fprintf('\n');
            fprintf('Press Ctrl+Pause to terminate the program.\n');
            evalin('base', 'clear');
            evalin('base', 'load ''temp.mat''');
            delete 'temp.mat'
            pause;
        end
        
    end
    
    methods (Access = protected) 
        
        function q=ProcessAtLine(q)
            % Process @-line of the spike-block.
            % "num" is the number of parameters of the @-line
            % and "vars" are parameters of the @-line.
            % For example, if the @-line is '@2::4; a,b,c;'
            % then "num" is 2 and vars(1,:)='2::4' and 
            % vars(2,:)='a,b,c'.  
            
            [vars,num,status]= SeparateVariables(q.AtLine,';');
            
            if ~isempty(status)
                Sp_Error(q,status,q.AtLine);
            elseif num<1,
                msg='@-line must have at least one parameter.';
                Sp_Error(q,msg,q.AtLine);
            end
            
            % This is the first argument of the at-line. 
            FirstPar=strtrim(vars(1,:));
            
            if ~isempty(strfind(FirstPar,','))
                msg='The first parameter of @-line has a comma.';
                Sp_Error(q,msg,q.AtLine);
            end
            
            [firstvars,firstvarnums,status]= SeparateVariables(FirstPar,':');
            
            if ~isempty(status)
                Sp_Error(q,status,q.AtLine);
            elseif firstvarnums<1,
                msg='The first parameter of @-line must have at least one number.';
                Sp_Error(q,msg,q.AtLine);
            end

            q.Weight=str2double(firstvars(1,:));

            GlblWeight = evalin('base','GlblWeight');
            if ~isempty(GlblWeight),
                q.Weight=GlblWeight;
            end
            
            if q.Weight>9,
                msg='Question weight is > 9?';
                Sp_Error(q,msg,q.AtLine);
            end
            if isnan(q.Weight),
                msg='Question weight is NaN?';
                Sp_Error(q,msg,q.AtLine);
            end
            
            
            q.NRepeats = evalin('base','NRepeat');
            q.NAltAnswers = evalin('base','NAltAns');

            if firstvarnums>=2, 
                ss2=strtrim(firstvars(2,:));
                if ~isempty(ss2),
                    q.NRepeats = str2double(ss2);
                end
            end

            GlblNRepeat = evalin('base','GlblNRepeat');
            if ~isempty(GlblNRepeat)
                q.NRepeats=GlblNRepeat;
            end
            
            
            ss='??????????'; 
            q.CorrAns=ss(1:q.NRepeats);
            
            if firstvarnums>=3,
                ss3=strtrim(firstvars(3,:));
                if ~isempty(ss3),
                    q.NAltAnswers= str2double(ss3);
                end
            end
            
            GlblNAltAns = evalin('base','GlblNAltAns');
            if ~isempty(GlblNAltAns)
                q.NAltAnswers=GlblNAltAns;
            end
            
            if num>=2,
                % These are the text part variables.
                ss = strtrim(vars(2,:));
                if ~isempty(ss),
                    q.TxtPtPar=[',',ss];
                end
            else 
                q.TxtPtPar='';
            end
            
            if num>=3,
                fprintf('\n\nERROR: old style format of at line.');
                fprintf('\n\nChange the format of spk-files, using\n');
                fprintf('Replace_at_line_in_a_file.m function.\n');
                msg='too many (>2) parameters in @-line.';
                Sp_Error(q,msg,q.AtLine);
            end            
        end

        
        function q=SetCorrAns(q)
        end
        
        function q=SetRandPerm(q)
        end
        
        function q=ProcessCmdPt(q)
        end
        
        
        
        function q=TypeQuesNum_and_FrozenTxTPart(q)
            ABC='abcdefghijklmn';
            
            TempTxtPt=q.TxtPt;

            % params are parameters of the text part,
            % such as ',a,b1,b2,N1,N2'
            params=q.TxtPtPar;
            
            there_are_any_hashtags=1;
            
            % Process hashtag and double hashtag operators,
            % if there are any. 
            while there_are_any_hashtags
                
                there_are_any_hashtags=0;

                for k=1:q.FreezeTxtPoint-1
                    
                    % Get a line of the text part.
                    ss=deblank(TempTxtPt(k,:));
                    
                    there_are_any_hashtags = ~ isempty(strfind(ss,'##'));
                    
                    % Process hashtag operators.
                    
                    [outstr,params]=ProcessHashtags(q,ss,params);
                   
                    % at this point "outstr" contains hashtag processed
                    % line of the frozen text part.
                    
                    % replace k-th line of TempTxtPt 
                    % with processed (hashtag free) line "outstr".
                    len=length(TempTxtPt(k,:));
                    TempTxtPt(k,:)=char(ones(1,len)*' ');
                    
                    TempTxtPt(k,1:length(outstr))=outstr;
                end % for k
                
            end % while there_are...
            
            q.LiquidTxtPtPar=params;
            
            if q.CRepeat==1
                fprintf(q.outfile,'\\QuesA{%d}\\ \\ ',q.Weight);
                for k=1:q.FreezeTxtPoint-1
                    ss=deblank(TempTxtPt(k,:));
                    fprintf(q.outfile,'%s\n',ss);
                end
                if q.NRepeats>1
                    fprintf(q.outfile,'\n\\medskip(a)\\ ');
                end
            else
                fprintf(q.outfile,'\\QuesB(%c)\\ ',ABC(q.CRepeat));
            end
                
        end
        
        function q=ProcessTxtPt(q)
        end

        function q=ProcessAnswers(q)
        end
        
        function q=TypeRawVolume(q)
            Min_raw_volume=evalin('base','MIN_RAW_VOLUME');
            if q.CRepeat==1,
                
                if q.RawVolume < 10^6 && q.CurrAssign==1,
                    fprintf(q.outfile,'%%Raw volume %d\n',q.RawVolume);
                else
                    fprintf(q.outfile,'%%Raw volume %.2e\n',q.RawVolume);
                end
                
                if q.RawVolume < Min_raw_volume && q.CurrAssign==1,
                    fprintf(q.logfile,'Q%d: small raw volume:',q.QuesNum);
                    fprintf(q.logfile,' %d\n',q.RawVolume);
                    evalin('base','LogWarnings=LogWarnings+1;');
                end
                
            end
        end
        
    end
    
end % classdef problem

