classdef problemT < problemG
    
    properties
        ntrue;   % number of true statements
        nfalse;  % number of false statements
        p_00;    % random sample of statements
    end
    
    methods
        
        function q=problemT(S)
            q=q@problemG(S);
        end
        
    end
    
    methods (Access = protected)
       
        function q=SetCorrAns(q)
            % do nothing,
            % since the value of q.CorrAns is set by
            % the method ProcessCmdPt(q).
        end
        
        function q = ProcessCmdPt(q)
            
            MAX_COMMAND_LENGTH = 780;
            max_cmd_length=0;
            
            % Process "long", many line, commands.
            % (Glue their pieces together). 

            % initialise a temporary duplicate of q.CmdPt
            CmdPtCopy=char(ones(q.NCmdPt,MAX_COMMAND_LENGTH)*' ');
            
            ss='';
            % k is the counter of the statements.
            k=0;
            for j=1:q.NCmdPt,
                cmdline=deblank(q.CmdPt(j,:));
                if StrCmp(cmdline,'   '),
                    if j==1,
                        error('The first line in type T question ...');
                    end
                    % a temporary spoilage of a cmd line.
                    ss=[ss,'$!$!   ',cmdline(4:end)];
                else
                    if k>0,
                        CmdPtCopy(k,1:length(ss)) = ss;
                    end
                    % proceed to the next statement
                    k=k+1;
                    % the beginning of a new statement
                    % (since the next line can be its continuation)
                    ss=cmdline;
                end
                
                if j==q.NCmdPt,
                   CmdPtCopy(k,1:length(ss))=ss;
                end
            end

            q.NCmdPt=k; % new counter for the size of the command part. 
            
            q.CmdPt=CmdPtCopy(1:k,:);
            
            
            
            CmdPtCopy=char(ones(q.NCmdPt,MAX_COMMAND_LENGTH)*' ');
            
            for j=1:q.NCmdPt,
                % Process the randomising operators
                % in the jth line of the command part.
                s_00=ProcessFString(q.CmdPt(j,:));
                
                CmdPtCopy(j,1:length(s_00))=s_00;
                
                if length(s_00)>max_cmd_length,
                    max_cmd_length=length(s_00);
                end
            end
            
            % Now CmdPtCopy has done its job,
            % so we get rid of it. 
            q.CmdPt=CmdPtCopy(:,1:max_cmd_length);
            
            % The lines which follow after @ line are for
            % the question body. The @ line itself in type T
            % question must have the format 
            % @Mark[:NRepeat[:NAltAns]]; k;
            % where k is the number of statements to choose. 
            
            q.ntrue=0;
            
            % find the position of the separator '-------',
            % and thus determine the number of false q.nfalse 
            % and true q.ntrue statements. 
            for j=1:q.NCmdPt,
                if StrCmp(q.CmdPt(j,:),'-------'),
                    q.nfalse=j-1;
                    q.ntrue=q.NCmdPt-q.nfalse-1;
                    break
                end
            end
            
            if q.ntrue==0,
                ss='False and true statements should be ';
                q.Sp_Error([ss,'separated by -------'],['@',q.AtLine]);
            end
            
            % Decide which statements to pick up
            q.p_00=randperm(q.nfalse+q.ntrue,q.nques);
            
            % skip the ``seven dash'' (that is, -------) line
            q.p_00 = q.p_00 + (q.p_00>q.nfalse);
            
            % number of correct statements chosen.
            q.nchosentrue=sum(q.p_00>q.nfalse);
            
            % flip statements with the separator &&.
            for k=1:q.nques,
               
                ss=q.CmdPt(q.p_00(k),:);
                maxlen=length(ss);
                
                sepr=strfind(ss,'&&');
                
                if isempty(sepr),
                    % do nothing
                else
                    % toss a coin,
                    x = randi(2)-1;
                    % if x = 0, then choose what comes before &&,
                    % otherwise choose what comes after &&.
                    if x,
                        ss=ss(1:sepr-1);
                    else
                        ss=ss(sepr+2:end);
                        % if we are replacing the true statement 
                        % by a false one, then decrease the counter
                        % of true statements by 1,
                        if q.p_00(k)>q.nfalse,
                            q.nchosentrue=q.nchosentrue-1;
                        % otherwise increase the counter
                        % of true statements by 1.
                        else
                            q.nchosentrue=q.nchosentrue+1;
                        end
                    end
                    
                    len=maxlen-length(ss);
                    q.CmdPt(q.p_00(k),:)=[ss,char(ones(1,len)*' ')];
                    
                end
            end            
            
            q.CorrAns(q.CRepeat) = char('0'+q.nchosentrue);
            
            % The number of ways to choose nques questions
            % out of the given set of statements. 
            q.RawVolume=nchoosek(q.nfalse+q.ntrue,q.nques);
        end
        
        function q = ProcessTxtPt(q)
            
            % Print a sentence of this kind:
            % ``How many of the following statements are true?''.
            
            for k=q.FreezeTxtPoint+1:q.NTxtPt,
                fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k,:)));
            end
            
            % Now print the list of statements
            fprintf(q.outfile,'\\begin{enumerate}\n');
            
            for k=1:q.nques,
                fprintf(q.outfile,'\\item ');
                
                ss=deblank(q.CmdPt(q.p_00(k),:));
                
                % Write "ss" treating its substrings '$!$!' as '\n'.
                
                while 1,
                    b=strfind(ss,'$!$!');
                    if isempty(b),
                        fprintf(q.outfile,'%s\n',ss);
                        break
                    else
                        fprintf(q.outfile,'%s\n',ss(1:b-1));
                        % skip '$!$!' bit
                        ss=ss(b+4:end);
                    end
                end
            end
            
            % Close the list of statements.
            fprintf(q.outfile,'\\end{enumerate}\n');
                        
        end
        
    end
    
end % classdef problemT < problemG
