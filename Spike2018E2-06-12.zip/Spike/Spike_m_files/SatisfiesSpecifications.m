function [entry,bool]=SatisfiesSpecifications(str,specs)
% This function checks whether a line "str" of a Problem D
% database satisfies specifications "specs". If "str" satisfies 
% the specifications, then "bool" is 1, otherwise it is 0. 
% "entry" is the part of the line "str" before the first separator &.
% 
%  For example, if the database is 
%
% Tiger      &   C       &   M    &   1
% Wolf       &   C       &   M    &   0 
% Bobcat     &   C       &   M    &   1
% Zebra      &   H       &   M    &   1
% Rabbit     &   H       &   M    &   0
% Crocodile  &   C       &   R    &   0
% Shark      &   C       &   F    &   0
% Koala      &   H       &   M    &   0
% Kangaroo   &   H       &   M    &   0
% Emu        &   H       &   B    &   0
%
% and the specifications are specs = 'C**', then Tiger, Wolf, Bobcat 
% satisfy it, while Zebra and Rabbit do not. If the specifications 
% are specs = 'CR*', then only Crocodile satisfies it. 

[entry,str] = strtok(str,'&');
bool=1;

StrSpecs=''; % initialize specifications of the line str.

while true
   [a,str]=strtok(str,'&');
   StrSpecs=[StrSpecs,strtrim(a)];
   if isempty(str),
       break
   end
end

n=length(specs);
if length(StrSpecs)~=n,
    error('Specifications line has wrong length.');
end

for j=1:n,
    if specs(j)=='*',
        continue
    elseif specs(j)==StrSpecs(j),
        continue
    else
        bool=0;
        break
    end
end

end