function RandomGoodDenoms

for N=1:1000,
    s='0.';
    for j=1:15,
        s=sprintf('%s%d',s,randi(10)-1);
    end
    
    x=str2double(s);
    if IsFraction(x),
        fprintf('%s\n',s);
        %return
    end
end

end