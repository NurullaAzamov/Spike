function k = HowClose(x,y)
% This function finds the length of the common 
% part of mantissa's of x and y. For example,
% if x = 3.141592653589793 and y = 3.1413866679,
% HowClose returns k = 4. 

k=round(log10(abs(x))) - round(log10(abs(x-y)));

end