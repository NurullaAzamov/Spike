classdef topic

    properties(Constant=true)
        MAX_NUMBER_OF_STUDENTS=500;
        ID_LENGTH=7;
    end
    
    properties
        code;             % topic code, such as 'MATH2712'
        name;             % topic name, such as 'Algebra'
        NStud;            % number of students enrolled in this topic.
        StudFile;         % file with list of students enrolled in this topic.
        StudNames;        % Names of students.
        StudList;
    end

    methods
        function t=topic(TopicCode)
            TopicCode=upper(TopicCode);
            t.code=TopicCode;
            
            t.name='Unknown Topic Code';            
            topiclistfile=fopen('topiclist.txt');
            if topiclistfile==-1
                fprintf('Topic list file is not found.\n');
            else
                while ~feof(topiclistfile),
                    s=fgetl(topiclistfile);
                    [s,s2]=strtok(s,':');
                    if strcmp(s,TopicCode),
                        t.name=s2(2:end);
                        break
                    end
                end
            end
            fclose(topiclistfile);
            
            t.StudFile=sprintf('%s\\StudList.txt',t.code);

            sfile=fopen(t.StudFile);
            if sfile==-1 
                error('Spike: student file is not found.'); 
            end
            % NStud is the number of students.
            t.NStud=0;
            % 48 is the code of the character ``0''
            t.StudList=char(ones(t.MAX_NUMBER_OF_STUDENTS,100)*32);
            
            % Read the student ID's from the student 
            % ID file to the array StudList.
            while ~feof(sfile)
                ss=fgetl(sfile); % ID of a student and their name
                if StrCmp(ss,'%')   
                    continue
                elseif length(ss)<t.ID_LENGTH,
                    fprintf('Spike: error in a student list file:\n');
                    fprintf('   %s.\n',ss);
                    fprintf('In a student list file lines cannot have ');
                    fprintf('length less than %d.',t.ID_LENGTH);
                elseif StrCmp(ss,'-------'),
                    break
                else 
                    t.NStud=t.NStud+1;
                    t.StudList(t.NStud,1:length(ss))=ss;
                end
            end
            fclose(sfile);
           
            % removing empty (zero) lines
            t.StudList=t.StudList(1:t.NStud,:);  
            
            % Sort StudList before starting to do anything with it.
            idlen=t.ID_LENGTH;
            t.StudList=mysort(t.StudList,idlen-2,idlen);

            cc=t.StudList(:,1:t.ID_LENGTH);
            t.StudNames=[cc,t.StudList(:,t.ID_LENGTH+11:40)];
            t.StudList=cc;

        end % function topic (constructor)
    end
    
end % classdef topic