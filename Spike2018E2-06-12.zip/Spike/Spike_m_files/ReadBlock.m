function [SB,endline]=ReadBlock(SB,spkfile,spkLine)
% We have just read an opening line <<...
% of a spike-file spkfile and we are about to read
% the block into SB. spkLine is the current line of 
% spkLine, and SB already contains the block's type. 
%
%
% Input: SB, a spikeblock,
%        spkfile, a file with spikeblocks,
%        spkLine, a pointer to the current line in spkfile.
% Output: 
%       SB, a spikeblock read from the spkfile,
%          with the pointer moved to endline. 

QuesTypes='ABDGHINRVTZ';

MAX_NUMBER_OF_CMDS=500;
MAX_CMD_LENGTH=780;

% maximum number of lines
% in the text part of spike block.
MAXNUM_OF_PROBLTXT=87;

% maximum length of lines
% in the text part of spike block.
MAX_PROBLTXT_LEN=237;

max_cmd_length=0;
max_txtpt_length=0;

if ~strcmp(SB.Cmd,'data') && ~strcmp(SB.Cmd,'text'),
    UnknownType=~ismember(SB.Cmd(8),QuesTypes);
    if ~ StrCmp(SB.Cmd,'problem') || UnknownType,
        fprintf('\n\nFunction spikeblock\n\n');
        fprintf('ERROR in line %d: ',SB.StartLn);
        fprintf('after << one of the following ');
        fprintf('commands is expected:\n');
        fprintf('data, text, problem[A,B,D,G,H,I,N,R,V,T,Z].\n');
        SB.status='error';
        return
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Read the command part CmdPt of spike-block.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The command part CmdPt is what comes between << and @.

% Here we are inside << ... >>

% If the spike block is not a text-block, then read
% the command part of the block.
if ~strcmp(SB.Cmd,'text'),
    
    % Initialize CmdPt as an array of
    % MAX_NUMBER_OF_CMDS empty commands.
    % 32 is the code of empty space character.
    SB.CmdPt=char(ones(MAX_NUMBER_OF_CMDS,MAX_CMD_LENGTH)*32);
    
    while true,
        if feof(spkfile),
            fprintf('\nERROR in line ');
            fprintf('%d: @ or >> is expected.\n',SB.StartLn);
            SB.status='error';
            return
        else
            s=fgetl(spkfile);
            s=deblank(s);
            spkLine=spkLine+1;
            if StrCmp(s,'%EOF'),
                fprintf('\nERROR in line %d: ',SB.StartLn);
                fprintf('@ or >> is expected.\n');
                SB.status='error';
                return
            end
        end
        
        % Here s is current non-empty line from spike-file.
        if StrCmp(s,'%'),
            
            continue
            
        elseif StrCmp(s,'@'),
            
            if strcmp(SB.Cmd,'data'),
                fprintf('\nERROR in line');
                fprintf(' %d: ',SB.StartLn);
                fprintf('>> was expected, @ was found.\n');
                fprintf('\nData spike-block should ');
                fprintf('not have @...>> part.\n');
                SB.status='error';
                return
            else
                SB.AtLine=s(2:end);
                break % from << ... @
            end
            
        elseif StrCmp(s,'>>'),
            
            break % from << ... >>
            
        else % read the command lines between << and @
            len=length(s);
            while StrEnd(s,'%'),
                if feof(spkfile),
                    fprintf('\nERROR in line');
                    fprintf(' %d: ',SB.StartLn);
                    fprintf('@ or >> is expected.\n');
                    SB.status='error';
                    return
                end
                t=fgetl(spkfile);
                spkLine=spkLine+1;
                s=[s(1:len-1),t];
                len=length(s);
            end
            if length(s)>MAX_CMD_LENGTH,
                fprintf('\nERROR in line ');
                fprintf('%d:\n',SB.StartLn);
                fprintf('this command has length');
                fprintf(' > %d.',MAX_CMD_LENGTH);
                SB.status='error';
                return
            elseif length(s)>max_cmd_length,
                max_cmd_length=length(s);
            end
            SB.NCmdPt=SB.NCmdPt+1;
            if ~isempty(s),
                SB.CmdPt(SB.NCmdPt,1:length(s))=s;
            end
            if StrCmp(strtrim(s),'freeze')
                SB.FreezeCmdPoint=SB.NCmdPt; 
            end
        end
    end
    
    SB.CmdPt=SB.CmdPt(1:SB.NCmdPt,1:max_cmd_length);
    
end % if ~strcmp(SB.Cmd,'text')

% if StrCmp(s,'@'),
%     SB.AtLine=s(2:end);
% end

% At this stage we are inside a subblock @...>>
% or inside a text-block <<...>>.
% Read the text part of <<...>> to the array TxtPt.
% The text part is what comes between @ and >>

if ~strcmp(SB.Cmd,'data'),
    
    SB.TxtPt=char(ones(MAXNUM_OF_PROBLTXT,MAX_PROBLTXT_LEN)*32);
    
    while true,
        if feof(spkfile),
            error('Spike: >> is expected');
        end
        
        % read a line, ignoring comments.
        s=fgetl(spkfile);
        s=deblank(s);
        spkLine=spkLine+1;
        if StrCmp(s,'%'),
            continue
        end
        
        if StrCmp(s,'%EOF'),
            fprintf('\nERROR in line ');
            fprintf('%d: @ or >> is expected.\n',SB.StartLn);
            SB.status='error';
            return
        end
        
        if length(s)>MAX_PROBLTXT_LEN,
            fprintf('\nERROR in line ');
            fprintf('%d:\nthis line has length',SB.StartLn);
            fprintf(' larger than %d.',MAX_PROBLTXT_LEN);
            SB.status='error';
            return
        elseif length(s)>max_txtpt_length,
            max_txtpt_length=length(s);
        end
        
        if StrCmp(s,'>>'),
            % if this is the end of the problem part, ...
            break
        else
            SB.NTxtPt=SB.NTxtPt+1;
            if ~isempty(s),
                SB.TxtPt(SB.NTxtPt,1:length(s))=s;
            end
            if StrCmp(s,'\freeze')
                SB.FreezeTxtPoint=SB.NTxtPt;
            end
        end
    end
    
    SB.TxtPt=SB.TxtPt(1:SB.NTxtPt,1:max_txtpt_length);
    
end % if ~strcmp(SB.Cmd,'data') && ...

%endline=spkLine;
SB.EndLn=spkLine;

end