classdef problemD < problemG
    
    properties
        datafile;    % file with problem D database.
        truespecs;   % boolean variable, true if the data entry satisfies
                     % the specifications.
        choicespecs; % boolean variable, true if the data entry satisfies
                     % the choice specifications.
    end
    
    
    methods
        
        function q=problemD(S)
            q=q@problemG(S);
        end
        
    end
    
    methods (Access = protected)
       
        
        function q = ProcessCmdPt(q)
            
            ErrMsg='Cmd part of type D question must have at ';
            
            if q.NCmdPt<2,
                q.Sp_Error([ErrMsg,'least two lines'],'');
            elseif q.NCmdPt>3,
                q.Sp_Error([ErrMsg,'most three lines'],'');
            end
            
            % File with data
            q.datafile=strtrim(q.CmdPt(1,:));
            
            % "true statement" specifications
            q.truespecs=strtrim(q.CmdPt(2,:));
            
            % Choice specifications
            if q.NCmdPt==3,
                q.choicespecs=strtrim(q.CmdPt(3,:));
            else
                q.choicespecs='';
            end
        end
        
        function q = ProcessTxtPt(q)
            
            f=fopen(q.datafile);
            
            if f==-1,
                q.Sp_Error('Type D question datafile is not found',q.datafile);
            end
            
            chosenentries=char(ones(q.nques,120)*' ');
            
            % Initialize true or false value of the chosen entry.
            chosen_tf=zeros(q.nques); 
            
            curr_entry=0;
            q.nchosentrue=0;
            
            while ~feof(f),
                ss=strtrim(fgetl(f));
                if isempty(ss) || ss(1)=='%',
                    continue
                elseif StrCmp(ss,'-------'),
                    break
                end
                if ~isempty(q.choicespecs),
                    [~,bool]=SatisfiesSpecifications(ss,q.choicespecs);
                    if ~bool,
                        continue
                    end
                end
                curr_entry=curr_entry+1; 
                [entry,bool]=SatisfiesSpecifications(ss,q.truespecs);
                if curr_entry<=q.nques,
                    chosenentries(curr_entry,1:length(entry))=entry;
                    q.nchosentrue=q.nchosentrue+bool;
                    chosen_tf(curr_entry)=bool;
                else 
                    % throw a fair "coin" ...
                    x=randi(curr_entry);
                    if x <= q.nques,
                        % ... if lucky then replace a randomly 
                        % chosen unlucky entry by the new one.
                        j=randi(q.nques);
                        chosenentries(j,:)=char(ones(1,120)*' ');
                        chosenentries(j,1:length(entry))=entry;
                        q.nchosentrue=q.nchosentrue+bool-chosen_tf(j);
                        chosen_tf(j)=bool;
                    end
                end
            end
            
            fclose(f);
            
            % Write the body of the multiple choice question;
            % it is of this kind: ``How many of the following
            % ... are ...?''
            for k=1:q.NTxtPt,
                fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k,:)));
            end
            
            fprintf(q.outfile,'\\begin{enumerate}\n');
            for k=1:q.nques,
                ss=strtrim(chosenentries(k,:));
                ss=ProcessFString(ss);
                fprintf(q.outfile,'\\item %s\n',ss);
            end
            fprintf(q.outfile,'\\end{enumerate}\n\n');
            
            q.RawVolume=nchoosek(curr_entry,q.nques);
            
            % Set the correct answer as the number 
            % of "true statements"
            q.CorrAns(q.CRepeat) = char('0'+q.nchosentrue);

        end
        
    end
    
end % classdef problemD < problemG

