classdef problemB < problemI

    properties
        AlternativeAnswersString; % it is a line of this kind: 'False~True'
        bool;  % discrete variable, showing position of the correct answer
               % among multiple choice answers: 
               % bool==0 means A, bool==1 means B, bool==2 means C, etc
    end
    
    methods
        
        function q=problemB(S)
            q=q@problemI(S);
        end
        
    end
    
    methods (Access = protected)
        
        
        function q=SetRandPerm(q)
            % in question of problemB type we do not permute answers.
        end

        function q=SetCorrAns(q)
            % in problemB type the correct answer is set 
            % in the comand part as the value of special 
            % variable "bool" (for boolean).
            %
            % If bool==0, then the correst answer is (A),
            % if bool==1, then the correst answer is (B), etc

            q.bool = evalin('base', 'bool;');
            if q.bool==999,
                msg='The variable "bool" is undefined.';
                q.Sp_Error(msg,q.CmdPt(q.NCmdPt,:));
            end
            q.CorrAns(q.CRepeat)=char(65+q.bool);
        end
        
        function q=ProcessCmdPt(q)
            evalin('base', 'bool=999;');
            q=ProcessCmdPt@problemI(q);
        end
        
        function q=ProcessAnswerCmd(q)
            
            % "inss" is the last command of the command part 
            % of a type B spike block. This last command must 
            % have the format such as, for example, 
            %
            %       answer('No~Yes');  
            % or 
            %       answer('Even~Odd');
            % or 
            %       answer('Elliptic~Parabolic~Hyperbolic');
            
            % remove blank spaces 
            inss=strtrim(q.CmdPt(q.NCmdPt,:));
            
            if ~ StrCmp(inss,'answer('),
                msg='Last command of command part must be answer command.';
                q.Sp_Error(msg,inss);
            elseif ~strcmp(inss(end-1:end),');'),
                msg='An answer command must end with );';
                q.Sp_Error(msg,inss);
            end
            
            % the variable "a" will contain positions 
            % of the two quotes in inss.
            a=strfind(inss,'''');
            
            if length(a)~=2,
                msg='An answer command must have exactly two quotes.';
                q.Sp_Error(msg,inss);
            end
            
            % AlternativeAnswersString is the part of the answer command
            % such as 'Even~Odd'.
            q.AlternativeAnswersString=inss(a(1)+1:a(2)-1);
            
        end
        
        function q=ProcessAnswers(q)
            % If AlternativeAnswersString is, say, 'Even~Odd~Neither', then 
            % this function writes into out-file a line
            % of the following kind:
            %
            % (A) Even    (B) Odd    (C) Neither.
            
            fprintf(q.outfile,'\n\\medskip\\noindent\n');
            
            [vars,len,~]=SeparateVariables(q.AlternativeAnswersString,'~');
            q.NAltAnswers=len;
            
            % Write Multiple Choice answers.
            for k=1:q.NAltAnswers,
                fprintf(q.outfile,'(%c) \\ ',char('A'-1+k));
                fprintf(q.outfile,'%s \\ ',vars(k,:));
                fprintf(q.outfile,'\\quad \n');
            end
            
            fprintf(q.outfile,'\n');
        end
    end

end % classdef problemB