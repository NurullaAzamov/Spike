classdef problemG < problem
% Last edited: 20/02/2015

    properties
        nques;   % number of statements to be chosen
        nchosentrue; % number of true statements in a chosen random sample
    end
    
    methods

        function q=problemG(S)
            q=q@problem(S);
            
            % It is difficult to evaluate raw volume 
            % of a type G question, so we just set it to be 1000.
            q.RawVolume=1000;
            
        end
        
    end
    
    methods (Access = protected)
        
        
        function q=SetCorrAns(q)
            % This code should be overridden further, 
            % but just in case: 
            %if isempty(q.CorrAns),
              % q.CorrAns='?';
            %end
        end
        
        function q=ProcessAtLine(q)
            q=ProcessAtLine@problem(q);
            % Number of true/false statements which are to be chosen;
            % this number is given at @-line as the second parameter.
            % For example, @2;7; means we have to choose 7 statements.
            if ismember(q.TxtPtPar(2:end),'0123456789'),
                q.nques=str2double(q.TxtPtPar(2:end));
            else
                q.Sp_Error('Incorrect format of the @-line',q.TxtPtPar(2:end));
            end
        end
        
        function q = ProcessTxtPt(q)
            % Write the body of the multiple choice question;
            % it is of this kind: ``How many of the following
            % statements are true?''
            for k=q.FreezeTxtPoint+1:q.NTxtPt,
                fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k,:)));
            end
            
            % nchosentrue is the number of right statements chosen randomly.
            
            q.nchosentrue=0;
            
            fprintf(q.outfile,'\\begin{enumerate}\n');
            
            for k=1:q.nques,
                
                % This is what we do in type G questions.
                [s,b]=eval(q.CmdPt(1,:));
            
                fprintf(q.outfile,'\\item %s\n',s);
                
                q.nchosentrue=q.nchosentrue+b;
                
            end
            
            fprintf(q.outfile,'\\end{enumerate}\n');
            
            q.CorrAns(q.CRepeat) = char('0'+q.nchosentrue);
            
        end
        

        function q=ProcessAnswers(q)
            % do nothing
        end

    end
    
end % classdef problemG