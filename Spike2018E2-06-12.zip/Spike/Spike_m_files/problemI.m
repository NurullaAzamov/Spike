classdef problemI < problem
    % This class implements multiple choice
    % questions of type I.
    
    properties
        RandPerm; % random permutation of answers.
        answer;   % the answer string which the command part
                  % returns upon execution.
    end
    
    methods
        
        function q=problemI(S)
            % S is a spikeblock
            q=q@problem(S);
        end
        
    end
    
    methods (Access = protected)
        
        function q=SetRandPerm(q)
            q.RandPerm = randperm(q.NAltAnswers);
        end
        
        function q=SetCorrAns(q)
            if q.NAltAnswers>1,
                % We choose a random permutation of answers so that
                % RandPerm(CorrAns)=1.
                for k=1:q.NAltAnswers,
                    if q.RandPerm(k)==1,
                        q.CorrAns(q.CRepeat)=char(64+k);
                        break
                    end
                end
            else
                q.CorrAns(q.CRepeat) = 'A';
            end
        end
        
        function q=ProcessCmdPt(q)
            % Execute commands of the command part.
            % If an attempt to evaluate fails, give an error message.

            NAttempts=0;
            Answer_Attempts=evalin('base','ANSWER_ATTEMPTS');
            
            % We run this while-cycle until "condition" is true 
            % (which happens, or should happen, in 99.9% 
            %  of cases anyway).
            while true,
                
                NAttempts=NAttempts+1;
                if NAttempts >= Answer_Attempts,
                    fprintf('\nQ%d: too many attepmts.\n',q.QuesNum);
                    fprintf('%s\n',q.TxtPt(1,:));
                    error('The program terminated.');
                end
                evalin('base','condition=1;');
                
                % Run the command part,
                % except the last answer command;
                % (so we have ...:q.NCmdPt-1, not ...:q.NCmdPt).
                
                if q.CRun==1
                    A0=1;
                else
                    A0=q.FreezeCmdPoint+1;
                end
                
                for k=A0:q.NCmdPt-1,
                    
                    out = strtrim(q.CmdPt(k,:));
                    
                    if StrCmp(out,'freeze'),
                        continue
                    end
                    
                    if StrCmp(out,'rawvolume'),
                        ket=strfind(out,')');
                        factor=evalin('base',out(11:ket-1));
                        q.RawVolume=q.RawVolume*factor;
                        continue
                    end
                    
                    try
                        [status,q.RawVolume]=Spike2Matlab(out,q.RawVolume,q.CRun);
                        if ~isempty(status),
                            q.Sp_Error(status,out);
                        end
                    catch ME
                        q.Sp_Error(ME.message,out);
                    end
                    
                    if evalin('base','~condition;'),
                        break
                    end
                    
                end % for k
                
                if evalin('base','~condition;'),
                    continue
                else
                    break
                end
                
            end
            
            % Process the last answer command.
            % This command produces "answer" variable.
            q=q.ProcessAnswerCmd;
            
        end
        
        function q=ProcessAnswerCmd(q)
            
            % "inss" is the last command of the command part of a
            % type I spike block. This last command must be an answer
            % command such as
            %
            %  answer('#4e',r);
            %
            % The aim of this function is to produce the variable 
            % "answer" by processing the answer command. 
            
            % remove blank spaces
            inss=strtrim(q.CmdPt(q.NCmdPt,:));
            
            if ~StrCmp(inss,'answer('),
                msg='Last command of the command part must be answer command.';
                q.Sp_Error(msg,inss);
            elseif ~StrEnd(inss,');'),
                msg='An answer command must end with );';
                q.Sp_Error(msg,inss);
            end
            
            % the variable "a" will contain positions
            % of the quotes in inss.
            a=strfind(inss,'''');
            
            % StrPt is the first argument of the answer command
            % such as '(#4r,#4r)'
            StrPt=inss(a(1)+1:a(end)-1);
            StrPt=['''',strrep(StrPt,'''',''''''),''''];
            
            % VarPt is the second argument of the answer command
            % such as 'a,b'
            VarPt=inss(a(end)+1:end-2);
            
            outss=sprintf('xprintf(%s,''%s'');',StrPt,VarPt);
            
            try
                [q.answer,pars,status,logstatus]=evalin('base',outss);
            catch ME
                q.Sp_Error(ME.message,outss);
            end
            
            if ~logstatus
                fprintf(q.logfile,'%s',logstatus);
            end
            
            if ~isempty(status)
                q.Sp_Error(status,inss);
            end

            % if there is a double hashtag operator in the answer command
            if ismember('#',q.answer)   %was ~isempty(strfind(q.answer,'#')),
                outss=sprintf('xprintf(''%s'',''%s'');',q.answer,pars);
                try
                    [q.answer,pars,status,logstatus]=evalin('base',outss);
                catch ME
                    q.Sp_Error(ME.message,outss);
                end
                
                if ~logstatus
                    fprintf(q.logfile,'%s',logstatus);
                end
                
                if ~isempty(status)
                    q.Sp_Error(status,inss);
                end
                
            end
            
            if ~isempty(pars)
                msg='Invalid number of paramaters in an answer command.';
                q.Sp_Error(msg,inss);
            end
            
        end
        
        function q=ProcessTxtPt(q)
            % This function processes the text part of spike-block.
            % Namely, it reads lines of the text part and replaces
            % formatting #-operators such as #r, #"\quad "t, #%6d, etc
            % by the corresponding values of the text part variables,
            % which are given as the second argument of the @-line.
            % The lines of the text part after being processed are written
            % into the output LaTeX file.
            
            
            TempTxtPt=q.TxtPt;

            % params are parameters of the text part,
            % such as ',a,b1,b2,N1,N2'
            params=q.LiquidTxtPtPar;
            
            there_are_any_hashtags=1;
            
            A0=q.FreezeTxtPoint+1;
            
            % Process hashtag and double hashtag operators,
            % if there are any. 
            while there_are_any_hashtags,
                % this cycle runs at most twice, and mostly likely 
                % only once. 
                
                there_are_any_hashtags=0;

                for k=A0:q.NTxtPt,
                    
                    % Get a line of the text part.
                    ss=deblank(TempTxtPt(k,:));
                    
                    there_are_any_hashtags = ~ isempty(strfind(ss,'##'));

                    [outstr,params]=ProcessHashtags(q,ss,params);
                    
                    len=length(TempTxtPt(k,:));
                    TempTxtPt(k,:)=char(ones(1,len)*' ');
                    
                    TempTxtPt(k,1:length(outstr))=outstr;
                end
                
            end
            
            % Write the processed text part into the output LaTeX file.
            % (we don't need to write the question number, since this
            % have been done by q.TypeQuesNum function before.
            for k=A0:q.NTxtPt,
                % Get a line of the hashtag processed text part.
                ss=deblank(TempTxtPt(k,:));

                hash_tags_present = ~ isempty(strfind(ss,'#'));
                if hash_tags_present,
                    % by now all hashtags should have been processed,
                    % so there should be none left.
                    fprintf('Error: a hashtag was found \n');
                    fprintf('where it shoould not be.\n');
                end
                
                fprintf(q.outfile,'%s\n',ss);
            end
            
            if ~isempty(params),
                msg='Too many parameters.';
                q.Sp_Error(msg,['@',q.AtLine]);
            end
            
        end
        
        function q=ProcessAnswers(q)
            if q.NAltAnswers>1,
                MAX_ANSWER_LENGTH=207;
                
                try
                    Answer_Attempts=evalin('base','ANSWER_ATTEMPTS');
                catch ME
                    q.Sp_Error(ME.message,'ANSWER_ATTEMPTS?');
                end
                
                try
                    Ans_Attempts=evalin('base','ANS_ATTEMPTS');
                catch ME
                    q.Sp_Error(ME.message,'ANS_ATTEMPTS?');
                end
                
                answ=char(ones(q.NAltAnswers,MAX_ANSWER_LENGTH)*32);
                anslen=zeros(1,q.NAltAnswers);
                NAttempts=0;
                
                anslen(1)=length(q.answer);
                if anslen(1) > MAX_ANSWER_LENGTH,
                    q.Sp_Error('answer line is too long',q.answer);
                elseif anslen(1) ==0,
                    q.Sp_Error('answer line is empty','');
                end
                answ(1,1:anslen(1))=q.answer;
                
                % To generate wrong answers, we run the command part
                % NAltAnswers-1 times again.
                for m=2:q.NAltAnswers
                    q.CRun=m;
                    while NAttempts<1000,
                        q=q.ProcessCmdPt;
                        
                        % Check that the current answer is different
                        % from the previous ones.
                        answer_is_good=true;
                        for j=1:m-1,
                            if strcmp(q.answer,answ(j,1:anslen(j))),
                                answer_is_good=false;
                                break
                            end
                        end
                        
                        if answer_is_good,
                            anslen(m)=length(q.answer);
                            if anslen(m) > MAX_ANSWER_LENGTH,
                                msg='answer line is too long';
                                q.Sp_Error(msg,q.answer);
                            end
                            answ(m,1:anslen(m))=q.answer;
                            
                            if NAttempts >= Ans_Attempts && q.Version==1,
                                fprintf(q.logfile,'Q%d: ',q.QuesNum);
                                fprintf(q.logfile,'%d ',NAttempts);
                                fprintf(q.logfile,'attempts to find a ');
                                fprintf(q.logfile,'non-repeating answer\n');
                                evalin('base','LogWarnings=LogWarnings+1;');
                            end
                            
                            break
                        else
                            NAttempts=NAttempts+1;
                            if NAttempts >= Answer_Attempts,
                                fprintf('\nToo many attepmts to ');
                                fprintf('find a non-repeating answer.\n');
                                fprintf('%s',q.TxtPt(1,:));
                                fprintf('q.NAltAnswers: %d\n',q.NAltAnswers);
                                fprintf('\nContinue? (Y/N)');
                                yn=input('','s');
                                if (yn=='Y') || (yn=='y'),
                                    fprintf(q.logfile,'\nSpike: I''ll try');
                                    fprintf(q.logfile,' 50 more times.\n');
                                    Answer_Attempts=Answer_Attempts+50;
                                else
                                    fclose(q.outfile);
                                    fprintf('The program has ');
                                    fprintf('been terminated.\n');
                                    return
                                end
                            end
                            continue
                        end
                    end
                end
                
                
                fprintf(q.outfile,'\n\\medskip\\noindent\n');
                
                % Write Multiple Choice answers.
                for k=1:q.NAltAnswers,
                    ik=q.RandPerm(k);
                    fprintf(q.outfile,'(%c) \\ ',char(64+k));
                    fprintf(q.outfile,'%s\\quad\n',answ(ik,1:anslen(ik)));
                end
            else
                fprintf(q.outfile,'\n\\medskip\\noindent\n');
                if q.NAltAnswers==1,
                    fprintf(q.outfile,'{\\it Answer:} \\ ');
                else
                    fprintf(q.outfile,'%%{\\it Answer:} \\ ');
                end
                fprintf(q.outfile,'%s',q.answer);
            end
        end
        
    end
    
end % classdef problemI
