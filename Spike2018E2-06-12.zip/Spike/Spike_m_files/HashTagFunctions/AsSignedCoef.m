function ss=AsSignedCoef(x)
% This function returns fraction or more generally
% algebraic representation
% of a real number x in LaTeX format, which is supposed to be used
% as a coefficient. So, if x=1, then the result is ss='+'.

ss=AsCoef(x);
if x>0
    ss=['+',ss];
end

end