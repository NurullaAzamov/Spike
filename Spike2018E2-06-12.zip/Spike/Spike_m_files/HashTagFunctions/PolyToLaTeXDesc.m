function s=PolyToLaTeXDesc(a)
% Given a vector a=(a0,a1,...), returns a LaTeX string with polynomial 
% a_nx^n+...+ a_2x^2+a_1x+a_0.

% Remove trailing zeros. 
k=length(a);

while a(k)==0, 
     k=k-1; 
     if k==0, break; end
end
n=k;

% If zero polynomial, then ...
if n==0, 
    s='0'; 
    return; 
end

a=a(1:n);

% The polynomial is non-zero. Then ...
k=1;
while a(k)==0, 
     k=k+1; 
     if k==n, break; end
end

% At this point, a(k) is the first non-zero coefficient,
% and a(n) is the last non-zero coefficient.

% If the polynomial is constant then ...
if deg(a)==0, 
   s=sprintf('%d',a(1));
   return
end

% At this point, the polynomial is not constant.
% The degree n-1 is at least 1. 

if n-1>1,
   s=sprintf('%sx^{%d}',AsCoef(a(n)),n-1);
elseif n-1==1, 
   s=sprintf('%sx',AsCoef(a(n)));
end

for j=n-1:-1:k,
    if a(j)==0, 
        continue; 
    end
    if j-1==1,
        s=sprintf('%s%sx',s,AsSignedCoef(a(j)));
    elseif j-1 > 1,
        s=sprintf('%s%sx^{%d}',s,AsSignedCoef(a(j)),j-1);
    elseif j-1==0,
        if a(j)<0,
          s=sprintf('%s%d',s,a(j));
        else 
          s=sprintf('%s+%d',s,a(j));
        end
    end
end

end