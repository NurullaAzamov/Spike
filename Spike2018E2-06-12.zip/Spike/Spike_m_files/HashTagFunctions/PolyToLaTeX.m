function s=PolyToLaTeX(a)
% Given a vector a=(a0,a1,...), this function 
% returns a LaTeX string with polynomial 
% a_0+a_1x+a_2x^2+...+a_nx^n.


% Remove trailing zeros. 
k=length(a);
while a(k)==0 
     k=k-1; 
     if k==0 
         break
     end
end
n=k;

% If a is a zero polynomial, then ...
if n==0
    s='0'; 
    return
end

% The polynomial is non-zero. Then ...
a=a(1:n);
k=1;
while a(k)==0
     k=k+1; 
     if k==n 
         break
     end
end
% a(k) is the first non-zero coefficient,
% and a(n) is the last non-zero coefficient.

if k-1==0
    if a(k)==1
        s='1';
    elseif a(k)==-1
        s='-1';
    else
      s=sprintf('%s',AsCoef(a(k)));
    end
elseif k-1==1
    s=sprintf('%sx',AsCoef(a(k)));
else
    s=sprintf('%s x^{%d}',AsCoef(a(k)),k-1);
end

for j=k+1:n
    if a(j)==0 
        continue
    end
    if j-1==1
        s=sprintf('%s%sx',s,AsSignedCoef(a(j)));
    else
        s=sprintf('%s%sx^{%d}',s,AsSignedCoef(a(j)),j-1);
    end
end

end