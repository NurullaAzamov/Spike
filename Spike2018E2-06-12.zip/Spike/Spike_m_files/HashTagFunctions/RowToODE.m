function s=RowToODE(input_row)
% Given a vector input_row=(a0,a1,...), returns a LaTeX string with  
% a_n y^(n)+...+ a_2y''+a_1y'+a_0y.

    function sss=dyk(m)
    % This function returns a string with m-th derivative of y.
    % For example, dyk(2) is y'', dyk(4) is y^{(4)}.
      if m==0
          sss='y';
      elseif m==1
          sss='y\dash';
      elseif m==2
          sss='y\ddash';
      elseif m==3
          sss='y\dddash';
      elseif m>3
          sss=sprintf('y^{(%d)}',m);
      end
    end

n=length(input_row);
s='';

for j=1:n,
    if input_row(j)==0, 
        continue
    else
        s2=dyk(n-j);
        s=sprintf('%s%s%s',s,AsSignedCoef(input_row(j)),s2);
    end
end

if isempty(s),
    s='0';
elseif s(1)=='+',
    s=s(2:end);
end

end