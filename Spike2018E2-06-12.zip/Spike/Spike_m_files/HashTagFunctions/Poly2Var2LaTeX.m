function ss=Poly2Var2LaTeX(p)
% This function returns in a string ss a polynomial 
% of two variables p(x,y) in LaTeX format.

ss='';

[m,n]=size(p);
m=m-1;
n=n-1;
if m~=n,
    error('m~=n');
end

for k=0:n,
    for j=k:-1:0,
        coef=p(j+1,k-j+1);
        if coef~=0,
            if coef==1,
                if j+k>0
                    t='+';
                else
                    t='+1';
                end
                t='+';
            elseif coef==-1,
                if j+k>0
                    t='-';
                else
                    t='-1';
                end
            else
                t=sprintf('%s',AsCoef(coef));
                if coef>0,
                    t=['+',t];
                end
            end
            ss=[ss,t];
            
            mm=j;
            if mm==1,
                t='x';
            elseif mm==0,
                t='';
            else
                t = sprintf('x^{%d}',mm);
            end
            
            ss=[ss,t];

            mm=k-j;
            if mm==1,
                t='y';
            elseif mm==0,
                t='';
            else
                t = sprintf('y^{%d}',mm);
            end
            
            ss=[ss,t];
            
        end
    end
end

ss=strtrim(ss);
if numel(ss)==0
    error('The string is empty?');
end
if ss(1)=='+', 
    ss=ss(2:end);
end

end