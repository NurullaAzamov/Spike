function ss=AsCoef(x)
% This function returns fraction representation
% of a real number x in LaTeX format, which is supposed to be used
% as a coefficient. So, if x=1, then the result is ss='+'.

if IsZero(x)
    error('AsCoef: zero argument.'); 
elseif IsZero(1-x) 
    ss=''; 
elseif IsZero(1+x)
    ss='-';
else
    ss=LaTeXFrac(x);
end

end
