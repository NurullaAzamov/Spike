function [outss,status]=LaTeXFrac(x)
% LaTeXFrac(x) returns a rational number x in the LaTeX format. 
% For example, if x=0.3333..., then LaTeXFrac(x) returns \frac{1}{3}.

    function bool=IsInteger(x)
        bool=(abs(x-round(x)) < 5*10^(-12));
    end

ZERO=5*10^(-12); % "machine zero".


% "status" is not empty, if LaTeXFrac fails to find reasonable
% represntation of the real number x.
status='';

if x<-ZERO, 
    sign='-';
else
    sign='';
end

x=abs(x);

%[m,n]=rat(x,ZERO);
if x < ZERO,       % if x is zero
    
    outss = '0';
    
elseif IsInteger(x),       % if x is an integer
    
    outss=sprintf('%d',round(x));
    
elseif IsFraction(x),  % if x is a fraction with an acceptable denominator
    
    [m,n]=rat(x,ZERO);
    outss=sprintf('\\frac{%d}{%d}',m,n);
    
elseif IsInteger(x^2),  % if x is sqrt of an integer
    
    y=round(x^2);
    if isprime(y),
        outss=sprintf('\\sqrt{%d}',y);
    else
        [s,t]=int_times_sqrt(y);
        
        if s==1,
            outss=sprintf('\\sqrt{%d}',t);
        else
            outss=sprintf('%d\\sqrt{%d}',s,t);
        end
    end
    
elseif IsInteger(x^3),  % if x is a cubic root of an integer
    
    y=round(x^3);
    if isprime(y),
        outss=sprintf('\\sqrt[3]{%d}',y);
    else
        [s,t]=int_times_cubicsqrt(y);
        
        if s==1,
            outss=sprintf('\\sqrt[3]{%d}',t);
        else
            outss=sprintf('%d\\sqrt[3]{%d}',s,t);
        end
    end

elseif IsInteger(x/pi),  % if x/pi is an integer
    
    outss=sprintf('%d\\pi',round(x/pi));
    
elseif IsInteger(x*pi),  % if x*pi is an integer
    
    outss=sprintf('\\frac{%d}{\\pi}',round(x*pi));
    
elseif IsFraction(x/pi),  % if x/pi is a fraction 
    
    [m,n]=rat(x/pi,ZERO);
    if m~=1,
        outss=sprintf('\\frac{%d\\pi}{%d}',m,n);
    else
        outss=sprintf('\\frac{\\pi}{%d}',n);
    end

elseif IsFraction(x*pi),  % if x*pi is a fraction 
    
    [m,n]=rat(x*pi,ZERO);
    outss=sprintf('\\frac{%d}{%d\\pi}',m,n);

elseif IsInteger(x^2/pi),  % if x^2/pi is an integer
    
    [s,t]=int_times_sqrt(x^2/pi);
    
    if s==1,
        if t==1,
            outss=sprintf('\\sqrt{\\pi}');
        else 
            outss=sprintf('\\sqrt{%d\\pi}',t);
        end
    else
        if t==1,
            outss=sprintf('%d\\sqrt{\\pi}',s);
        else 
            outss=sprintf('%d\\sqrt{%d\\pi}',s,t);
        end
    end
    
elseif IsFraction(log(x)),  
    
    [m,n]=rat(log(x),ZERO);
    if abs(log(x)-1)<ZERO,
        outss=sprintf('e');
    elseif n==1,
        outss=sprintf('e^{%d}',m);
    elseif m>0
        outss=sprintf('e^{\\frac{%d}{%d}}',m,n);
    else
        outss=sprintf('e^{-\\frac{%d}{%d}}',abs(m),n);
    end
    
elseif IsFraction(x^2), 
    [m,n]=rat(x^2,ZERO);
    
    [s,t]=int_times_sqrt(m);
    [p,q]=int_times_sqrt(n);
    
    if s==1,
        outss=sprintf('\\frac{\\sqrt{%d}}{%d}',t*q,p*q);
    else
        outss=sprintf('\\frac{%d\\sqrt{%d}}{%d}',s,t*q,p*q);
    end
elseif IsFraction(x^2/pi), 
    [m,n]=rat(x^2/pi,ZERO);
    
    [s,t]=int_times_sqrt(m); % s*sqrt(t)=m
    [p,q]=int_times_sqrt(n); % p*sqrt(q)=n
    
    if s==1,
        outss=sprintf('\\frac{\\sqrt{%d\\pi}}{%d}',t*q,p*q);
    else
        outss=sprintf('\\frac{%d\\sqrt{%d\\pi}}{%d}',s,t*q,p*q);
    end
elseif IsFraction(x^2*pi), 
    [m,n]=rat(x^2*pi,ZERO);
    
    [s,t]=int_times_sqrt(m);
    [p,q]=int_times_sqrt(n);
    
    if s==1,
        outss=sprintf('\\frac{\\sqrt{%d}}{%d\\sqrt{\\pi}}',t*q,p*q);
    else
        outss=sprintf('\\frac{%d\\sqrt{%d}}{%d\\sqrt{\\pi}}',s,t*q,p*q);
    end
elseif IsFraction(x^3), % if x is a cubic root of a rational number
    [m,n]=rat(x^3,ZERO);
    [p,q]=int_times_cubicsqrt(n);
    [s,t]=int_times_cubicsqrt(m*q^2);
    [s,Denom]=rat(s/(p*q),ZERO);
    
    if s==1,
        outss=sprintf('\\frac{\\sqrt[3]{%d}}{%d}',t,Denom);
    else
        outss=sprintf('\\frac{%d\\sqrt[3]{%d}}{%d}',s,t,Denom);
    end
elseif abs(x)<20 && IsFraction(exp(x)),  
    
    [m,n]=rat(exp(x),ZERO);
    if n==1,
        [ispower,power]=IsPower(m);
        if ~ispower,
            outss=sprintf('\\ln\\,%d',m);
        else 
            rr=round(m^(1/power));
            outss=sprintf('%d\\ln\\,%d',power,rr);
        end
    else
        [ismpower,mpower]=IsPower(m);
        [isnpower,npower]=IsPower(n);
        if (ismpower && isnpower),
            x=round(m^(1/mpower));
            y=round(n^(1/npower));
        end
        if (ismpower && isnpower) && (mpower==npower),
            outss=sprintf('%d\\ln\\,\\frac{%d}{%d}',mpower,x,y);
        elseif (ismpower && isnpower) && (mod(mpower,npower)==0),
            x=round(m^(1/npower));
            outss=sprintf('%d\\ln\\,\\frac{%d}{%d}',npower,x,y);
        elseif (ismpower && isnpower) && (mod(npower,mpower)==0),
            y=round(n^(1/mpower));
            outss=sprintf('%d\\ln\\,\\frac{%d}{%d}',mpower,x,y);
        else
            outss=sprintf('\\ln\\,\\frac{%d}{%d}',m,n);
        end
    end
    
else
    outss=sprintf('%.4f',x);
    status='LaTeXFrac: very transcendental number';
end

outss=[sign,outss];

end

function [s,t]=int_times_sqrt(y)
% Writes sqrt(x) as s * sqrt(t).
%
y=round(y);
p=primes(3000);
N=length(p);
z=factor(y);
a=zeros(1,N);
for i=1:N,
    a(i)=sum(z==p(i));
end
c=mod(a,2);
b=(a-c)/2;

s=prod(p.^b);
t=prod(p.^c);

if NotZero(y-s^2*t),
    error('LaTeXFrac: int_times_sqrt.');
end

end

function [s,t]=int_times_cubicsqrt(y)
% Writes sqrt[3](x) as s * sqrt[3](t).
%
p=primes(3000);
N=length(p);
z=factor(y);
a=zeros(1,N);
for i=1:N,
    a(i)=sum(z==p(i));
end
c=mod(a,3);
b=(a-c)/3;

s=prod(p.^b);
t=prod(p.^c);

if NotZero(y-s^3*t),
    error('LaTeXFrac: int_times_sqrt.');
end

end