function [alpha,beta] = int_plus_intsqrt(x)
%
% It is incomplete.
%
% This function will try to write a real number x
% in the form alpha + beta sqrt(2), where alpha
% and beta are integers, assuming that alpha and beta 
% are non-zero and not very large. 

eps=5*10^(-13);

for a=1:200,
    y = (x-a)^2/2;
    
    if abs(y^2 - round(y^2)) < eps,
       alpha = a;
       beta = sign(x-a)*round(sqrt(y));
       return
    end
    
    y = (x+a)^2/2;
    
    if abs(y^2 - round(y^2)) < eps,
       alpha = -a;
       beta = sign(x-a)*round(sqrt(y));
       return
    end
end

end