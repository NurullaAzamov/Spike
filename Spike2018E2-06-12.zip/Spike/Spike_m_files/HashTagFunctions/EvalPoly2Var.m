function f=EvalPoly2Var(p,x,y)
% This function evaluates
% a polynomial of two variables at (x,y).
% Entries which are below the skew-diagonal of p are ignored.

[m,n]=size(p);
m=m-1;
n=n-1;
if m~=n,
    error('m~=n');
end

f=0;

for k=0:n,
    for j=k:-1:0,
        f=f+p(j+1,k-j+1)*x^j*y^(k-j);
    end
end


end