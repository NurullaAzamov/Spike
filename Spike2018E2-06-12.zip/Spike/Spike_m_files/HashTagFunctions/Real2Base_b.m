function s=Real2Base_b(x,b,k,option)
% This functions returns in LaTeX format a string s
% which contains base b representation of a real number x in 
%  1) scientific form, if option =='scientific',
%  2) computer form, if option =='computer',
%  3) integer form, if option=='integer'.


if x==0,
    s='0';
    return
end

d='0123456789ABCDEF';

if strcmp(option,'integer') 
    k=floor(log(abs(x))/log(b))+2;
elseif strcmp(option,'fixed') 
    kk=k;
    k=floor(log(abs(x))/log(b))+1+kk;
end

[sgn,mnts,expt]=Real2SciForm(x,b,k);
ss=d(mnts+1);

if strcmp(option,'computer'),
    s=sprintf('0.%s\\cdot %d^{%d}',ss,b,expt);
elseif strcmp(option,'scientific'),
    if expt==1,
        s=sprintf('%c.%s',ss(1),ss(2:end));
    else
        s=sprintf('%c.%s\\cdot %d^{%d}',ss(1),ss(2:end),b,expt-1);
    end
elseif strcmp(option,'integer'),
    s=ss(1:expt);
elseif strcmp(option,'fixed'),
    if k>kk,
        s=sprintf('%s.%s',ss(1:end-kk),ss(end-kk+1:end));
    else
        s=sprintf('0.%s%s',char(ones(1,kk-k)*'0'),ss(1:k));
    end
else
    error('Unknown option.');
end

if sgn==-1,
    s=['-',s];
end

end