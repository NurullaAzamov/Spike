function bool=IsFraction(x)
% This function investigates whether 
% a real number x can be well approximated
% by a quotient with a ``good'' denominator.
% The function LaTeXFrac.m, and therefore xprintf.m too,
% heavily rely on IsFraction. 
%
% Numerical experiments have shown that a randomly chosen
% number from [0,1] is practically never a quotient with 
% a ``good'' denominator.
%
% Here a good denominator means that it is 
% 1) not very big (less than 10000),
% 2) is not divisible by very large primes (larger than 100),
% 3) is not divisible by two or more large primes (larger than 20),
% 3) is not divisible by three or more primes larger than 10.
%
% The number of good denominators is 3007. 
% The three largest good denominators are 9996, 9990 and 9984. 
%
%
% Among the first 1000 natural numbers 656 are good denominators.
% The remaining bad ones are here: 
% 101 103 107 109 113 127 131 137 139 149 151 157 163 167 173 179 181 191 
% 193 197 199 202 206 211 214 218 223 226 227 229 233 239 241 251 254 257 
% 262 263 269 271 274 277 278 281 283 293 298 302 303 307 309 311 313 314 
% 317 321 326 327 331 334 337 339 346 347 349 353 358 359 362 367 373 379 
% 381 382 383 386 389 393 394 397 398 401 404 409 411 412 417 419 421 422 
% 428 431 433 436 439 443 446 447 449 452 453 454 457 458 461 463 466 467 
% 471 478 479 482 487 489 491 499 501 502 503 505 508 509 514 515 519 521 
% 523 524 526 529 535 537 538 541 542 543 545 547 548 554 556 557 562 563 
% 565 566 569 571 573 577 579 586 587 591 593 596 597 599 601 604 606 607 
% 613 614 617 618 619 622 626 628 631 633 634 635 641 642 643 647 652 653 
% 654 655 659 661 662 667 668 669 673 674 677 678 681 683 685 687 691 692 
% 694 695 698 699 701 706 707 709 713 716 717 718 719 721 723 724 727 733 
% 734 739 743 745 746 749 751 753 755 757 758 761 762 763 764 766 769 771 
% 772 773 778 785 786 787 788 789 791 794 796 797 802 807 808 809 811 813 
% 815 818 821 822 823 824 827 829 831 834 835 838 839 841 842 843 844 849 
% 851 853 856 857 859 862 863 865 866 872 877 878 879 881 883 886 887 889 
% 892 894 895 898 899 904 905 906 907 908 909 911 914 916 917 919 921 922 
% 926 927 929 932 933 934 937 939 941 942 943 947 951 953 955 956 958 959 
% 961 963 964 965 967 971 973 974 977 978 981 982 983 985 989 991 993 995 
% 997 998 

% Denom is the denominator of a rational approximation of x. 

[~,Denom]=rat(x,5*10^(-14));

prms=factor(Denom);

% Make sure that the denominator ...
% ... is not too big,
b1=(Denom < 10000); 
% ... is not divisible by very large primes,
b2=(max(prms)<100); 
% ... is not divisible by two or more large primes.
b3=(sum(prms>20)<2);

b4=(sum(prms>10)<3);

bool=b1 & b2 & b3 & b4;

end
