function sa=Perm2ShortCycleProdLaTeX(a,X)
% This function returns cycle product representation of a permutation a
% in LaTeX format. The difference with Perm2CycleProdLaTeX(a)
% is that this function omits trivial length one cycles. 

[C,s]=Perm2CycleProd(a);
sa='';

A=char(97:122); % 'abcdefghijklmnopqrstuvqxyz';
if nargin >1
    if X=='A'
        A=upper(A);
    end
else 
    X='n';
end

for j=1:length(s),
    if s(j)==1, 
        continue
    end
    ss='';
    for k=1:s(j),
        if nargin <2 || X=='n'
            ss=sprintf('%s%d',ss,C(j,k));
        elseif X=='a' || X =='A'
            ss=sprintf('%s%c',ss,A(C(j,k)));
        end
    end
    sa=sprintf('%s(%s)',sa,ss);
end

end
