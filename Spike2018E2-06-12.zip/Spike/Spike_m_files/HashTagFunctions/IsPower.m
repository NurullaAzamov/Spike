function [bool,power]=IsPower(x)
% This function returns true,
% if x is a power of an integer.

if isprime(x),
    bool=0;
    power=1;
    return
end
power=1;

a=factor(x);

prms=primes(1000);
N=length(prms);

pwr=zeros(1,N);

for k=1:N,
    pwr(k)=sum(a==prms(k));
end

bool=0;

for k=1:10,
    if sum(mod(pwr,prms(k)))==0, % power is at least prms(k)
        bool=1;
        power=power*prms(k);
        x=round(x^(1/power));
        while 1
            [bb,pp]=IsPower(x);
            if bb,
                power=power*pp;
                x=round(x^(1/pp));
            else
                break
            end
        end
        break
    end
end

end