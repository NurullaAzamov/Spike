function sa=Perm2LaTeX(a,X)
% This function returns a string
% which contains a permutation a in LaTeX format.
% The parameter X regulates what to permute: numbers
% (by default, if X is absent or 'n'), lower case letters if X = 'a',
% or upper case letter if X = 'A'.

n=length(a);

A=char(97:122); % 'abcdefghijklmnopqrstuvqxyz';

if nargin>1
    if X=='a'
    elseif X=='A' 
        A = upper(A);
    elseif X=='n' 
    else
        error('unexpected X');
    end
else X='n';
end

S=sprintf('\\left(%c  \\begin{array}',char(13));
S=sprintf('%s{%s}%c    ',S,ones(1,n)*'c',char(13));

for j=1:n-1
    if X=='n'
        S=sprintf('%s%d&',S,j);
    elseif X=='a' || X=='A'
        S=sprintf('%s%c&',S,A(j));
    end
end

if X=='n'
    S=sprintf('%s%d\\\\%c    ',S,n,char(13));
elseif X=='a' || X=='A'
    S=sprintf('%s%c\\\\%c    ',S,A(n),char(13));
end

for j=1:n-1
    if X=='n'
        S=sprintf('%s%d&',S,a(j));
    elseif X=='a' || X=='A'
        S=sprintf('%s%c&',S,A(a(j)));
    end
end

if X=='n'
    S=sprintf('%s%d%c',S,a(n),char(13));
elseif X=='a' || X=='A'
    S=sprintf('%s%c%c',S,A(a(n)),char(13));
end

sa=sprintf('%s  \\end{array}%c\\right)',S,char(13));

end
