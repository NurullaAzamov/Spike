function [sgn,mantissa,exponent] = Real2SciForm(x,b,k)
% This function returns sign, mantissa and exponent
% of the computer form of the number x, using rounding method
% for rounding.
% 
% Input:  x, a real number,
%         b, base,
%         k, mantissa length.
%
% Output: sign, mantissa, exponent

mantissa=zeros(1,k);
sgn=sign(x);
x=abs(x);
if sgn==0,
    exponent=0;
    return
end

exponent=floor(log(x)/log(b))+1;
x=x/b^exponent;

for j=1:k,
    x=x*b;
    mantissa(j)=floor(x);
    x=x-floor(x);
end

if x>=1/2,
    for j=k:-1:1,
        if mantissa(j)<b-1,
            mantissa(j)=mantissa(j)+1;
            break
        else
            if j==1,
                mantissa(j)=1;
                exponent=exponent+1;
            else
                mantissa(j)=0;
            end
        end
    end
end
    
end
