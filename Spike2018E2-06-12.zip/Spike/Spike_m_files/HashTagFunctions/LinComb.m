function outs=LinComb(a,x,desc)
% Given a vector a=(a0,a1,...), 
% and a vector of strings x='x0~x1~x2~x3~...';
% this function returns a LaTeX string a_0x0+a_1x1+a_2x2+...,
% provided desc==0. If desc==1,
% then the function returns ...+a_2x2+a_1x1+a_0x0.

if nargin<2
    x='';
    desc=0;
elseif nargin<3
    desc=0;
end

n=length(a);
outs='';

for j=1:n
    [s,x]=strtok(x,'~');
    if isempty(s)
        s='1';
    end
    if a(j)==0
        continue
    elseif strcmp(s,'1') && NotZero(abs(a(j))-1)
        s='';
    end
    if desc
       outs=sprintf('%s%s%s',AsSignedCoef(a(j)),s,outs);
    else
       outs=sprintf('%s%s%s',outs,AsSignedCoef(a(j)),s);
    end
end

if isempty(outs)
    outs='0';
elseif outs(1)=='+'
    outs=outs(2:end);
end

end