function S = LaTeXMatrix(A,k)
% LaTeXMatrix(A) returns a string 
% which represents the matrix A in LaTeX format.
% If k=0, then entries are written in the format rat,
% otherwise entries are written in the format %.*f with *=k.

    function s=type_a_row(a,k)
    % This function types in LaTeX format
    % the row a; for example, if a=[1,2,4], then 
    % type_a_row(a) returns '1 & 2 & 4 \\'.
    
    s='';
    if k==0,
        for j=1:n-1
            aa=LaTeXFrac(a(j));
            s=sprintf('%s%s&',s,aa);
        end
        aa = LaTeXFrac(a(n));
        s = sprintf('%s%s',s,aa);
    else 
        for j=1:n-1
            s=sprintf('%s%.*f&',s,k,a(j));
        end
        s = sprintf('%s%.*f',s,k,a(n));
    end
    end

[m,n]=size(A);

S='';

for i=1:m
%    S=sprintf('%s    %s\\\\@n',S,type_a_row(A(i,:),k));
    S=sprintf('%s    %s\\\\%c',S,type_a_row(A(i,:),k),char(13));
end

S=sprintf('%c  \\begin{matrix}%c%s  \\end{matrix}',char(13),char(13),S);

end
