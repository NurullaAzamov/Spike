classdef problemR < problemI

    properties (Access = private)
        lastdigit;
        lastdigitpos;
    end
    
    methods
        
        function q=problemR(S)
            q=q@problemI(S);
        end
        
    end
    
    methods (Access = protected)
        
        
        function q=SetRandPerm(q)
            % the identity permutation
            q.RandPerm = 1:q.NAltAnswers;
        end

        
        function q=SetCorrAns(q)
            
            NAttempts=0;
            
            while true,
                
                % Find position of the "last digit" in the string.
                [q.lastdigit,q.lastdigitpos]=lastdigit_of_typeR_answer(q.answer);
                
                % Check the quality of problemR type answer:
                Rquality=q.AnswerQuality;
                
                % If the answer quality is bad, then ...
                if Rquality > 2,
                    NAttempts=NAttempts+1;
                    if NAttempts >= 50,
                        fprintf('\nSpike: too many attepmts to find');
                        fprintf(' a good quality type R answer.\n');
                        fprintf('%s\n',q.TxtPt(1,:));
                        error('The program terminated.');
                    end
                    % ... run the command part again.
                    q=q.ProcessCmdPt;
                else 
                    break
                end
            end
            
            if isempty(q.lastdigitpos),
                q.Sp_Error('No digits in type R answer',q.answer);
            end
                
            q.CorrAns(q.CRepeat)=char(floor(q.lastdigit/2) + 65);
        end
        
        
        function q=ProcessAnswers(q)
            fprintf(q.outfile,'\n\\medskip\\noindent\n');
           
            % Write Multiple Choice answers.
            
            if  mod(q.lastdigit,2)==0,
                lastchar='02468';
            else
                lastchar='13579';
            end
            
            for m=1:5  %q.NAltAnswers,
                fprintf(q.outfile,'(%c) \\ ',char(64+m));
                wrongans=q.answer;
                if q.lastdigitpos==0,
                    q.Sp_Error('q.lastdigitpos==0',q.answer);
                end
                wrongans(q.lastdigitpos)=lastchar(m);
                if wrongans(1)=='$',
                    fprintf(q.outfile,'%s\\quad\n',wrongans);
                else
                    fprintf(q.outfile,'$%s$\\quad\n',wrongans);
                end
            end
            
            fprintf(q.outfile,'\n');
        end
        
        function AQ=AnswerQuality(q)
            % If, say, r = '230.05000',
            % then this function returns q = 3,
            % that is, the number of trailing zeros.
            % Answres of this kind: 1.66667 are also treated. 
            
            r=q.answer(1:q.lastdigitpos);
            
            if r(end)=='$',
                r=r(1:end-1);
            end
            
            k=length(r);
            
            if r(k)=='0',
                AQ=0;
                for j=k:-1:1,
                    if r(j)=='0',
                        AQ=AQ+1;
                    elseif r(j)=='.',
                        continue
                    else
                        break
                    end
                end
            else
                AQ=0;
                for j=k-1:-1:1,
                    if r(j)==r(k),
                        AQ=AQ+1;
                    elseif r(j)=='.',
                        continue
                    else
                        break
                    end
                end
            end
            
        end
        
    end

    
end % classdef problemR

function [lastdigit,lastdigitpos]=lastdigit_of_typeR_answer(answ)
  
k=strfind(answ,'\cdot');
if ~isempty(k),
    answ=answ(1:k-1);
end

k=strfind(answ,'{}');
if ~isempty(k),
    answ=answ(1:k-1);
end

len=length(answ);

lastdigitpos=0;
for j=len:-1:1,
   lastdigit=intersect(answ(j),'0':'9'); 
   if ~isempty(lastdigit),
       lastdigit=lastdigit-'0';
       lastdigitpos=j;
       break
   end
end

end