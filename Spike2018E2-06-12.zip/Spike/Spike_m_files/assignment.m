classdef assignment

    properties
        topic;    % topic of assignment
        number;   % assignment number
        pmark;    % mark for this assignment in percents.
        year;     % year
        semester; % semester
        duedate;  % due date
        rseed=1; % Random seed. This number is used to 
                  %    initialize Matlab's generator of random numbers.
        SpkFile;  % spike file, which generates the assignment
    end
    
    methods
        function A=assignment(topic0,number0)
            
            A.topic=topic0;
            A.number=number0;
            A.pmark=evalin('base','PercentMarks');
            A.rseed=evalin('base','rseed');
            A.duedate=evalin('base','duedate');

            c=clock; 
            A.year=round(c(1));
            
            tcode=topic0.code;
            if c(2)<=6,
                A.semester = 1;
            else
                A.semester = 2;
            end
            
            if isnumeric(A.number),
                A.SpkFile=sprintf('%s\\A%d.spk',tcode,A.number);
            elseif A.number=='E',
                A.SpkFile=sprintf('%s\\Ex.spk',tcode);
            else
                fprintf('Spike: Error.\nThe second argument must ');
                fprintf('be a number or ''E'' character.\n');
                return
            end
            
        end % function assignment
    end % methods
end % classdef assignment
