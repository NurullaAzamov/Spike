function [outss,hparams,status,logstatus] = xprintf(inss,params)
% The function xprintf processes LaTeX-format 
% hashtag specificators in the text part 
% of a spike-block, by replacing the hastag specificators 
% by values of the corresponding variables in LaTeX format. 
% The #-variables are given as the second parameter
% of a spike-block's at-line. For example, in 
% @2:2; a,b,x,y;
% there are four #-variables: a, b, x and y.
%
% "status" is an error status. If something goes wrong,
% then "status" will contain a non-empty error message;
% otherwise "status" is the empty string.
%
% A hashtag specificator is one of the following letters: 
%
%   b, c, e, l, m, p, q, r, s, t, w.
%
%  
%  0. Boolean (discrete) outcomes.
%  #"Yes~No"b.
%
%  Often an answer to a multiplce choice question has a dichotomous 
%  character, such as "Yes/No" or "Odd/Even" etc.
%
%  #b operator translates integer value of #-variable 
%  to one of these word-options. The word options should be 
%  separated by ~. The first word option is chosen if #-variable
%  has value 0, the second word option is chosen if #-variable
%  has value 1, etc. That is, there can be more than two word-options.
%
%  For example, 
%
%  b=1; xprintf('#"odd~even"b','b')
%  ans =
%  even
%
%  x=0; xprintf('#"elliptic~parabolic~hyperbolic"b','x')
%  ans =
%  elliptic    
%
%
%  1. Coefficients:
%  #c  #+c
%
%  This command writes a number #-variable as a coefficient.
%  For example, if the #-variable $a$ has value 12 then 
%  ' #cx^2' will be replaced by ' 12x^2'.
%  Exceptional cases: 
%    if #-variable has value 1, then ' #cx^2' will be replaced by ' x^2';
%    if #-variable has value -1, then ' #cx^2' will be replaced by ' -x^2';
%    if #-variable has value 0, then ' #cx^2' will be replaced by ' ';
%      more exactly, in this case Spike will remove all characters after #c
%      until an empty space is encountered. 
%
%   If the #c command has '+' then Spike writes '+' before a positive
%   coefficient. 
%  
%   
%   If the value of #-variable is not integer then Spike assumes 
%   that it is rational and will (try to) write it as a fraction 
%   in LaTeX format. 
%
%
%  2. Floating point form of a real number:
%  #e, #[+][c|s|f|i][mantissalength][,base]e,
%
%  By default, #e represents a real number in scientific form
%  in base 10 with mantissa length 4.   
%
%  c - computer form
%
%  s - scientific form. 
%      This form is used by xprintf by default. 
%
%  f - floating form
%
%  i - integer form. 
%      To be used for integer numbers. This format
%      ignores mantissa length, which can thus be set to 0.
%      If the number is not integer, then for integer form
%      xprintf rounds it.
%         
%   Examples: 
%
%  [xprintf('#e','pi'), '  ', xprintf('#12e','pi')]
%  ans =
%  3.142\cdot 10^{0}  3.14159265359\cdot 10^{0}
%
%  [xprintf('#+7e','pi'), '  ', xprintf('#"+s5"e','pi'), 
%       '  ', xprintf('#"f6"e','pi'), '  ', xprintf('#"c5,2"e','pi'), ]
%  ans =
%  +3.141593\cdot 10^{0}  +3.1416\cdot 10^{0}  3.141593  0.11001\cdot 2^{2}
%
%  xprintf('#"i"e','round(pi^3)')
%  ans =
%  31
%
%  xprintf('#"+i0,2"e','round(pi^6)')
%  ans =
%  +1111000001
%
%  xprintf('#9,16e','pi^7')
%  ans =
%  B.CC4B10FA\cdot 16^{2}
%
%  3. Linear combinations:
%   The command #l writes a vector of numbers as a linear combination
%   whose coefficients are entries of the vector. 
%
%  #l, #+l, #"~y"l, #"+~x,y,x"l, ...
%
%
%
%  Examples:
%
%  a=[-3 0 0 1 -8 0 -1]; xprintf('#l','a')
%  ans =
%  -3x_{1}+x_{4}-8x_{5}-x_{7}   % x_1, x_2, ... 
%                               % are a default choice of variables.
%
% a=[1 2 3 6]; xprintf('#"+~y"l','a')
% 
% ans =
% 
% +y_{1}+2y_{2}+3y_{3}+6y_{4}   % write y_j instead of x_j
% 
% a=[1 2 3 6]; xprintf('#"+~x,y,z,w"l','a')   % use x,y,z,w
%                                             % instead of x_1, ... 
% 
% ans =
% 
% +x_{1}+2y_{2}+3z_{3}+6w_{4}
% 
% a=[-1 0 3 1]; xprintf('#"~\alpha"l','a')
% 
% ans =
% 
% -\alpha_{1}+3\alpha_{3}+\alpha_{4}
% 
% 
%  4. Matrices:
%  #m   #[]m   #()m or #Nm, #[]Nm, #()Nm, where N is a positive integer.
%  #"ode"m
%
%  This command writes a matrix #-variable
%  in LaTeX format. The command #m writes a matrix without brackets,
%  the command #[]m writes a matrix with square brackets,
%  the command #()m writes a matrix with round brackets.
%
%  Entries of the matrix #-variable  
%  can be non-integer rational numbers, in which case Spike 
%  will (try to) write entries as fractions in LaTeX format. 
%  If there is N in #m command then Spike will write entries of the 
%  matrix as fixed point real numbers with N digits after the decimal
%  point.
%
%  #"ode"m writes a system of ODE's with matrix #m.
%
%  #"ode."m writes the same system of ODE's using the dot for
%  the time derivative. 
%
%  5. Polynomials:
%  #p  #<p  #>p
%
%  This command writes a polynomial in LaTeX format
%  with coefficients taken from a vector #-varible. 
%  The command #<p (respectively, #>p) instructs Spike to write the 
%  polynomial in the order of increasing (respectively, decreasing) powers.
%  If the order is not specified, then Spike uses the default order 
%  of powers, which is #<p. 
%
%  For example, if the #-variable "a" has value a=[1,0,0,0.5,0,0.1]
%  then '#p' will be replaced by '1+\frac{1}{2}x^{3}+\frac{1}{10}x^{5}'.
%  For the same value of "a", The command '#>p' will be replaced by 
%  '\frac{1}{10}x^{5}+\frac{1}{2}x^{3}+1'.
%
%  This command drops a term if its coefficient is zero.
%  It also drops coefficient of a term if it is +1 or -1:
%  only the sign is written.
%
%
%  6. Permutations:
%  #0q  #1q  #2q  #"0a"q  #"0A"q  #"0n"q
%
%  The command #0q writes a permutation represented by a vector as a table.
%  The command #1q writes a permutation as a product of disjoint cycles 
%  including  trivial length one cycles. 
%  The command #2q writes a permutation as a product of disjoint cycles 
%  omitting trivial length one cycles. 
%
%  The command #"0a"q writes a permutation as a table but using 
%  lower case letters instead of numbers; if the command is #"0A"q,
%  the upper case letters are used. The command #"0n"q is the same 
%  as #0q. Here 0 can be replaced by 1 or 2 with the same effect as above. 

%  7. Rational numbers including integers 
%     and square or cubic roots of rational numbers:
%  #r, #+r, #+Nr
%
% This command writes a real number as a fraction in LaTeX format, 
% for example, 1/3 will be written as \frac{1}{3}, not as 0.3333. 
% If a real number is in fact integer, then #r will write it as an 
% integer. If denominator of the fraction is too big (>=50000), then 
% this command will try to find another reasonable algebraic expression 
% of the real number. If even this fails, then #r will produce an error 
% message and will halt the program. 
%
% The option #+r is signed version of #r.
%
%  8. Strings:
%  #s
%
%  This command works exactly as Matlab's %s command.
%  
%  9. Lines of tables.
%  #t
%
%  This command returns a string which contains elements of a vector
%  separated by a character, such as '&'. 
%  For example, if  a=[3,5,7] then '#&t'
%  will be replaced by '3&5&7'.
%
%  One can use any other non-letter character or characters 
%  instead of '&', for example, ','.
%  For instance, '#,t' will be replaced by '3,5,7'.
%
%  One can use separators with letters too. 
%  If the separator argument is supposed to contain letters, 
%  then it should be taken in double quotes. For example,
%
%  a=[3 4 5]; xprintf('#"\quad "t','a')
%
%  ans =
%
%  3\quad 4\quad 5

%  Elements of a vector can be rational numbers, in which case they will
%  be written as fractions.
%
%  If elements of a vector are real numbers, then after the separator 
%  one can give after "~" the number of digits to be written as in Matlab's 
%  %.*f command. For example, #&~2t will write elements of the vector
%  with two digits after the decimal point and these numbers will be
%  separated by &.
%
%  a=[3 4 5]; xprintf('#&~2t','a')
%
%  ans =
%
%  3.00&4.00&5.00
%
%
%  The aim of this command is to create lines of tables and matrices
%  in LaTeX format. 
%
%
%  10. Powers:
%  #w 
%
%  This command writes an integer #-variable, say, n, as a power.
%  For example, if n=-3, then ' a#w' will be replaced by ' a^{-3}'.
%  Exceptional cases: 
%      If n = 1, then ' a#w' will be replaced by 'a'.
%      If n = 0, then ' a#w' will be replaced by empty string '';
%      more exactly, in this case Spike will remove all characters 
%      preceding #w until an empty space is encountered.
%        For example, 'AB \mathbf{C}#w' will be replaced by 'AB ',
%        if the value of the corresponding #-variable is zero.
%
%  If the #-variable has rational non-integer value then Spike will 
%  (try to) write the power as a fraction. For example, if #-variable 
%  n has value 3/7, then ' a#w' will be replaced by ' a^{\frac{3}{7}}'.
%
% 
%
% Warning: in the current version of xprintf
% it is not desirable to mix #c with #w.
%
% 11. ODE's with constant coefficients
%  #y
%
%  Example: if #-variable is a row of the form [1,0,3,-1,1] then #y will
%  return the string
%    y^{(4)}+3y''-y'+y
%
% The variable hparams contains those parameters from params 
% which were not processed.
%
% For example, the command
%
% [out,h]=xprintf('#r #r #r','a,b,c,d');
%
% will return in h value 'd'.

% Find the first formatting specificator. 

% Default value of error status is empty string. 


status='';
logstatus='';

if length(inss) < 2,
    outss=inss;
    hparams=params;
    return
end

% Split inss into two parts, outss and inss.
% For example, if 
%
%              inss = 'equation #r x + #r y =...'
%
% then after the next command we will have 
%
%        outss = 'equation ' 
% and 
%        inss = '#r x + #r y =...'.
%
if inss(1) == '#',
    outss='';
else
    [outss,inss]=strtok(inss,'#');
end

% If there are no hashtag specificators 
% (that is, if inss is empty) then quit.
if isempty(inss),
    hparams=params;
    return
% Double hashtag '##' is to be replaced by '#'.
elseif StrCmp(inss,'##'),
    [s,hparams] = xprintf(inss(3:end),params);
    outss=[outss,'#',s];
    return
end

% The following command splits inss into two parts: "a" and "inss".
% "a" contains the parameter of the hash-tag operator, and "inss"
% contains everything that follows after that parameter.
%
% If, say, inss is #+3r... or #"+3"r..., then 
% after this command a will be "+3" and inss will be "r...".
%
if length(inss)>=2 && inss(2)~='"',
    [a,inss]=strtok(inss,['a':'z','A':'Z']);
    a = a(2:end);
else
    [a,inss]=strtok(inss(3:end),'"');
    inss=inss(2:end);
end

if isempty(inss),
    error('Missing hashtag specificator, such as r in "#4r".');
end

% Single out one variable "var" from the list 
% of variables "params".

%[var,hparams]=strtok(params,',');
[var,hparams]=SingleOutOneVariable(params,',');

if isempty(var),
    status='Insufficient number of parameters.';
    return
end

try
    mm=evalin('base',var);
catch ME
    fprintf('\n\n\nxprintf: ERROR.\n');
    fprintf('Message:\n      %s\n',ME.message);
    fprintf('Variable: %s\n',var);
    fprintf('Input string: %s\n',inss);
    fprintf('Parameter string: %s\n',hparams);
    fprintf('Press Ctrl+Pause to terminate the program.\n');
    %evalin('base', 'clear');
    %evalin('base', 'load ''temp.mat''');
    %delete 'temp.mat'
    pause;
end


% If this is a #%-operator, ...
if StrCmp(a,'%')  
    t=sprintf([a,inss(1)],mm);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              b
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Transformer of categorical variable.
elseif  inss(1)=='b',
   [vars,len,status]=SeparateVariables(a,'~');
   if ~isempty(status),
       return
   elseif mm>=len,
       status='Insufficient number of options in #b operator';
       return
   end
   t=vars(mm+1,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              e
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Floating form of real numbers
elseif inss(1) == 'e',
    
    if StrCmp(a,'+')  
        if mm>0, 
            sign='+'; 
        else 
            sign='';
        end
        a=a(2:end);
    else
        sign='';
    end
    
    if isempty(a),
        mantissa_len=4;
        t=Real2Base_b(mm,10,mantissa_len,'scientific');
    else
        if a(1)=='c',
            option='computer';
            a=a(2:end);
        elseif a(1)=='s',
            option='scientific';
            a=a(2:end);
        elseif a(1)=='i',
            option='integer';
            a=a(2:end);
        elseif a(1)=='f',
            option='fixed';
            a=a(2:end);
        else
            option='scientific';
        end
        
        [a,base]=strtok(a,',');
        if isempty(base),
            base=10;
        else
            base=str2double(base);
        end
        mantissa_len=str2double(a);
        t=Real2Base_b(mm,base,mantissa_len,option);
    end
    
    t=[sign,t];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              l
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linear expressions
elseif inss(1)=='l',
    % Read two parameters of the #l command.
    if StrCmp(a,'~')  
        ltr=a(2:end);
        a='';
    else 
        a=strtrim(a);
        [a,ltr]=strtok(a,'~');
        if isempty(ltr),
            ltr='x';
        else 
            ltr=ltr(2:end);
        end
    end
    
    sign='';
    if ~isempty(a),
        if strcmp(a,'+'),
            sign='+';
        else
            status='The #l command must be of only two forms: #l or #+l.';
            return
        end
    end
    
    % There are two ways to give the second parameter for #l command:
    % say, #"~y"l or, say, #"~x,y,z"l
    % returning respectively 3y_{1}+y_{2}-4y_{3} or 3x+y-4z.
    t='';
    n=length(mm);
    if ismember(',',ltr);
        for k=1:n,
            [ch,ltr]=strtok(ltr,',');
            if isempty(ch),
                error('xprintf: #l command has insufficient number of vars');
            end
            if NotZero(mm(k)),
                if ~strcmp(ch,'1'),
                    t=sprintf('%s%s%s',t,AsSignedCoef(mm(k)),ch);
                else % that is, if ch='1'
                    if mm(k)< -10^(-10),
                        t=sprintf('%s%s',t,LaTeXFrac(mm(k)));
                    else 
                        t=sprintf('%s+%s',t,LaTeXFrac(mm(k)));
                    end
                end
            end
        end
    else
        for k=1:n,
            if NotZero(mm(k)),
                t=sprintf('%s%s%s_{%d}',t,AsSignedCoef(mm(k)),ltr,k);
            end
        end
    end
    if isempty(t),
        t='0';
    elseif t(1)=='+',
        if isempty(sign),
            t=t(2:end);
        end
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Matrices
elseif inss(1)=='m'
    if StrCmp(a,'ode')
        a=a(4:end);
        DerChar='''';
        
        if ~isempty(a)
            if a(1)==''''
                a=a(2:end);
            elseif a(1)=='.'
                % if the hashtag command is something like
                % '#"ode."m' then ...
                DerChar='.';
                a=a(2:end);
            end
        end
        
        if isempty(a)
            [N,~]=size(mm);
            x_y_z='x~y~z~u~v~w';
            xyz='xyzuvw';
            t='';
            for j=1:N
                if DerChar==''''
                    t=sprintf('%s%c''=',t,xyz(j));
                else
                    t=sprintf('%s\\dot %c=',t,xyz(j));
                end
                t=[t,LinComb(mm(j,:),x_y_z)];
                if j<N
                    t=[t,',\qquad '];
                end
            end
            
        end
    else % if it is a usual matrix   
        % separate the "bracket part" of the #m command.
        if StrCmp(a,'[]'),
            bra='\left['; ket='\right]';
            a=a(3:end);
        elseif StrCmp(a,'()'),
            bra='\left('; ket='\right)';
            a=a(3:end);
        else
            bra=''; ket='';
        end
        
        % if there is N in the #m command,
        % such as in #()Nm, then let k=N,
        % otherwise k=0.
        if isempty(a),
            k=0;
        else
            k=str2double(a);
        end
        
        %t=sprintf('%s%s@n%s',bra,LaTeXMatrix(mm,k),ket);
        t=sprintf('%s%s%c%s',bra,LaTeXMatrix(mm,k),char(13),ket);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              p
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomials
elseif inss(1)=='p',
    if strcmp(a,'<') || isempty(a),
        t = PolyToLaTeX(mm);
    elseif strcmp(a,'>'),
        t = PolyToLaTeXDesc(mm);
    else
        status='Unknown parameter in #p command';
        return
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              q
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Permutations
elseif inss(1) == 'q',
    if length(a)~=1,
        if length(a)==2,
            X=a(2);
            a=a(1);
        else
            status='The #q command must be of the form #Nq or #NXq.';
            return
        end
    else
        X='n';
    end
    
    if a=='0',
        t=Perm2LaTeX(mm,X);
    elseif a=='1',
        t=Perm2CycleProdLaTeX(mm,X);
    elseif a=='2',
        t=Perm2ShortCycleProdLaTeX(mm,X);
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              r, c
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Real numbers
elseif ismember(inss(1),'rc') 
    
    if StrCmp(a,'+')  % ~isempty(a) && a(1)=='+',
        sign='+';
        a=a(2:end);
    else
        sign='';
    end
    
    if isempty(a),
        [t,logstatus]=LaTeXFrac(mm);
    else
        kk=str2double(a);
        t=sprintf('%.*f',kk,mm);
    end
    
    if mm>0,
        t=[sign,t];
    end
    
    if (inss(1) == 'c')
        if IsZero(mm-1)
            t=sign;
        elseif IsZero(mm+1)
            t='-';
        elseif IsZero(mm)
            t=' ';
            [to_be_removed,inss]=strtok(inss,' ');
            to_be_removed=deblank(to_be_removed); % need to fix. 
            if length(to_be_removed)>8,
                fprintf('Zero coefficient of a lengthy expression:\n');
                fprintf('"%s"       Is this ok?\n',to_be_removed);
            elseif strcmp(to_be_removed,'c'),
                fprintf('Zero coefficient of an empty expression:\n');
                fprintf('"%s"       Is this ok?\n',to_be_removed);
            end
        end
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Strings, characters
elseif inss(1)=='s',
    t = sprintf('%s',mm);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              t
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rows of tables, vectors
elseif inss(1)=='t',
    % say, if we have a hashtag command 
    % #,~2t, then a = ',' and kk='~2'.
    [a,kk]=strtok(a,'~');
    
    if isempty(a),
       a=' ';
    end
    
    if isempty(kk),
        t=sprintf('%s',LaTeXFrac(mm(1)));
        n=length(mm);
        for j=2:n,
            t = sprintf('%s%s%s',t,a,LaTeXFrac(mm(j)));
        end
    else 
        kk=str2double(kk(2:end));
        t=sprintf('%.*f',kk,mm(1));
        n=length(mm);
        for j=2:n,
            t = sprintf('%s%s%.*f',t,a,kk,mm(j));
        end
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              w
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Powers
elseif inss(1)=='w',
    if isempty(a),
        if IsZero(mm-1),
            t='';
        elseif IsZero(mm),
            t='';
            outss=deblank(outss);
            xx=strfind(outss,' ');
            if ~isempty(xx),
                outss=outss(1:xx(end));
            else
                outss='';
            end
        else
            t = sprintf('^{%s}',LaTeXFrac(mm));
        end
    else
        status='Unknown parameter in #w command';
        return
    end
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ODE's with constant coefficients
elseif inss(1)=='y',
    t = RowToODE(mm);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              ?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    status='Unknown #-specificator.';
    return
end

outss=sprintf('%s%s%s',outss,t,inss(2:end));

[outss,hparams,status]=xprintf(outss,hparams);

end