function [var,hparams,status]=SingleOutOneVariable(ss,sep)
% "ss" is a string of variables separated by "sep".
% The function SingleOutOneVariable chops out the first variable from ss
% and assigns it to "var". "hparams" contains the remaining variables in 
% "ss". status is an error status: if "status" is empty, then everyting 
% is ok, otherwise "status" contains the error message.

status='';
roundbrs=0;
squarebrs=0;
curvedbrs=0;

if isempty(ss),
    var='';
    hparams='';
    return
elseif ss(1)==sep,
    ss=ss(2:end);
end

n=length(ss);

for j=1:n,
    if ss(j)=='(',
      roundbrs=roundbrs+1;
    elseif ss(j)==')',
      roundbrs=roundbrs-1;
    elseif ss(j)=='[',
      squarebrs=squarebrs+1;
    elseif ss(j)==']',
      squarebrs=squarebrs-1;
    elseif ss(j)=='{',
      curvedbrs=curvedbrs+1;
    elseif ss(j)=='}',
      curvedbrs=curvedbrs-1;
    end
    
    if roundbrs < 0,
        status='Unbalanced round brackets';
        return
    elseif squarebrs < 0,
        status='Unbalanced square brackets';
        return
    elseif curvedbrs < 0,
        status='Unbalanced curved brackets';
        return
    end
    
    if ss(j)==sep && roundbrs==0 && squarebrs==0 && curvedbrs==0,
        var=ss(1:j-1);
        hparams=ss(j+1:end);
        return
    end
end

var=ss; hparams='';

end
