classdef problemV < problem
    
    properties
    end
    
    methods

        function q=problemV(S)
            q=q@problem(S);
        end
        
    end
    
    methods (Access = protected)
        
        function q=SetCorrAns(q)
            q.CorrAns=q.TxtPtPar(2);
        end
        
        function q=ProcessTxtPt(q)
            for k=1:q.NTxtPt,
                fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k,:)));
            end
            fprintf(q.outfile,'\n');
        end
        
    end
end % classdef problemV < problem