classdef problemN < problemI
    % This class implements multiple choice
    % questions of type I.
    
    properties
    end
    
    methods
        
        function q=problemN(S)
            % S is a spikeblock
            q=q@problemI(S);
        end
        
    end
    
    methods (Access = protected)
        
        function q=SetCorrAns(q)
            %q.CorrAns = '?';
        end
        
        function q=ProcessAnswerCmd(q)
            % In problemN type question the answer is a 
            % one digit integer variable "intans".

            % Execute the last command in the command part,
            % it must produce "intans" variable. 
            k=q.NCmdPt;
            out = strtrim(q.CmdPt(k,:));

            try
                status=Spike2Matlab(out,q.RawVolume,1);
                if ~isempty(status),
                    q.Sp_Error(status,out);
                end
            catch ME
                q.Sp_Error(ME.message,out);
            end


            try
                x=evalin('base','intans;');
            catch ME
                q.Sp_Error(ME.message,'Last command must define "intans".');
            end
            
            q.CorrAns(q.CRepeat) = char('0'+x);
        end
        
        function q=ProcessAnswers(q)
            % do nothing
        end
        
    end
    
end % classdef problemI
