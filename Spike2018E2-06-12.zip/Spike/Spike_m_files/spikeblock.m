classdef spikeblock
    
    properties
        StartLn;   % the number of the line in a spike-file 
                   %         where this block starts.
        EndLn;     % the number of the line in a spike-file 
                   %         where this block ends.
        Cmd;       % one of these: data, text, or problemX, where X
                   %     is one of A,B,D,G,H,I,R,T.
        CmdPt;     % the command part of the spike-block; 
                   %         this is what comes between << and @
        NCmdPt;    % the number of lines in the command part;
        
        TxtPt;     % the text part of spike-code; 
                   %         this is what comes between @ and >>
        NTxtPt;    % the number of lines in the text part;
        
        AtLine;    % This is the line in the block 
                   %         which starts with @ character;
        status;    % this is either '', or 'error', or 'EOF'.
        
        QuesNum; % current question in an assignment
        
        CurrAssign; % current assignment which is being prepared.

        Version; % current assignment version which is being prepared.
        
        outfile;   % this is a file where the LaTeX output is written.  
        
        logfile;   % this is a file where log-warnings go
        
        SpkFile;    % this is where this spikeblock is kept
        
        FreezeCmdPoint;  % freeze point of the command part;
        
        FreezeTxtPoint;  % freeze point of the text part;
    end
    
    methods
        
        function SB=spikeblock
            SB.Cmd='EOF';
            SB.CmdPt='';
            SB.NCmdPt=0;
            SB.TxtPt='';
            SB.NTxtPt=0;
            SB.AtLine='';
            SB.status='';
            SB.SpkFile='nil folder';
            SB.FreezeCmdPoint=0;
            SB.FreezeTxtPoint=0;
        end
        
        function SB=readspikeblock(SB,SPK,spkLine,OUT,LOG,CQues,CAss,CVer)
            % This function reads one spike-block <<...>> 
            % from a spk-file SPK, and returns it in 
            % the spike-block SB.
            %
            % Input: a pointer is at line StartLn outside 
            %        a spike-block of a file spkfile;
            %        OUT is outfile, it is not used anywhere;
            %        LOG is logfile.
            %
            % Output: one spike-block <<...>> is read into SB 
            % and the pointer is at the last line of the block.
            SB.outfile=OUT;
            SB.logfile=LOG;
            SB.QuesNum=CQues;
            SB.CurrAssign=CAss;
            SB.Version=CVer;

            % Read an opening line << and the SB.Cmd name.
            while true,
                if feof(SPK),
                    SB.status='EOF'; return
                else
                    s=deblank(fgetl(SPK));
                    spkLine=spkLine+1;
                    if StrCmp(s,'<<'),
                        SB.StartLn=spkLine;
                        if ~ StrEnd(s,';'),
                            fprintf('\nERROR in line %d:',SB.StartLn);
                            fprintf('; is expected at the end of line.\n');
                            SB.status='error';
                            return
                        else
                            SB.Cmd=s(3:end-1);
                            break
                        end
                    elseif StrCmp(s,'##'),
                        break
                    elseif StrCmp(s,'%EOF'),
                        SB.status='EOF'; return
                    end
                end
            end % true 
            
            if StrCmp(s,'<<'),
                %[SB,SB.EndLn]=ReadBlock(SB,SPK,spkLine);
                SB=ReadBlock(SB,SPK,spkLine);
            elseif StrCmp(s,'##'),
                SPK=s(3:end); % this is a new spkfile
                SB.SpkFile=SPK;
                spikefile=fopen(SPK);
                if spikefile==-1,
                    fprintf('Spike: Error.\n');
                    fprintf('The file %s is not found.\n',SPK);
                    SB.status='error';
                    return
                end
                
                while true,
                    if feof(spikefile),
                        SB.status='EOF'; return
                    else
                        s=deblank(fgetl(spikefile));
                        if StrCmp(s,'<<'),
                            if ~ StrEnd(s,';'),
                                fprintf('\nERROR in line ??:');
                                fprintf('; is expected at the end of line.\n');
                                SB.status='error';
                                return
                            else
                                SB.Cmd=s(3:end-1);
                                break
                            end
                        elseif StrCmp(s,'%EOF'),
                            SB.status='error'; return
                        end
                    end
                end
                
                SB.Cmd=s(3:end-1);
                fakeLine=1;
                SB=ReadBlock(SB,spikefile,fakeLine);
                SB.EndLn=spkLine;
                fclose(spikefile);
            end
            
            
        end % spikeblock
        
        function [outstr,outparams]=ProcessHashtags(q,ss,params)
            
            % Replace quotes ' in the line "ss" by double
            % quotes ''. This is necessary for "xprintf"
            % function to correctly process "ss".
            ss=strrep(ss,'''','''''');
            % But there is something wrong (what exactly?) with this.
            % Need to fix this. (I think this issue has been fixed).
            
            out=['xprintf(''',ss,''',''',params,''');'];
            
            try
                % logstatus is info which goes to the log-file,
                % status is an indicator of correct work.
                
                [outstr,outparams,Status,logstatus]=evalin('base',out);
                % now outstr contains a line of the text part
                % with processed hashtags.
                
                % Error processing,
                if ~isempty(Status),
                    q.Sp_Error(Status,ss);
                end
                
                % and again.
                if ~logstatus,
                    fprintf(q.logfile,'%s',logstatus);
                end
                
            catch ME
                
                q.Sp_Error(ME.message,out);
                
            end
            
        end
        
        function ME_Error(SB,str,ME)
            fprintf('\n\n\nERROR in spike-block ');
            fprintf('starting at line %d in spk-file.\n',SB.StartLn);
            fprintf('Spike-block type: %s\n\n',SB.Cmd);
            fprintf('Line with error:\n      !%s!\n\n',str);
            fprintf('%s\n',ME.identifier);
            fprintf('%s\n',ME.message);
            fprintf('Press Ctrl+Pause to terminate the program.\n');
            evalin('base', 'clear');
            evalin('base', 'load ''temp.mat''');
            delete 'temp.mat'
            pause;
        end
        
    end
end % spikeblock