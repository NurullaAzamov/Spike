function outss=ProcessFString(inss)
% This function is used to process lines in questions 
% of type problemT, which contain randomising operators.

if StrCmp(inss,'-------'),
    outss=inss;
else
    [a,b]=strtok(inss,'@');
    b=strtrim(b);
    if isempty(b),
        outss=a;
        return
    end
    % the last two variables here (1 and 0) should be ignored.
    [b,~,~]=ProcessCurvedBrackets(b(2:end),1,0);
    % now b contains numbers instead of {...}.
    
    %
    if isempty(b),
        outss=a;
    else
        a=strrep(a,'''','''''');
        str0=sprintf('xprintf(''%s'',''%s'');',a,b);
        try
            outss=evalin('base',str0);
        catch ME
            fprintf('\nERROR in line ''%s'':\n',inss);
            fprintf('%s\n',ME.identifier);
            fprintf('%s\n',ME.message);
            error('The program is halted.');
        end
    end
end
