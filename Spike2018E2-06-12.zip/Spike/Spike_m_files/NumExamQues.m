function N=NumExamQues(startstr, tfile)
% This function returns the number
% of exam theory questions in the topic.
% This number is the number of "\item"s
% in the theory list questions from the 
% the topic lecture notes kept in the "tfile". 
% More precisely, this number is the number of items
% between \begin{enumerate} and \end{enumerate}
% which follow after the startstr. 

f=fopen(tfile);

while 1
    if feof(f)
        fprintf('Error: in %s\n the line %s is expected\n',tfile,startstr);
        error('Halted.');
    end
    
    s=fgetl(f);
    
    if StrCmp(s,startstr)
        break
    end
end

N=0;
while 1
    endstr='\end{enumerate}';
    if feof(f)
        fprintf('Error: in %s\n the line %s is expected\n',tfile,endstr);
        error('Halted.');
    end
    
    s=fgetl(f);
    
    s=strtrim(s);

    if StrCmp(s,endstr)
        break
    elseif StrCmp(s,'\item')
        N=N+1;
    end

end

fclose(f);

end