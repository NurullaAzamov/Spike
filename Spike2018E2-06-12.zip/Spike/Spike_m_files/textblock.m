classdef textblock < spikeblock
    
    properties
    end
    
    methods

        function q=textblock(S)
            q.NTxtPt=S.NTxtPt;
            q.TxtPt=S.TxtPt;
            q.StartLn=S.StartLn;
            q.CurrAssign=S.CurrAssign;
            q.Version=S.Version;
            q.outfile=S.outfile;
            q.logfile=S.logfile;
        end
       
        function q=ProcessTxtPt(q)
            ss1=deblank(q.TxtPt(1,:));
            if ~StrCmp(ss1,'@'),
                for k_00=1:q.NTxtPt,
                    fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k_00,:)));
                end
                
            else    
                
                params=[',',ss1(2:end)];
                
                there_are_any_hashtags=1;
                
                % Process hashtag and double hashtag operators,
                % if there are any.
                while there_are_any_hashtags,
                    
                    there_are_any_hashtags=0;
                    
                    for k=2:q.NTxtPt,
                        
                        % Get a line of the text part.
                        ss=deblank(q.TxtPt(k,:));

                        there_are_any_hashtags = ~ isempty(strfind(ss,'##'));
                        
                        [outstr,params]=ProcessHashtags(q,ss,params);
                        
                        len=length(q.TxtPt(k,:));
                        q.TxtPt(k,:)=char(ones(1,len)*' ');
                        
                        q.TxtPt(k,1:length(outstr))=outstr;
                    end
                    
                end

                for k_00=2:q.NTxtPt,
                    fprintf(q.outfile,'%s\n',deblank(q.TxtPt(k_00,:)));
                end
                
            end
        end
        
    end
    
end % classdef datablock < spikeblock

