classdef datablock < spikeblock
    
    properties
    end
    
    methods

        function q=datablock(S)
            q.NCmdPt=S.NCmdPt;
            q.CmdPt=S.CmdPt;
            q.StartLn=S.StartLn;
            q.CurrAssign=S.CurrAssign;
            q.Version=S.Version;
            q.outfile=S.outfile;
            q.logfile=S.logfile;
        end
       
        function q=ProcessCmdPt(q)
            % Evaluate commands of the command part.
            % If an attempt to evaluate fails, give an error message. 
            for k=1:q.NCmdPt,
                out = q.CmdPt(k,:);
                try
                    Spike2Matlab(out,1,0);
                catch ME
                    q.ME_Error(out,ME);
                end
            end
        end
        
    end
    
end % classdef datablock < spikeblock

