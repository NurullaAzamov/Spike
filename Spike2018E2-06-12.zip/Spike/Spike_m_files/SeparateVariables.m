function [vars,len,status]=SeparateVariables(ss,sep)
% This function returns substrings of the string "ss"
% separated by "sep" character. 
% If the last character of "ss" is not "sep",
% then "sep" is attached to the end of "ss". 
% "len" is the number of the substrings.
%
% This function ignores separators, if they appear inside
% round, square or curved brackets.
%
% For example, if sep==',' and ss=='a1,xy,k', then
% this function will return len=3 and vars(1,:)='a1',
% vars(2,:) = 'xy' and vars(3,:)='k '.
%
% If ss=='a1,xy,k,' then the result will be the same.

status='';

% If the last character of "ss" is not the separator character
% then append a separator to the end of "ss".
if ~StrEnd(ss,sep)   %was isempty(ss) || ss(end)~=sep,
    ss=[ss,sep];
end

n=length(ss);

% Find number of substrings "len".
len=sum(ss==sep);

% Initialize vars(j,:) as a string of 50 empty spaces.
vars=char(ones(len,100)*32);

% Separator positions.
sp=zeros(1,30);

roundbrs=0;
squarebrs=0;
curvedbrs=0;

len=0;

maxstrlen=0;

for j=1:n,
    if ss(j)=='(',
      roundbrs=roundbrs+1;
    elseif ss(j)==')',
      roundbrs=roundbrs-1;
    elseif ss(j)=='[',
      squarebrs=squarebrs+1;
    elseif ss(j)==']',
      squarebrs=squarebrs-1;
    elseif ss(j)=='{',
      curvedbrs=curvedbrs+1;
    elseif ss(j)=='}',
      curvedbrs=curvedbrs-1;
    end
    
    if roundbrs < 0,
        status='Unbalanced round brackets';
        return
    elseif squarebrs < 0,
        status='Unbalanced square brackets';
        return
    elseif curvedbrs < 0,
        status='Unbalanced curved brackets';
        return
    end
    
    if ss(j)==sep && roundbrs==0 && squarebrs==0 && curvedbrs==0,
       % one more varialbe
       len=len+1;
       
       % position of the new variable
       sp(len+1)=j;

       % trim the variable
       temp_ss=strtrim(ss(sp(len)+1:j-1));

       strlen=length(temp_ss);
       if strlen>maxstrlen,
           maxstrlen=strlen;
       end
       vars(len,1:strlen)=temp_ss;
    end
end

if roundbrs ~= 0, 
    status='Unbalanced round brackets';
    return
elseif squarebrs ~= 0, 
    status='Unbalanced square brackets';
    return
elseif curvedbrs~=0,
    status='Unbalanced curved brackets';
    return
end

vars=vars(1:len,1:maxstrlen);

end %SeparateVariables
