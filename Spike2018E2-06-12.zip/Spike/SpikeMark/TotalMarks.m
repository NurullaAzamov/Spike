function TotalMarks(TopicCode,MaxAssignMarks,NVersions,Sort,ExamVersion,exam,GiveNames)
% Examples of usage:
%
% TotalMarks('MATH2702',[10,15,15],2,1)        % to mark assignments only
% TotalMarks('MATH2702',[7,7,7,7],2,1,1,1,1)   for main exam,
% TotalMarks('MATH2702',[7,7,7,7],2,1,2,1,1)   for supp exam.
%
% Input: TopicCode,          is a topic code, such as MATH3712.
%        MaxAssignMarks,     is an array of maximum marks for assignments,
%                            say, [10,15,15] means that there are three
%                            assignments with maximum marks 10, 15 and 15
%                            respectively. 
%        NVersions,          the number of versions of each assignment,
%                            which is usually 2; say, 
%                            MATH3712A1V1, MATH3712A1V2, MATH3712A2V1, etc
%        Sort,               sorting parameter; if Sort==1, then student
%                            ID's are sorted by the last three digits. 
%        ExamVersion,        version of exam paper;
%                            ExamVersion = 1 (or any other odd digit) is for 
%                            the main exam paper and ExamVersion = 2 (or any 
%                            other even digit) is for the supplementary 
%                            exam paper.
%        exam,               is a boolean parameter,
%                            is exam==1, then this function will 
%                            process exam results too.
%                            By default, exam==0.
%        GiveNames,          If GiveNames==1, then student names
%                            will appear in the output file,
%                            otherwise only student ID's will.
%
%    To allow marking of exam results, in the folder 
%    [TopicCode]\Submissions create a file of this kind:
%
% 2126509:DAABDE ECCDEA, 0  0 
% 2136357:DAABCE ECADEA, 12 0
% 2136801:DACBCE EDADDB, 0  0
% 2143597:DAABCE ACDDDC, 0  0
% 2098409:CAACDE ECCAAC, 0  0
% 2134626:DAABBE ECADEA, 12 11
% 2138209:CAACCE ECADEA, 10 0
% 2120451:DAACAE CCBABD, 0  0
% 2149030:DAABDE BCEDCA, 0  0
% 2123293:DAADEE ECDDEC, 0  0
% 2134166:DAABDE ECACEA, 6  0
% 2135279:CAABDE ECZBDA, 6  0
% -------

currfolder=pwd;
if ~strcmp(currfolder(end-5:end),'\Spike'),
    fprintf('Error: to run TotalMarks the current folder is to be \\Spike.\n');
    fprintf('Please change the folder and run spike again.\n');
    return    
end

% Uppercase the topic code (just in case).
TopicCode=upper(TopicCode);

% Get list of student ID's. 
Topic=topic(TopicCode);
StudIDs=Topic.StudList;
if Sort==1,
    StudIDs=mysort(StudIDs,5,7);
end

if nargin<=4,
    exam=0;
    ExamVersion=1;
end

% The number of students.
NStud=Topic.NStud;

% The total number of assignments; usually this is 4. 
NAssignments=length(MaxAssignMarks);

% The variable Marks will contain students' marks for each assignment.
% But a student's total mark (= the sum of all assignment marks) 
% will be kept in the same array as the last entry of this array.
% So, we need to increase the number of assignments by 1.

% Initialize Marks. 
AssignmentMarks=zeros(NStud,NAssignments+1);

for A=1:NAssignments,

    fprintf('------------------------\n');
    fprintf('A%dV1:\n',A);
    % Calculate the mark for each version.
    
    AD1=AssignmentData(TopicCode,A,1,MaxAssignMarks(A),Sort);
    
    AD1=AD1.ReadDataFromSubmissionFile;
    
    if ~AD1.AssignFileExists,
        fprintf('A A%dV1 file has not been found.\n', A);
        fprintf('The program is terminated.\n');
        return
    else
        % Sort the lines of answer arrays by student ID's.
        AD1=AD1.Sorting;
        
        AD1=AD1.ProcessData;
        
        if NStud~=length(AD1.ScaledMark),
            fprintf('spikemark: the student number mismatch.\n');
            fprintf('Probably misplaced separator -------');
            fprintf(' in the student list file.\n');
            error('!')
        end
        
        AssignmentMarks(:,A) = AD1.ScaledMark;
    end
    
    if NVersions==2,
    
        fprintf('------------------------\n');
        fprintf('A%dV2:\n',A);
        AD2=AssignmentData(TopicCode,A,2,MaxAssignMarks(A),Sort);
        
        AD2=AD2.ReadDataFromSubmissionFile;
        
        if ~AD2.AssignFileExists,
            fprintf('A A%dV2 file has not been found.\n', A);
            fprintf('The program is terminated.\n');
            return
        else
            % Sort the lines of answer arrays by student ID's.
            AD2=AD2.Sorting;
            
            AD2=AD2.ProcessData;
            
            if NStud~=length(AD2.ScaledMark),
                fprintf('spikemark: the student number mismatch.\n');
                fprintf('Probably misplaced separator -------');
                fprintf(' in the student list file.\n');
                error('!')
            end
            
        end
        
        % recalculate version 2 question marks as maxima 
        % of both version marks. 
        for i=1:AD2.NStud,
            for j=1:AD2.NQues,
                AD2.QuesMarks(i,j)=max(AD1.QuesMarks(i,j),AD2.QuesMarks(i,j));
            end
            
            % Raw mark.
            AD2.Mark(i)=sum(AD2.QuesMarks(i,:));
            % ScaledMark is the mark.  10^(-6) to remove minuses.
            AD2.ScaledMark = round(10*AD2.Tot*AD2.Mark/AD2.TotalPoints+10^(-6))/10;
        end
        
        % Apply the rule: the mark for version 2 does not exceed
        % 0.4*Tot + the mark for version 1:
        
        %AssignmentMarks(:,A) = min(AD2.ScaledMark, 0.4*AD1.Tot + AssignmentMarks(:,A));
        
        % Do not apply the rule above. 
        AssignmentMarks(:,A) = AD2.ScaledMark;
        
    end
    
end

AssignmentMarks(:,NAssignments+1)=sum(AssignmentMarks,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Prepare output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrDate=date;
Year=CurrDate(end-3:end);
c=clock; 
if c(2)<=6, 
    Semester=1; 
else
    Semester=2; 
end

if exam,
    ED=AssignmentData(TopicCode,'E',ExamVersion); % ED is exam data
    ED=ReadDataFromExamFile(ED);
    
    fprintf('------------------------\n');
    fprintf('ExV1:\n');
    
    % Change weights of MCQ to 3: 
    % (this is a bad style of programming, but it works ...)
    ED.Wts=char(ones(1,12)*'3');
    ED=ProcessData(ED);
end


if exam,
    OutFile=sprintf('%s\\Marks',TopicCode);
    OutFile=sprintf('%s\\TopicResults%sV%d.txt',OutFile,Year,ExamVersion);
else
    OutFile=sprintf('%s\\Marks\\',TopicCode);
    OutFile=sprintf('%s%s_assignment_results.txt',OutFile,TopicCode);
end

f=fopen(OutFile,'w');

% Prepare the output file

fprintf(f,'Flinders University %s Semester %d.\n',Year, Semester);
if exam,
    fprintf(f,'%s %s topic results:\n\n',Topic.name,TopicCode);
else
    fprintf(f,'%s %s assignment results:\n\n',Topic.name,TopicCode);
end

fprintf(f,'     Stud.ID');
for j=1:NAssignments,
    fprintf(f,'%6c%d','A',j);
end
fprintf(f,'%7s','Sum');
if exam
    fprintf(f,'%15s%5s','Exam: MCP', 'Sum');
    for j=1:ED.NTheoryQues
        fprintf(f,'%3c%d','Q',j);
    end
    fprintf(f,'%6s%6s','Mark','Grade');
end
fprintf(f,'\n\n');

Grades=zeros(1,6);

DNS=0; Passed=0; Failed=0;

for j=1:NStud,
   fprintf(f,'%3d. ****%s',j,StudIDs(j,5:7));
   
   % Assignment marks
   for A=1:NAssignments,
       fprintf(f,'%7.1f',AssignmentMarks(j,A));
   end
   
   % ... and their sum
   SumOfAssignMarks=round(AssignmentMarks(j,NAssignments+1));
   fprintf(f,'%7d',SumOfAssignMarks);
   
   
   if exam
       fprintf(f,'%15s%5d',ED.S(j,:),ED.Mark(j));
       fprintf(f,'%4d',ED.ExamTheoryMarks(j,:));
       ExamMark=ED.Mark(j)+sum(ED.ExamTheoryMarks(j,:));
       FinalMark=SumOfAssignMarks+ExamMark;
       fprintf(f,' |%4d%4s |',FinalMark,Mark2Grade(FinalMark));
       
       if FinalMark >=85,
           Grades(6)=Grades(6)+1;
       elseif FinalMark >=75,
           Grades(5)=Grades(5)+1;
       elseif FinalMark >=65,
           Grades(4)=Grades(4)+1;
       elseif FinalMark >=50,
           Grades(3)=Grades(3)+1;
       elseif FinalMark >=45,
           Grades(2)=Grades(2)+1;
       else 
           Grades(1)=Grades(1)+1;
       end
       
       if FinalMark >= 50,
           Passed=Passed+1;
       elseif ExamMark >= 1,
           Failed=Failed+1;
       else
           if ED.S(j,1)=='.',
               DNS=DNS+1;
           else 
               Failed=Failed+1;
           end
       end
       
       if ExamMark==0,
           if ED.S(j,1)=='.',
               fprintf(f,'    DNS');
           else
               fprintf(f,'       ');
           end
       elseif (40<=FinalMark) && (FinalMark<50),
           fprintf(f,'      !');
       elseif (FinalMark<50),
           fprintf(f,'      *');
       else
           fprintf(f,'       ');
       end
       if GiveNames,
           fprintf(f,'   %s',Topic.StudNames(j,8:end));
       end
   end
   fprintf(f,'\n');
   if mod(j,5)==0,
       if exam
           fprintf(f,'%s\n',(ones(1,100)*'-'));
       else
           fprintf(f,'%s\n',(ones(1,47)*'-'));
       end
   end
end

if exam,
    fprintf(f,'\n\nCorrect answers to multiple choice questions: ');
    fprintf(f,'    %s\n',ED.Correct);
end

if exam,
    fprintf(f,'\nGrades:\n');
    fprintf(f,' HD: %4d\n',Grades(6));
    fprintf(f,' DN: %4d\n',Grades(5));
    fprintf(f,' CR: %4d\n',Grades(4));
    fprintf(f,'  P: %4d\n',Grades(3));
    fprintf(f,'F/A: %4d\n',Grades(2));
    fprintf(f,'  F: %4d\n',Grades(1));
    
    fprintf(f,'\n\nPassed/Failure info:\n');
    fprintf(f,' Passed: %4d\n',Passed);
    fprintf(f,' Failed: %4d\n',Failed);
    fprintf(f,' DNS   : %4d\n',DNS);
end

fprintf(f,'\n\n');

if exam,
    
    InFile='Exam mark challenging process.tex';
    
    g=fopen(InFile);
    
    while ~feof(g),
        ss=fgets(g);
        fprintf(f,ss);
    end
    
    fclose(g);
    
end

fclose(f);

fprintf('\n\nMarking results are in the file %s\n',OutFile);
edit(OutFile);
end

