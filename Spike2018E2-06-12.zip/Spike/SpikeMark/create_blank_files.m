function create_blank_files(topiccode)
% This function creates in folder "topiccode\Submissions" empty files 
% A1V1.txt, A1V2.txt
% A2V1.txt, A2V2.txt
% A3V1.txt, A3V2.txt
% A4V1.txt, A4V2.txt
%
% Example:
% create_blank_files('MATH3712')

currfolder=pwd;
if ~strcmp(currfolder(end-5:end),'\Spike'),
    fprintf('Error: to run spike the current folder is to be \\Spike.\n');
    fprintf('Please change the folder and run spike again.\n');
    return    
end

topiccode=upper(topiccode);

for j=1:2,
    for k=1:4,
        SubmFile=sprintf('%s\\Submissions',topiccode);
        SubmFile=sprintf('%s\\A%dV%d.txt',SubmFile,k,j);
        if exist(SubmFile,'file')==2,
            fprintf('Warning: the file \\%s already exists.\n',SubmFile);
            fprintf('So, I quit!\n');
            return
        end
        OutF=fopen(SubmFile,'w'); % the LaTeX output file
        fclose(OutF);
    end
end

end