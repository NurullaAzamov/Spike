function A=mysparse3(AS, NQues,Repeats)
% This function 
% (1) if nargin<2, then it inserts blank spaces after each 
% five characters in a string AS,
% (2) otherwise it inserts blank spaces according to string NQues.

    function s = sprsstr(ss)
        if length(ss)<=5,
            s=ss;
        else
            s=[ss(1:5),' ',sprsstr(ss(6:end))];
        end
    end

    function s = sprsstr2(ss,NQues)
        ss=[ss,'    '];
        tab=1;
        s='';
        for j=1:NQues,

            kkk=Repeats(j)-1;
            
            if tab+kkk>length(ss),
                fprintf('\nPaused. Press any key.\n');
                pause;
            end
            
            if mod(j,5)==0,
                s=sprintf('%s%s|',s,ss(tab:tab+kkk));
            else
                s=sprintf('%s%s ',s,ss(tab:tab+kkk));
            end
            
            tab=tab+Repeats(j);
            
        end
    end

AS=deblank(AS);

[m,~]=size(AS);
A=char(ones(m,200)*' ');
maxlen=0;

for i=1:m,
    if nargin==1,
        ss=sprsstr(AS(i,:));
    else 
        ss=sprsstr2(AS(i,:),NQues);
    end
    if length(ss)> maxlen,
        maxlen=length(ss);
    end
    A(i,1:length(ss))=ss;
end

A = A(:,1:maxlen);

A(end)=';';
end