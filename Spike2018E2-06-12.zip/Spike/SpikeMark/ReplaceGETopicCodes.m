function Subm0=ReplaceGETopicCodes(Subm,TopicCode)
% This function replaces a GE topic code, 
% such as 'MATH8712', if it is found in the string Subm, 
% by its normal counterpart,  such as 'MATH3712'. 

Subm0=Subm;
if strcmpi(TopicCode,'MATH3712'),
    k=strfind(Subm,'MATH8712');
    if ~isempty(k),
        Subm0(k+4)='3';
    end
    return
elseif strcmpi(TopicCode,'MATH3701'),
    k=strfind(Subm,'MATH8701');
    if ~isempty(k),
        Subm0(k+4)='3';
    end
    return    
end

end
