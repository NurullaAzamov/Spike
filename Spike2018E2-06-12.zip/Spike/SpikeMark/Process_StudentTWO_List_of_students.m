function Process_StudentTWO_List_of_students(infile)
% This function prepares a good student list file 
% from a raw student list file which is copy-pasted 
% from Flinders StudentTwo. Name of the new output
% file is obtained from the old file by adding '_new.txt'.
%
% Example. Run the following command from the Spike folder: 
% >>Process_StudentTWO_List_of_students('MATH2702\MATH2702raw')
%
% In the same forder the file 'MATH2702\MATH2702raw_new.txt'
% will appear. 

ID_length=7;

InF=fopen(infile);
outfile=[infile,'_new.txt'];
OutF=fopen(outfile,'w'); 

while ~feof(InF),
    ss=fgetl(InF);
    
    k=strfind(ss,'Enrolled');
    ss=strtrim(ss(k+length('Enrolled'):end));
    
    k=strfind(ss,'@');
    email=strtrim(ss(k-9:k-1));
    
    k=strfind(ss,'Commonwealth');
    if ~isempty(k),
        ss=ss(1:k-1);
    end

    k=strfind(ss,'Feepaying');
    if ~isempty(k),
        ss=ss(1:k-1);
    end

    k=strfind(ss,'Intl ');
    if ~isempty(k),
        ss=ss(1:k-1);
    end
    
    if ss(7)==' ',
        ss=['0',ss];
    end
    
    End=min(35,length(ss));
    fprintf(OutF,'%s:%8s:%s\n',ss(1:ID_length),email, ss(9:End));
end

fprintf(OutF,'-------');

fclose(InF);
fclose(OutF);
edit(outfile);

end