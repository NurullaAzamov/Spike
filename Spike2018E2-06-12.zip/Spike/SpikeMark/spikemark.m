function spikemark(TopicCode,An,Vn,Tot,Sort)
% spikemark, version C.
% Modified: 21 Nov 2014, 3 pm.
% This function marks answers to multiple choice questions.
% All answers must be upper case, as A,B,..., not a,b,...
%
% Examples of usage:
% Tot=10; Sort=1;
% spikemark('MATH2712',2,1,Tot,Sort)
% spikemark('MATH2702',3,1,15,1)
%
% By default, Tot=10 and Sort=1. So,
% spikemark('MATH3701',3,1,10,1) 
%     is the same as 
% spikemark('MATH3701',3,1).
%f
% and 
%
% spikemark('MATH3712',3,1,15,1) 
%     is the same as 
% spikemark('MATH3701',3,1,15).
%
% Input: 
%
%   I.  TopicCode is topic code.
%       An is the assignment number.
%       Vn is the assignment version number.
%
%       Using these parameters spikemark finds InFile 
%       which has the filename      %sA%dV%d.tex
%       where %s is the topic code, A%d is the assignment number,
%       and V%d is the assignment version number. For example, an InFile
%       can be MATH2712A3V1.tex. The InFile is to be located in the folder
%       \Spike\%s\Final\, where %s is the topic code. 
%
%       InFile is a text file which contains all the necessary 
%       information for marking of an assignment. 
%
%       spikemark scans the InFile for the line '%MARKING'. Once this 
%       line is found it starts processing the following lines.
%
%       1. The first line (after the line '%MARKING') 
%          contains types of questions, PrbType.
%       2. NAltAns, number of multiple choice answers,
%       3. Questns, question numbers,
%       4. Weights, weights of questions,
%       5. Specfcs, marking specifications,
%       6. A list of student ID's and of correct answers. 
%          This list consists of lines which contain:
%                 (1) Student ID
%                 (2) Correct answers to multiple choice questions 
%                     from the student's assignment. 
%        Example: 
%             2062083:DDDCDDBBDBCCDCDBECCBDDEBBD.
%          This list must be finished by the line starting with -------.
%
%   II.  Tot is the maximal mark for this assignment.
%
%   III. Sort. If Sort == 0, sort by student ID's, if Sort == 1, sort 
%          by the last three digits of student ID's,
%          in increasing order. Value of Sort also affects student 
%          ID's: if Sort==1, then the first four digits of ID's 
%          are replaced by stars (for privacy).
%
% Output:
%   a file in LaTeX format containing marking results and other relevant 
%   information. All you need to do is to save it and compile.

% Examples of an InFile:
%
% ... ... ...
%MARKING
%PrbType: I  I  I  I  I |I  I   I  I  B  |B   B  B  I  I |T  T  T  T  H |T  T  
%NAltAns: 5  5  5  5  5 |5  5   5  5  2  |2   2  2  5  5 |5  5  5  5  5 |5  5  
%Questns: 1  2  3  4  5 |6  7   8  9  0  |1   2  3  4  5 |6  7  8  9  0 |1  2 
%Weights: 1  2  1  1  2 |3  1   2  2  2  |2   2  2  3  3 |2  3  3  3  2 |2  3  
%Specfcs: .. .. .. .. ..|.. ... .. .. ...|... .. .. .. ..|.. .. .. .. ..|.. .. 
%2166013: CB AA BB DE ED|BD ABD DB DE AAB|BAB BA AB AD BB|21 31 32 13 32|11 22 
%2188077: AA DA ED AA CD|DB BEE BD EA BAB|BAA BB BA DB CC|21 22 11 21 00|21 32 
%2152148: DA EE CA DB CA|CC EDE DC EE BAB|AAA AB AA BB BA|22 22 31 22 02|21 33 
%2166155: ED DD ED AC CD|DA CAE CC EB ABA|BAA AA AA AE EA|22 21 21 11 12|02 31 
%...
%-------
%
%
%MARKING:EXAM
%PrbType: I  I  I  I  I |I  I   I  I  B  |B   B  B  I  I |T  T  T  T  H |T  T  
%NAltAns: 5  5  5  5  5 |5  5   5  5  2  |2   2  2  5  5 |5  5  5  5  5 |5  5  
%Questns: 1  2  3  4  5 |6  7   8  9  0  |1   2  3  4  5 |6  7  8  9  0 |1  2 
%Weights: 1  2  1  1  2 |3  1   2  2  2  |2   2  2  3  3 |2  3  3  3  2 |2  3  
%Specfcs: .. .. .. .. ..|.. ... .. .. ...|... .. .. .. ..|.. .. .. .. ..|.. .. 
%Correct: CB AA BB DE ED|BD ABD DB DE AAB|BAB BA AB AD BB|21 31 32 13 32|11 22 
% -------

if nargin<2,
    fprintf('Usage: spikemark(TopicCode,An,Vn,Tot,Sort)\n');
    fprintf('  An - assignment number\n');
    fprintf('  Vn - assignment version number\n');
    fprintf('  Tot - total mark for the assignment\n');
    fprintf('  Sort - method of sorting (usually Sort==1).\n\n');

    fprintf('The first two arguments (TopicCode and An) are compulsory.\n');
    
    fprintf('\nExamples:\n');
    fprintf('  spikemark(''MATH2702'',3,1,15,1)\n');
    fprintf('  spikemark(''MATH3701'',2)\n\n');
    return
end

currfolder=pwd;
%if ~strcmp(currfolder(end-5:end),'\Spike'),
if ~ StrEnd(currfolder,'\Spike'),
    fprintf('Error: to run spikemark the current');
    fprintf(' folder is to be \\Spike.\n');
    fprintf('Please change the folder and run spike again.\n');
    return    
end

TopicCode=upper(TopicCode);

if nargin<=4,
    Sort=1; % default value of Sort parameter.
end

if nargin<=3,
    Tot=7; % default value of maximum assignment mark.
end

if nargin<=2,
   Vn=1; % default value of assignment version number.
end

% (Constructor) Process the topic tex file:
AD=AssignmentData(TopicCode,An,Vn,Tot,Sort);


% Process the file with student email submissions:
AD=AD.ReadDataFromSubmissionFile;

fprintf('--------------------------------------\n');
fprintf('Total number of students: %d.\n',AD.NStud);

% Sort the lines of answer arrays by student ID's.
AD=AD.Sorting;

% Process the data.
% This function does all the hard job of marking.
% In particular, it calculates the fields
% S, Mark, ScaledMark and grades.
AD=AD.ProcessData;

% To obtain marks for the second version 
% we need to process both versions. 
if Vn==2,
    AD1=AssignmentData(TopicCode,An,1,Tot,Sort);
    AD1=AD1.ReadDataFromSubmissionFile;
    AD1=AD1.Sorting;
    AD1=AD1.ProcessData;

    if AD.NStud ~=AD1.NStud
        error('Error: mismatch in student numbers.');
    end
    
    for i=1:AD.NStud,
        % A mark for a question is the largest of marks for different 
        % versions of that question.
        for j=1:AD.NQues,
            AD.QuesMarks(i,j)=max(AD.QuesMarks(i,j),AD1.QuesMarks(i,j));
        end
        
        AD.Mark(i)=sum(AD.QuesMarks(i,:));
        % ScaledMark is the mark. 
        % We add 10^(-6) in order to remove minuses.
        AD.ScaledMark = round(10*AD.Tot*AD.Mark/AD.TotalPoints+10^(-6))/10;
    end
    
    AD.grades=zeros(1,AD.Tot+1);
    
    for j=1:AD.NStud,
        i=floor(AD.Tot*AD.Mark(j)/AD.TotalPoints+0.5);
        AD.grades(i+1)=AD.grades(i+1)+1;
    end
    
end

% Preparing the output file.
CurrDate=date;
Year=CurrDate(end-3:end);
c=clock; 
if c(2)<=6, 
    Semester=1; 
else
    Semester=2; 
end

% Sparse the string of + and - with blanks for better readability.
AD.S=mysparse3(AD.S,AD.NQues,AD.Repeats); 
if AD.S(end,end)==';'
    AD.S(end)=' '; % back from ';'.
end

% OutFile is a file into which marking results are written
OutFile=sprintf('%s\\Marks\\A%dV%d_marks.tex',TopicCode,An,Vn);

fprintf('Preparing the output file %s ... \n', OutFile);

f=fopen(OutFile,'w');
fprintf(f,'%% This file is prepared on %s by spikemark, version B1.\n',date);
fprintf(f,'\\documentclass[10pt]{article}\n');
fprintf(f,'\\textwidth 17cm \\oddsidemargin -1.5cm\n');
fprintf(f,'\\textheight 27cm \\topmargin -2.5cm\n');
fprintf(f,'\\pagestyle{empty}\n');
fprintf(f,'\\begin{document}\n\n');
fprintf(f,'\\begin{center}\n');
fprintf(f,'Flinders University %s Semester %d \\\\\n',Year,Semester);
fprintf(f,'%s Assignment %d ',TopicCode,An);
fprintf(f,'(version %d) marks as by %s\n',Vn,CurrDate);
fprintf(f,'\\end{center}\n\n');

%
%  Start of the main table
%

if AD.NProbl > 50,
    fprintf(f,'{\\small\n');
end

fprintf(f,'\\begin{center}\n');
fprintf(f,'\\begin{tabular}{|r|l|c|r|r|}');
fprintf(f,'\\hline\\hline\n');
fprintf(f,'&{\\small Stud.\\,ID}&Answers  &{\\small p-ts}&{\\small mark}\\\\\n');
fprintf(f,'\\hline\\hline\n');
%%%%%%%%%%%%%%%%%%%
for j=1:AD.NStud,
    
    if AD.Sort==0,
        % give the whole student ID
        fprintf(f,'%2d&\\verb!%s!',j,AD.CorrAns(j,1:7));
    else
        % give only the last three digits of the student ID
        fprintf(f,'%2d&\\verb!****%s!',j,AD.CorrAns(j,5:7));
    end
    
    if AD.AllSubmAns(j,8)==':',
        fprintf(f,'&\\verb!%s!&',AD.S(j,:));
    else
        if AD.AllSubmAns(j,8)=='*',
            ss=' Error: answer line is short';
        elseif AD.AllSubmAns(j,8)=='o',
            ss=' Error: answer line is long';
        elseif AD.AllSubmAns(j,8)=='#',
            ss=' Error: answer line has unusual answers';
        end
        answ=char(ones(1,length(AD.S(j,:)))*' ');
        answ(1:length(ss))=ss;
        fprintf(f,'&\\verb!%s!&',answ);
    end
    
    fprintf(f,'%2d&%4.1f',round(AD.Mark(j)),AD.ScaledMark(j));
    fprintf(f,'\\\\ \\hline %%%s,%s',AD.CorrAns(j,5:7),StudentName(AD.TopicCode,AD.CorrAns(j,1:7)));
    fprintf(f,'\n');
end
%%%%%%%%%%%%%%%%%%%
fprintf(f,'\\hline\n');

Repeats=GetRepeats(AD.Repeats);

sss=mysparse3(AD.Questns,AD.NQues,AD.Repeats);
sss(end)=' '; % replace ';' by ' '
fprintf(f,'         &Questns&\\verb!%s!',sss);
fprintf(f,' &       &\\\\');
fprintf(f,'\\hline\\hline\n');

sss=mysparse3(Repeats,AD.NQues,AD.Repeats);
sss(end)=' ';
fprintf(f,'         &Repeats&\\verb!%s!',sss);
fprintf(f,' &max&max\\\\');
fprintf(f,'\\hline\\hline\n');

wts_out=AD.Wts;
% replace zeros in AD.Wts by stars (just for a moment),
wts_out(wts_out=='0')='*'; 
% sparse it,
wts_out=mysparse3(wts_out,AD.NQues,AD.Repeats);
% and now replace stars by blank spaces. 
wts_out(wts_out=='*')=' '; 
wts_out(end)=' '; % and also do this.
fprintf(f,'         &Weights&\\verb!%s! &',wts_out);

fprintf(f,'%d&%d\\\\',AD.TotalPoints,AD.Tot);
fprintf(f,'\\hline\\hline\n');
fprintf(f,'\\end{tabular}\n');
fprintf(f,'\\end{center}\n');

if AD.NProbl > 50,
    fprintf(f,'}\n');
end

fprintf(f,'\n\\bigskip\\bigskip');

%
%  End of main table
%

fprintf(f,'\nIf a student''s answer is incorrect, then the correct \n');
fprintf(f,'answer \\verb!A,B,C,...! or \\verb!"-"!');
fprintf(f,' is shown in the table.\n\n');

fprintf(f,'\\bigskip \\verb!"-"! means that');
fprintf(f,' student''s answer \n');
fprintf(f,'is incorrect and the correct answer will be given later.\n\n');
fprintf(f,'\\bigskip \\verb!"+"! means that student''s answer ');
fprintf(f,'is correct.\n\n');
fprintf(f,'\\bigskip \\verb!"."! means that');
fprintf(f,' the answer was not given.\n\n\n');
fprintf(f,'%%\\bigskip If an error message is shown instead of an answer line\\\\\n');
fprintf(f,'%%you should resubmit your corrected answer line again ASAP.\n\n\n');

%
% Some statistics
%

fprintf(f,'\\newpage\n');
fprintf(f,'\\noindent The number of students enrolled in this topic: ');
fprintf(f,'%d.\\\\\n',AD.NStud);

fprintf(f,'\\noindent The number of submissions: %d.\\\\\n',AD.NSubm);

fprintf(f,'\\noindent The average mark for this assignment: ');
fprintf(f,'%6.3f.\\\\\n',sum(AD.ScaledMark)/AD.NSubm);

fprintf(f,'\\noindent The standard deviation of non-zero marks: ');
M2_without_zeros=AD.ScaledMark;
M2_without_zeros(AD.ScaledMark==0)='';
fprintf(f,'%6.3f.\n',std(M2_without_zeros));

% Numbers of correct answers and their percentages,
% -- these go to the outfile.

if AD.Vn==1
    NumbersOfCorrectAnswers(f,AD);
end

%
% Grades
%

fprintf(f,'\n\\bigskip\n\n');

fprintf(f,'\\noindent Mark distribution:\n\n\\smallskip \n\n');

fprintf(f,'\\begin{verbatim}\n');

for i=1:AD.Tot+1,
    fprintf(f,'%6.1f-%4.1f:  ',max(0,i-1.5),min(i-0.6,AD.Tot));
    fprintf(f,'%s\n',repmat('*',1,AD.grades(i)));
end

fprintf(f,'\\end{verbatim}');

fprintf(f,'\n\n\\bigskip\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% General information for students
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(f,'\\begin{itemize}\n\n');

fprintf(f,'\\item If you submitted the assignment but a mark for\n');
fprintf(f,'it is missing please let me know about it asap.\n');
fprintf(f,'However, note that the most likely reason your mark is\n');
fprintf(f,'missing is that you did not follow precisely the submission\n');
fprintf(f,'instructions which were given in the assignment pdf-file.\n\n');

fprintf(f,'\\item If you believe that some question in your assignment\n');
fprintf(f,'was marked incorrectly, then you can challenge your mark\n');
fprintf(f,'for that question. To do this please\n');
fprintf(f,'send me an email with the following information:\n');
fprintf(f,'student ID, topic code, assignment number and assignment\n');
fprintf(f,'question number, which you are challenging.\n');
fprintf(f,'For example,\\\\\n\n');
fprintf(f,'\\verb!            2028022 %s',TopicCode);
fprintf(f,' A%dV%d, Q13(b).!\\\\\n\n',An,Vn);
fprintf(f,'If your challenge is correct\n');
fprintf(f,'you will get the full mark for the question;\n');
fprintf(f,'if it is incorrect I''ll explain why.\n'); 

fprintf(f,'Every student is allowed to make two incorrect\n');
fprintf(f,'challenges (per topic, per semester).\n');
fprintf(f,'After two incorrect challenges I reserve\n');
fprintf(f,'the right not to respond to your claims.\n');
fprintf(f,'But unlike the tennis system, if you make a correct challenge,\n');
fprintf(f,'the number of challenges you have will increase by one.\n');

fprintf(f,'Challenges (especially correct ones) are welcome, \n');
fprintf(f,'since they help to improve the system.\n\n');

fprintf(f,'\\item Final mark for a second version assignment question is determined\n');
fprintf(f,'as the largest of the question marks for both versions.\n\n');

fprintf(f,'\\item The final mark for an assignment is determined\n');
fprintf(f,'according to a marking rule which is stipulated elsewhere\n');
fprintf(f,'and which is based on marks for both versions.\n\n');

fprintf(f,'\\end{itemize}\n');
fprintf(f,'\\end{document}\n');
fclose(f);
fprintf('Done.\n');

edit(OutFile);

if strcmp(TopicCode,'MATH2712') || strcmp(TopicCode,'MATH3712')
    Semester=2;
elseif strcmp(TopicCode,'MATH2702') || strcmp(TopicCode,'MATH3701')
    Semester=1;
end


DestFile=sprintf('..\\..\\Nur\\Teaching Semester %d\\%s',Semester,TopicCode);
DestFile=sprintf('%s\\Marks\\A%dV%d_marks.tex',DestFile,An,Vn);
copyfile(OutFile,DestFile);
fprintf('The LaTeX file \\%s has been copied into the folder\n', OutFile);
fprintf('%s\n\n',DestFile);

end