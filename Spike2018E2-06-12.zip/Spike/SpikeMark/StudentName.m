function name=StudentName(Topic,ID)

%ID_Length=length(ID);
filename=sprintf('%s\\StudList.txt',Topic);

f=fopen(filename);

name='';

while 1
    if feof(f)
        break
    else
        ss=fgetl(f);
        if StrCmp(ss,ID);
            sep_pos=strfind(ss,':');
            if length(sep_pos) < 2
                fprintf('ERROR in StudentName.m:\n');
                fprintf('two colons were expected,\n');
                fprintf('less than two were found.\n');
                fprintf('Change the format of StudList.txt file.\n');
                error('In StudentName.');
            end
            name = ss(sep_pos(2)+1:end);
            break
        end
    end
end

end
