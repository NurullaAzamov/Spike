function A=mysparse(AS, QuesNum)
% This function 
% (1) if nargin<2, then it inserts blank spaces after each 
% five characters in a string AS,
% (2) otherwise it inserts blank spaces according to strling QuesNum.

    function s = sprsstr(ss)
        if length(ss)<=5,
            s=ss;
        else
            s=[ss(1:5),' ',sprsstr(ss(6:end))];
        end
    end

    function s = sprsstr2(ss,QuesNum,barpos)
        j=0;
        
        for k=2:length(QuesNum),
            if QuesNum(k-1)~=QuesNum(k),
                j=k;
                break
            end
        end
        
        if j==0,
            s=ss;
        else
            if barpos==5,
                barpos=1;
                s = [ss(1:j-1),'|', sprsstr2(ss(j:end),QuesNum(j:end),barpos)];
            else
                barpos=barpos+1;
                s = [ss(1:j-1),' ', sprsstr2(ss(j:end),QuesNum(j:end),barpos)];
            end
            
        end
    end

AS=deblank(AS);

[m,~]=size(AS);
A=char(ones(m,200)*' ');
maxlen=0;

for i=1:m,
    if nargin==1,
        ss=sprsstr(AS(i,:));
    else 
        ss=sprsstr2(AS(i,:),QuesNum,1);
    end
    if length(ss)> maxlen,
        maxlen=length(ss);
    end
    A(i,1:length(ss))=ss;
end

A = A(:,1:maxlen);

end