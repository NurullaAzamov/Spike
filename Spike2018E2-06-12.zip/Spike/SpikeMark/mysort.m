function T=mysort(S,a,b)
% This function sorts strings in an array of string S
% in ascending order. A string s1 is deemed to be less
% than s2, iff s1(a:b)<s2(a:b).

N=size(S);
Sorted = 0;
for k=1:999,
    if Sorted, 
        break
    end
    Sorted = 1;
    for j=1:N-1,
        CompareLines = (S(j,a:b)~=S(j+1,a:b));
        ind=find(CompareLines);
        if isempty(ind),
           error(['mysort: identical student ID''s: ',S(j,:)]);
        else
            if S(j,a-1+ind(1))>S(j+1,a-1+ind(1)),
                SS=S(j,:); S(j,:)=S(j+1,:); S(j+1,:)=SS;
                Sorted=0;
            end
        end
    end
end
T=S;
end
