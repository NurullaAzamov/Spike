function A=mysparse2(AS, NQues,Repeats)
% This function 
% (1) if nargin<2, then it inserts blank spaces after each 
% five characters in a string AS,
% (2) otherwise it inserts blank spaces according to string QuesNum.
% For example, if AS ='TIIIIIITBITTIIIBBBITTH      ',
% NQues=22, and Repeats=22222222322222232222220000000000000
% then mysparse2 returns
% 'T  I  I  I  I |I  I  T  B   I |T  T  I  I  I |B   B  B  I  T |T  H  '

    function s = sprsstr(ss)
        if length(ss)<=5,
            s=ss;
        else
            s=[ss(1:5),' ',sprsstr(ss(6:end))];
        end
    end

    function s = sprsstr2(ss,NQues,Reps)
        tab=1;
        s='';
        for j=1:NQues,
            if mod(j,5)==0,
                s=sprintf('%s%c%*c',s,ss(tab),Reps(j),'|');
            else
                s=sprintf('%s%c%*c',s,ss(tab),Reps(j),' ');
            end
            tab=tab+1;
        end
    end

AS=deblank(AS);

[m,~]=size(AS);
A=char(ones(m,200)*' ');
maxlen=0;

for i=1:m,
    
    if nargin==1,
        
        ss=sprsstr(AS(i,:));
        
    else
        
        ss=sprsstr2(AS(i,:),NQues,Repeats);
    end
    
    if length(ss)> maxlen,
        
        maxlen=length(ss);
        
    end
    
    A(i,1:length(ss))=ss;
    
end

A = A(:,1:maxlen);

A(end)=';';
end