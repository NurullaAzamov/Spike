function outss=GetRepeats(inss)
% If, say, inss = [2,2,2,3], this 
% function returns outss = 'ababababc'.

n=length(inss);
outss='';
abc='abcdefghijklm';

for j=1:n,
    outss=[outss,abc(1:inss(j))];
end

end