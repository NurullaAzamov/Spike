function [Mark,QuesMarks]=RawMark(NQues,SLine,pos,len,wts)
% This function calculates raw (not scaled) mark of a student. 
%
% SLine is something like  ++oo++++o+o...,
% it is a line of S array. 

% We introduce "pos" and "len" arrays. 
%
% For instance, if 
%
% SLine='1122223334555',
%
% then   pos=[1,3,7,10,11]
%
% and    len=[2,4,3,1,3], number of repeats.


    function y=f(P,C)
        % P is the number of repeats,
        % C is the number of correct answers.
        % f(P,C) is the processed mark for those answers.
        
        if 2*C <= P,
            y=0;
        else
            y = (2*C-P)/P;
        end
    end


Mark=0;

QuesMarks=zeros(1,NQues);

for j=1:NQues,
    
    % if there are two or more repeats in Question j, then ...
    if len(j)>1,
        % NCorrAns is the number of correct answers
        % to repeats of Question j.
        if j<NQues,
            NCorrAns=length(strfind(SLine(pos(j):pos(j+1)-1),'+'));
        else
            NCorrAns=length(strfind(SLine(pos(j):end),'+'));
        end
        QuesMarks(j)=f(len(j),NCorrAns)*wts(j);
        
    % if there is only one repeat, then ...
    else
        % if SLine(j) is '+', consider answer as correct. 
        if SLine(pos(j))=='+',
            QuesMarks(j)=wts(j);
        end
    end
    
    Mark=Mark+QuesMarks(j);

end

end