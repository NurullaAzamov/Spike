classdef AssignmentData
   properties
       TopicCode;   % topic code
       An;          % assignment number
       Vn;          % assignment version number
       NProbl;      % number of problems in the assignment
       NQues;       % number of questions in the assignment
       Questns;     % this line indicates how many repeats
                    % each assignment question has;
                    % for instance, if Questns='1 2  34  5...',
                    % then the 1st question has 2 repeats, the 2nd
                    % question has 3 repeats, 3rd has one, etc. 
       Specfcs;     % marking specifications
       Wts;         % weights of questions (string)
       Repeats;     % repeats of questions (array of numbers)
       CorrAns;     % a double array of correct answer strings
       NStud;       % number of students enrolled in the topic
       Sort;        % sorting parameter, if Sort==0, then sort 
                    % by student ID's, if Sort==1, then sort by the 
                    % last three digits of student ID's. 
       InFile;      % file with assignment marking information
       Exam;        % a boolean variable: assignment or exam?
       Correct;     % correct answers, in case it is an exam.
       SubmAns;     % an array of answer lines submitted by students;
                    % this is in fact an array of exam answer lines,
                    % if Exam==1.
       AllSubmAns;  % an array of submission lines including non-submissions.
       NSubm;       % the number of submissions,
       Tot;         % maximum scaled mark, usually 10 or 7.
       S;           % array of lines of the kind  +++BD++B+++++E+
       Mark;        % array of students raw marks (former M field)
       QuesMarks;   % array of students marks for each question
       ScaledMark;  % array of students scaled marks (former M2 field)
       TotalPoints; % the maximum number of points
       NCAns;       % array of numbers of correct 
                    % answers to assignment questions-repeats
       NQCAns;      % array of numbers of correct 
                    % answers to assignment questions
       grades;      % an array, contains distribution of marks
       SubmFileExists;  % boolean variable, true if submission file exists.
       ExamFileExists;  % boolean variable, true if exam file exists.
       RawETheoryMarks; % marks for exam theory questions.
       NTheoryQues; % number of theory questions. 
       ExamTheoryMarks; % marks for exam theory questions.
       AssignFileExists; % boolean variable, true if assignment file exists.
   end
   
   methods
       function AD=AssignmentData(TOPICCODE,AN,VN,TOT,SORT)
           function if_different_quit(Found,Expected,LineNumber)
%               if (length(Found)<8) || (~strcmp(Found(1:8),Expected)),
                if ~ StrCmp(Found,Expected)
                   fprintf('The input file has an error in line ');
                   fprintf('%d after %%MARKING.\n',LineNumber);
                   fprintf('"%s" was expected while',Expected);
                   fprintf(' %s was found.\n',Found(1:8));
                   error('!');
               end
           end
           
           function CheckSize(Str1,Str2,should_be_size)
               if length(Str1)~=should_be_size,
                   fprintf('The string "%s" has incorrect size.',Str2);
                   error('!');
               end
           end
           
           function ss=RemoveEmpties(ss)
               % Removes auxiliary characters (some empty spaces and '|').
               
               % find those nasty empty spaces and mark them.
               for jj=1:length(ss)-1,
                   if ss(jj+1)=='|' || ss(jj+1)==' ' || ss(jj+1)==';'
                       continue % do not delete an empty space if it is 
                                % followed by one of '|' or ' ' or ';'
                   end
                   
                   if ss(jj)==' '
                       ss(jj)='@';
                   end
               end
               
%                if ss(end)==';'
%                    ss(end)=' ';
%                end
               
               ss(end)='@';
               
               ss(ss=='@')=''; % now strip those empty spaces.
               ss(ss=='|')=''; % strip those too.
           end
           
           function Str=Read_a_line(Expected,NLine,LineSize0)
               Str=fgetl(ANVN_File);
               k=strfind(Str,';');
               if ~isempty(k)
                   Str=Str(1:k);
               end
               
               if_different_quit(Str,Expected,NLine)
               sss=Str(1:8);
               
               Str=Str(9:end);
               
               Str=RemoveEmpties(Str);
               
               Str=[sss,Str];
               CheckSize(Str,Expected,LineSize0);
               Str=Str(9:LineSize0);
           end
           
           
           TOPICCODE=upper(TOPICCODE);
           AD.TopicCode=TOPICCODE;
           AD.An=AN;
           AD.Vn=VN;
           if nargin>3,
               AD.Tot=TOT;
           else 
               % default value of total mark is 10.
               AD.Tot=10;
           end
           if nargin>4,
               AD.Sort=SORT;
           else 
               % default value of sorting parameter is "true", that is,
               % by default sorting is by the last three ID digits.
               AD.Sort=1;
           end
           
           % InFile is a file which contains student ID's
           % and correct answers to the assignment or exam questions
           %sfolder=sprintf('%s\\Final\\%s',TOPICCODE,TOPICCODE);
           sfolder=sprintf('%s\\Final\\',TOPICCODE);
           if AN=='E',
               AD.InFile=sprintf('%sExV%d.tex',sfolder,VN);
           else 
               AD.InFile=sprintf('%sA%dV%d.tex',sfolder,AN,VN);
           end
           
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %  Start processing the input file InFile
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           
           AD.AssignFileExists=1;
           
           %fprintf('The input file: %s.\n', AD.InFile);
           ANVN_File=fopen(AD.InFile);
           if ANVN_File==-1,
               if VN==1,
                   % If the input file does not exist:
                   fprintf('\n\nWarning:\n\n');
                   fprintf('the answer file %s',AD.InFile);
                   fprintf(' is not found!\n\n');
                   error('The assignment file was not found');
               else % if there is no the second version
                   fprintf('***************************************\n');
                   fprintf('ERROR: the answer file\n\n');
                   fprintf('    %s\n\n',AD.InFile);
                   fprintf(' is not found.\n');
                   fprintf('***************************************\n');
                   fprintf('Copy this file from Prelim\\ to Final\\.\n');
                   fprintf('Press [Enter] to terminate the program.\n');
                   pause;
                   AD.AssignFileExists=0;
                   AD.Wts=0;
                   AD.Specfcs=0;
                   AD.CorrAns=0;
               end
               return
           end
           
           % Scan the input file until the line '%MARKING' is found.
           ss='';
           while ~StrCmp(ss,'%MARKING')
               if feof(ANVN_File),
                   fprintf('spikemark: the line %%MARKING');
                   fprintf(' is expected in the input file.\n');
                   pause
                   return
               end
               ttt=deblank(fgetl(ANVN_File));
               if length(ttt)<8,
                   continue
               else
                   ss=ttt(1:8);
               end
           end
           
           %AD.Exam = length(ttt)>=13 && strcmp(ttt(9:13),':EXAM');
           AD.Exam = StrCmp(ttt(9:end),':EXAM');
           if AD.Exam && ~AN=='E',
               error('It says exam, while the command line does not?');
           end
           
           % After the line '%MARKING' there must follow:
           %    PrbType:
           %    NAltAns:
           %    ...
           
           % Read types of questions.
           PrbTypes=fgetl(ANVN_File);
           PrbTypes=RemoveEmpties(PrbTypes);
           if PrbTypes(end)==';'
               PrbTypes=PrbTypes(1:end-1);
           end

           if_different_quit(PrbTypes,'PrbType:',1)
           LineSize=length(PrbTypes);

                      %Read_a_line('PrbType:',2,LineSize);
                      Read_a_line('NAltAns:',2,LineSize);
           AD.Questns=Read_a_line('Questns:',3,LineSize);
           AD.Wts    =Read_a_line('Weights:',4,LineSize);
           AD.Specfcs=Read_a_line('Specfcs:',5,LineSize);
           
           AD.NStud=0; % initialise NStud, the number of students.
           
           % Initialise CorrectAnswers as array of '-'.
           AD.CorrAns=char(ones(500,LineSize)*45);
           
           if AD.Exam,
               
               AD.Correct=Read_a_line('Correct:',6,LineSize);
               
               ss=deblank(fgetl(ANVN_File)); % a string of correct answers.
               if ~ StrCmp(ss,'-------')
                   ss='The delimiter ------- is expected ';
                   error([ss,'after the list of correct answers.']);
               end
               Topic=topic(TOPICCODE);
               AD.CorrAns=AD.CorrAns(1:Topic.NStud,:);  
               AD.CorrAns(:,1:7)=Topic.StudList;  
               for j=1:Topic.NStud,
                   AD.CorrAns(j,8:end)=[':',AD.Correct];
               end
               AD.NStud=Topic.NStud;
           else
               
               % Read correct answers into the array CorrectAnswers
               while true,
                   if AD.NStud>=500 || feof(ANVN_File),
                       ss='The delimiter ------- is expected ';
                       error([ss,'after the list of correct answers.']);
                   end
                   
                   ss=fgetl(ANVN_File); % a string of correct answers.
                   ss(ss==' ')='';
                   ss(ss=='|')='';
                   
                   if StrCmp(ss,'%')  
                       continue
                   elseif StrCmp(ss,'-------')
                       break
                   end
                   
                   if ss(end)==';'
                       ss=ss(1:end-1);
                   end
                   
                   off=length(ss)-LineSize;
                   if off>0
                       fprintf('Correct answers line is long by: %d\n',off);
                       error('!');
                   elseif off<0
                       fprintf('Correct answers line is short by: %d\n',abs(off));
                       error('!');
                   end
                   AD.NStud=AD.NStud+1;
                   AD.CorrAns(AD.NStud,:)=ss;
                   if AD.CorrAns(AD.NStud,8) ~= ':'
                       error(['":" is expected in the line: ', ss]);
                   end
               end
               
               % removing empty lines
               AD.CorrAns=AD.CorrAns(1:AD.NStud,:);  
    
           end
           
           fclose(ANVN_File);
           
           
           % Sort correct answers CorrectAnswers 
           % before starting to do anything with it.
           if AD.Sort==1,
               AD.CorrAns=mysort(AD.CorrAns,5,7);
           elseif AD.Sort==0,
               AD.CorrAns=mysort(AD.CorrAns,1,7);
           else
               error('Unexpected sorting parameter.')
           end
           
           AD.NProbl=LineSize-8;
           
       end % function AssignmentData

       function AD=ReadDataFromExamFile(AD)
           % This function Processes the file with students 
           % answers to exam multiple choice questions.
           % This file has a name like  ExV1_2016.txt,
           % where '2016' is the currest year.

           MaxNTheoryQues=5;
           
           %c=clock;
           %year=c(1);
           txtfile=sprintf('%s\\Submissions\\',AD.TopicCode);
%            txtfile=sprintf('%sExV%d_%d.txt',txtfile,AD.Vn,year);
           txtfile=sprintf('%sExV%d.txt',txtfile,AD.Vn);
       
           AD.ExamFileExists=1;

           f=fopen(txtfile);
           if f==-1,
               fprintf('Error: the file %s does not exist.\n',txtfile);
               %AD.ExamFileExists=0;
               error('!');
           end

           AD.SubmAns=char(ones(200,8+AD.NProbl)*'.');
           AD.RawETheoryMarks=zeros(200,MaxNTheoryQues);
           
           AD.NSubm=0;
           while ~feof(f),
               s=fgetl(f);
               if s==-1,
                   break
               elseif StrCmp(s,'-------'),
                   break
               end
               % Skip empty lines and comments
               if isempty(s) || (s(1)=='%'),
                   continue
               else
                   % separate multiple choice part OneSubm
                   % and theory part TheoryMarks of an exam answer line.
                   [OneSubm,TheoryMarks]=strtok(s,',');
                   % Remove blanks from OneSubm.
                   OneSubm(OneSubm==' ')=''; 
                   
                   TheoryMarks(TheoryMarks=='-')='0'; 
                   
                   AD.NSubm=AD.NSubm+1;
                   % The first character of TheoryMarks is a comma;
                   % so to remove it we take TheoryMarks(2:end).
                   
                   theory_marks=str2num(TheoryMarks(2:end));
                   
                  
                   if AD.NSubm==1,
                       numThQ=length(theory_marks);
                       AD.NTheoryQues=numThQ;
                       AD.RawETheoryMarks=AD.RawETheoryMarks(:,1:numThQ);
                   end
                   
                   if AD.NSubm>1 && numThQ~=length(theory_marks)
                       fprintf('\n\nA wrong number of exam question marks in\n');
                       fprintf('\n%s.\n\n', s);
                       fprintf('Check its format.\n\n');
                       error('Error');
                   end
                   
                   AD.RawETheoryMarks(AD.NSubm,:)=theory_marks;
                   
                   if length(OneSubm)~=8+AD.NProbl
                       fprintf('\n\nThe line %s has wrong length.\n', OneSubm);
                       fprintf('Check its format.\n\n');
                       error('Error');
                   end
                   
                   AD.SubmAns(AD.NSubm,:)=OneSubm;
               end
           end
           
           AD.SubmAns=AD.SubmAns(1:AD.NSubm,:);
           AD.RawETheoryMarks=AD.RawETheoryMarks(1:AD.NSubm,:);
           
       end
       
       function AD=ReadDataFromSubmissionFile(AD)
           % Output:
           %    SubmAns: an array of answer lines submitted by students,
           %    NSubm:   the number of submissions,
           %
           % The file with students' email answers
           % must have a strict form such as:
           % 'A1V1_2015.txt', 'A3V1_2016.txt', 'A4V1_2017.txt'.
           
           ID_LENGTH=7;
           
           %c=clock;
           %year=c(1);
           txtfile=sprintf('%s\\Submissions\\',AD.TopicCode);
           txtfile=sprintf('%sA%dV%d.txt',txtfile,AD.An,AD.Vn);
           
           AD.SubmFileExists=1;

           f=fopen(txtfile);
           if f==-1,
               fprintf('Error: the file %s does not exist.\n',txtfile);
               AD.SubmFileExists=0;
               return
           end
           
           AD.SubmAns=char(ones(200,8+AD.NProbl)*'.');
           
           SetOfStudIDs=[];
           
           AD.NSubm=0;
           while ~feof(f),
               s=fgetl(f);
               if (s==-1) % || StrCmp(s,'%EOF') 
                   break
               end
               % Skip empty lines and comments
               if isempty(s) || (s(1)=='%'),
                   continue
               elseif StrCmp(s,'From')
                   continue
               else
                   OneSubm=ProcessOneSubmn(s,AD);
                   CurrStudID=str2double(OneSubm(1:ID_LENGTH));
                   if ismember(CurrStudID,SetOfStudIDs),
                       fprintf('Ignored double submission:\n   %s\n',s);
                       continue
                   else 
                       SetOfStudIDs=union(SetOfStudIDs,CurrStudID);
                   end
                   
                   AD.NSubm=AD.NSubm+1;
                   AD.SubmAns(AD.NSubm,:)=OneSubm;
               end
           end
           
           if AD.NSubm==0,
               error('It looks like there are no submissions?');
           end
           
           
           AD.SubmAns=AD.SubmAns(1:AD.NSubm,:);
           fclose(f);
           
           % Sort students' answers SubmittedAnswers before 
           % starting to do anything with it.
           AD.SubmAns=mysort(AD.SubmAns,1,7);
       
           if AD.NSubm>AD.NStud,
               fprintf('Number of submissions exceeds');
               fprintf(' number of students!\n');
               return
           end
           
       end
       
       function [outss,ErrCode]=ProcessOneSubmn(OneSubmn,AD)
           % This function returns in "outss" a string which contains
           % a student's ID and her/his answers, of this kind:
           % 2135296:DCEBDDBBDABEDEEABBEBEDABEDEBAADDECDEDDEC.
           %
           % Here OneSubmn is a line from an email submission's subject. 
           %
           
           ErrCode=':';
           ID_LENGTH=7;
           
           % Replace (possible) tabs by empty spaces.
           OneSubmn(OneSubmn==char(9))=' ';

           % Replace commas by empty spaces.
           OneSubmn(OneSubmn==',')=' ';

           
           % Insert ! after the answer string.
           OneSubm=InsertExclamationMark(OneSubmn);
          
           % Upper case everything.          
           OneSubm=upper(OneSubm);
           
           % Replace a GE Topic Code (if there is one), say, 'MATH8712',
           % by a normal one, say, 'MATH3712'.
           OneSubm=ReplaceGETopicCodes(OneSubm,AD.TopicCode);
           
           % Find the position k of the substring of the form 
           % 'MATH2712 A2V1', (assuming that MATH2712 is the 
           % topic code and A2 is the assignment number).
           
           TopicCodeAV=sprintf('%s A%dV%d',AD.TopicCode,AD.An,AD.Vn);
           k=strfind(OneSubm,TopicCodeAV);
           
           % ... if the substring of the form 'MATH2712 A2' is not found,
           % then report the failure and quit.
           if isempty(k),
               fprintf('\n\nERROR in %s:\n\n',OneSubm);
               error(['The string ',TopicCodeAV,' is not found']);
           end
           
           % Position k of the substring of the form 'MATH2712 A2V1' is found. 
           % Remove the substring 'MATH2712 A2V1' from the input string.
           OneSubm=OneSubm(k+length(TopicCodeAV):end);
           
           % Separate student's "ID" from 
           % the answers "answ" a student gave.
           [StudID,answ]=strtok(OneSubm);
           
           % Check that the ID has the right length ...
           if length(StudID)~=ID_LENGTH,
               if length(StudID)==ID_LENGTH-1,
                   StudID=['0',StudID];
               else
                   error(['The ID <<',StudID,'>> has wrong length']);
               end
           end
           % ... and that the ID consists of only the digits 0..9
           if ~(all(StudID >= '0') && all(StudID <= '9')),
               error(['Student ID ',StudID,' has non-digit characters']);
           end
           
           % Strip empty spaces from answ:
           answ(answ==' ')='';
           answ(answ==char(9))='';

           ExclPos=strfind(answ,'!');
           answ=answ(1:ExclPos-1);
           
           len=length(answ);
           if AD.NProbl > len,
               ss=fprintf('%s: answer line is short by %d\n',StudID, AD.NProbl-len);
               answ=char(ones(1,AD.NProbl)*' ');
               answ(1:length(ss))=ss;
               ErrCode='*';
           end
           
           if AD.NProbl < len,
               ss=fprintf('%s: answer line is long by %d\n',StudID, len-AD.NProbl);
               answ=char(ones(1,AD.NProbl)*' ');
               answ(1:length(ss))=ss;
               ErrCode='o';
           end
           
           % Take the first "NProbl" characters of "answ".
           % answ=answ(1:AD.NProbl); % THIS IS NOW REDUNDANT.
           
           % Check for non-answer characters.
           unusualchars='';
           if ErrCode==':', % that is, if its ok ...
               for j=1:length(answ),
                   if isempty(intersect(answ(j),['A':'H','0':'9','.Z'])),
                       if (answ(j)=='*')
                           answ(j)='.';
                       else
                           unusualchars=[unusualchars,answ(j)];
                       end
                   end
               end
           end
           
           unusualchars=deblank(unusualchars);
           
           % If there are non-answer characters, then
           % append them to the answer string.
           if ~isempty(unusualchars),
               fprintf('Unusual characters in %s: %s\n',StudID,unusualchars);
               ss='Unusual characters in answer line';
               answ=char(ones(1,AD.NProbl)*' ');
               len=min(length(ss),AD.NProbl);
               answ(1:len)=ss;
               ErrCode='#';
           end
           
           outss=sprintf('%s%c%s',StudID,ErrCode,answ);
       end
   
       function AD=Sorting(AD)
           % This function sorts data by student ID's (if Sort==0) 
           % or by the last three digits of student ID's (if Sort==1)
           if AD.Sort==1,
               fprintf('Sorting by the last three ');
               fprintf('digits of students ID''s... ');
               AD.CorrAns=mysort(AD.CorrAns,5,7);
               AD.SubmAns=mysort(AD.SubmAns,5,7);
               fprintf('done.\n');
           elseif AD.Sort==0,
               fprintf('Sorting by students ID''s... ');
               AD.CorrAns=mysort(AD.CorrAns,1,7);
               AD.SubmAns=mysort(AD.SubmAns,1,7);
               fprintf('done.\n');
           end
       end
   
       function AD=ProcessData(AD)
           % This function does all the hard job of marking.
           % In particular, it calculates the fields
           % S, Mark, ScaledMark and grades. 
           
           % Initialise AllSubmAns as an array 
           % of dots ..... (46 is the code of ".").
           
           ID_LENGTH=7;
           
           AD.AllSubmAns=char(ones(AD.NStud,8+AD.NProbl)*'.');
           
           % Copying students' ID's (only).
           AD.AllSubmAns(:,1:8)=AD.CorrAns(:,1:8); 
           
           % The variable Submitted indicates whether a student 
           % submitted an assignment or not: if the last character 
           % is +, then the assignment is submitted.
           Submitted(:,1:8)=AD.CorrAns(:,1:8); %
           
           % The arrays AD.CorrAns and AD.SubmAns are sorted 
           % by student IDs at this point.
           % Check the data for non-existent students.
           
           AD.ExamTheoryMarks=zeros(AD.NStud,AD.NTheoryQues);
           
           fprintf('Checking for non-submissions');
           fprintf(' and non-existent students. \n');
           
           for k=1:AD.NSubm,
               
               StudentID_exists=0;
               
               for j=1:AD.NStud,
                   if strcmp(AD.AllSubmAns(j,1:ID_LENGTH),AD.SubmAns(k,1:ID_LENGTH)),
                       AD.AllSubmAns(j,:)=AD.SubmAns(k,:);
                       if AD.Exam,
                           AD.ExamTheoryMarks(j,:)=AD.RawETheoryMarks(k,:);
                       end
                       StudentID_exists=1;
                       Submitted(j,8)='+';
                   end
               end
               
               if ~StudentID_exists,
                   fprintf('\nThe student ID %s',AD.SubmAns(k,1:ID_LENGTH));
                   fprintf(' is not found.\n');
                   fprintf('Press [Enter] to continue.\n\n');
                   pause;
               end
           end
           
           fprintf('Number of submissions: %d.\n',AD.NSubm);
           
           %
           %    Now start processing the data
           %
           
           % Initialise S as an array of dots ....
           AD.S=char(ones(AD.NStud,AD.NProbl)*46);
           
           %  Initialize "numbers of correct answers".
           AD.NCAns=zeros(1,AD.NProbl);
          
           for j=1:AD.NStud,
               
               % If submission is correct ...
               if AD.AllSubmAns(j,8)==':',
                   for k=1:AD.NProbl,
                       
                       % That Specfcs(k) is either '.' or 'n' means that
                       % the answer should be processed in the usual regime.
                       
                       if ismember(AD.Specfcs(k),'.n ')
                           
                           % if the answer is correct ...
                           Plus=(AD.AllSubmAns(j,8+k) == '+');
                           if (AD.AllSubmAns(j,8+k)==AD.CorrAns(j,8+k))||Plus
                               AD.S(j,k)='+';
                               AD.NCAns(k)=AD.NCAns(k)+1;
                               % if the answer is not correct
                               % or is not given ...
                           else
                               % if the answer is not given ...
                               % if AD.AllSubmAns(j,8+k) == '*'
                               if ismember(AD.AllSubmAns(j,8+k),'*.') 
                                   AD.S(j,k)='.';
                                   % if the answer is not correct ...
                               else
                                   if ismember(AD.Specfcs(k),'. ')
                                       if AD.Exam
                                           AD.S(j,k)='o';
                                       else
                                           AD.S(j,k)=AD.CorrAns(j,8+k);
                                       end
                                   elseif AD.Specfcs(k)=='n'
                                       AD.S(j,k)='-';
                                   else % this should not happen
                                       AD.S(j,k)='?';
                                   end
                               end
                           end
                           
                           % If Specfcs(k) is '+' then
                           % we treat all answers as correct ...
                           % (for whatever reason).
                           
                       elseif AD.Specfcs(k)=='+'
                           
                           if Submitted(j,8)=='+'
                               AD.S(j,k)='+';
                               AD.NCAns(k)=AD.NCAns(k)+1;
                           end
                           
                           % If Specfcs(k) is '0' then we ignore this question.
                           
                       elseif AD.Specfcs(k)=='0'
                           
                           if Submitted(j,8)=='+'
                               AD.S(j,k)='0';
                           end
                           AD.Wts(k)='0';
                       end
                   end
               end % if AD.ErrorCode==0
           end

           
           MaxN=100;
           pos=zeros(1,MaxN); % positions of questions
           len=zeros(1,MaxN); % number of repeats of questions
           wts=zeros(1,MaxN);
           
           % initialise:
           NQues0=1;          % current number of questions
           pos(NQues0)=1;     % position of the current question.
           len(NQues0)=1;     % number of repeats of the current question. 
           wts(NQues0)=str2double(AD.Wts(1));
           
           for j=2:length(AD.Questns),
               if AD.Questns(j)==' '  %AD.Questns(j-1),
                   len(NQues0)=len(NQues0)+1;
               else
                   NQues0=NQues0+1;
                   pos(NQues0)=j;
                   len(NQues0)=1;
                   if AD.Wts(j)==' '
                     wts(NQues0)=0; % this should not happen
                   else
                       wts(NQues0)=AD.Wts(j)-'0';
                   end
               end
           end
           
           pos=pos(1:NQues0);
           len=len(1:NQues0);
           wts=wts(1:NQues0);
           
           AD.NQues=NQues0;
           AD.Repeats=len;
           
           % Initialise Mark as an array of zeros.
           AD.Mark=zeros(AD.NStud,1); % Mark(j) is the mark of j-th student.

           AD.QuesMarks=zeros(AD.NStud,AD.NQues); % marks for each question. 

           % Compute students raw (unscaled) marks. 
           for j=1:AD.NStud,
               [AD.Mark(j),AD.QuesMarks(j,:)]=RawMark(AD.NQues,AD.S(j,:),pos,len,wts);
           end
           
           % Replace negative marks by zeros.
           AD.Mark=max(AD.Mark,0*AD.Mark);
           
           Pluses=char(ones(1,length(AD.Questns))*'+');
           AD.TotalPoints=RawMark(AD.NQues,Pluses,pos,len,wts);
           
           % ScaledMark is the mark.  10^(-6) to remove minuses.
           AD.ScaledMark = round(10*AD.Tot*AD.Mark/AD.TotalPoints+10^(-6))/10;
           
           % grades(i), i=1..11, is the number of students with a mark
           % within the range (i-1)/10-0.5 ... i/10-0.5 of the total mark.
           
           AD.grades=zeros(1,AD.Tot+1);
           
           for j=1:AD.NStud,
               i=floor(AD.Tot*AD.Mark(j)/AD.TotalPoints+0.5);
               AD.grades(i+1)=AD.grades(i+1)+1;
           end
           
       end % ProcessData
       
       
       
   end % methods
   
   
end