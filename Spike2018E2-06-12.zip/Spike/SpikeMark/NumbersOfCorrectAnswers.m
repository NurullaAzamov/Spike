function NumbersOfCorrectAnswers(f,AD)
% Input:
% 
%    f: output file,
%    AD: assignment data (with marking results).
%
% Output:
%    Some statistics about numbers 
%    of correct answers in the output file.

    function CorrAnsNumbs=GetCorrAnsNumbs
        CorrAnsNumbs=zeros(1,AD.NQues);
        CurrQues=0;
        CurrProbl=0;
        while 1
            CurrQues=CurrQues+1;
            if CurrQues>AD.NQues
                break
            end
            CorrAnsNumbs(CurrQues)=0;
            for i=1:AD.Repeats(CurrQues)
                CorrAnsNumbs(CurrQues)=CorrAnsNumbs(CurrQues)+AD.NCAns(CurrProbl+i);
            end
            CorrAnsNumbs(CurrQues)=CorrAnsNumbs(CurrQues)/AD.Repeats(CurrQues);
            CurrProbl=CurrProbl + AD.Repeats(CurrQues);
        end
    end

fprintf(f,'\n\n');
fprintf(f,'\\bigskip\\noindent The rounded numbers of correct answers given to\n');
fprintf(f,' each question averaged over the number of repeats: \n\n');
fprintf(f,'{\\small \\begin{verbatim}\n');

QuesPerLine=25;

T=floor((AD.NQues-0.1)/QuesPerLine)+1;

for k=1:T,
    A=1+QuesPerLine*(k-1);
    if k<T,
        B=QuesPerLine*k;
    else
        B=AD.NQues;
    end
    
    CorrAnsNumbs=GetCorrAnsNumbs;
    
    % Question numbers
    fprintf(f,'   ');
    for j=A:B, fprintf(f,'%4d',j); end
    fprintf(f,'\n');
   
    
    fprintf(f,'   ');  
    fprintf(f,'%4d',round(CorrAnsNumbs(A:B))); 
    fprintf(f,'\n');
    
    fprintf(f,'%%: ');
    fprintf(f,'%4d',round(CorrAnsNumbs(A:B)/AD.NSubm*100)); 
    fprintf(f,'\n   ');
    
    %
    % Indicators of difficulty of problems.
    %
    
    SOMETHING_REALLY_WRONG_THRESHOLD=0.3;
    DIFFICULT_PROBLEM_THRESHOLD=0.5;
    AVERAGE_PROBLEM_THRESHOLD=0.7;
    
    for j=A:B,
        if CorrAnsNumbs(j)/AD.NSubm <= SOMETHING_REALLY_WRONG_THRESHOLD,
            fprintf(f,'  !!');
        elseif CorrAnsNumbs(j)/AD.NSubm <=  DIFFICULT_PROBLEM_THRESHOLD,
            fprintf(f,'  **');
        elseif CorrAnsNumbs(j)/AD.NSubm <= AVERAGE_PROBLEM_THRESHOLD,
            fprintf(f,'  --');
        else
            fprintf(f,'    ');
        end
    end
    
    fprintf(f,'\n\n');
end

fprintf(f,'\\end{verbatim}\n}\n\n');

end