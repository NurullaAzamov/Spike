function ProcessExam(TopicCode)
end