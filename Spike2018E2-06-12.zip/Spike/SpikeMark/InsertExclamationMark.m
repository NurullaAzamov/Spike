function outss=InsertExclamationMark(inss)

% If inss already has ! then do nothing. 
ok=strfind(inss,'!');
if ok,
    outss=inss;
    return
end

Weeks='MonTueWedThuFriSatSun';

for j=1:7,
    k=strfind(inss,[' ',Weeks(3*j-2:3*j),' ']);
    if ~isempty(k),
        break
    end
end

if isempty(k),
    k=length(inss)+1;
end

outss=[inss(1:k-1),'!',inss(k:end)];

end