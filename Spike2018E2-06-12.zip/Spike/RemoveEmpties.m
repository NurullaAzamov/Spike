function ss=RemoveEmpties(ss)
% Removes auxiliary characters (some empty spaces and '|').

% find those nasty empty spaces and mark them.
for jj=1:length(ss)-1,
    if ss(jj+1)=='|' || ss(jj+1)==' ' || ss(jj+1)==';'
        continue % do not delete an empty space
                 % if it is followed by one of '|' or ' ' or ';'
    end
    
    if ss(jj)==' '
        ss(jj)='@'; % delete this empty space
    end
end

ss(end)='@';

ss(ss=='@')=''; % now strip those empty spaces.
ss(ss=='|')=''; % strip those too.
end